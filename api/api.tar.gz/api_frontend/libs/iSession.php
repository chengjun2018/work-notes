<?php

class iSession {

    static $controllerObj = null;
    static $access_token_index = "";
    static $access_token_content = array();
    static $commands = array();

    function __get($name) {
        return self::get($name, in_array($name, array("id", "status")) ? 0 : "");
    }

    /**
     * 会话redis操作
     * @global type $php
     * @return boolean
     */
    static function redis() {
        $params = func_get_args();
        $method = array_shift($params);
        //查看连接是否存在，如果不存在则创建
        $pool = iGlobal::get("pool_session");
        if (empty($pool)) {
            $pool = self::createRedis();
            if ($pool === null) {
                return false;
            }
            iGlobal::set("pool_session", $pool);
        }
        //查看连接是否断开，如果断开需要重新连接
        $ping = $pool->ping();
        if ($ping != "+PONG") {
            $pool->close();
            $pool = self::createRedis();
            if ($pool === null) {
                return false;
            }
            iGlobal::set("pool_session", $pool);
        }
        //访问redis
        $redis_ex_begin_time = microtime(TRUE);
        $ret = call_user_func_array(array($pool, $method), $params);
        $redis_ex_end_time = microtime(TRUE);
        $spend_time = ($redis_ex_end_time - $redis_ex_begin_time) * 1000;
        self::$commands[] = $method . "|" . json_encode($params, JSON_UNESCAPED_UNICODE) . "[fd][spt:{$spend_time}]";
        return $ret;
    }

    static function start(&$controllerObj) {
        $access_token_content = array("id" => 0);

        self::$controllerObj = &$controllerObj;
        $access_token = iGlobal::get("access_token");
        if ($access_token) {
            //检验token是否非法，如果token非法，这废弃，重新创建token
            if (strlen($access_token) < 20) {
                $access_token = false;
            } else {
                $access_token_index = "accesstoken_" . $access_token;
                $access_token_content_old = self::redis("get", $access_token_index);
                if ($access_token_content_old === null || $access_token_content_old === false) {
                    $access_token = false;
                } else {
                    $access_token_content = json_decode($access_token_content_old, TRUE);
                }
            }
        }

        if (!$access_token) {
            /**
             * 创建唯一token
             * 如何保证唯一：
             * 1.
             * token由device，保证正常情况下access_token对单一设备产生，
             * 并使用uniqid和随机数，保证在时间维度上token不重复
             * 2.token源，使用128位随机字符，算法对外公开也无法生成重复token，防止非法用户通过撞击生成与某正常用户相同的token凭证
             * 3.通过https协议保证token不在中间网络传输过程中被盗取
             * 4.通过使用老的token刷新新的token方式，定时刷新token,保证用户会话安全
             * 5.token只做算法验证，会话登陆依靠token和uid建立联系实现，未登陆用户会话过期时间为600秒，需要不断续期
             * 保证：在token请求被攻击情况下：每秒生成1万token,600秒最多产生600万垃圾token，同时600万token过期，
             * 每个垃圾token占用1k，则最高垃圾token对会话redis占用6G,但并发和带宽首先达到瓶颈，不会出现会话崩溃
             */
            $code = uniqid();
            for ($i = 0; $i < 128; $i++) {
                $code .= chr(rand(33, 126));
            }
            $code = sha1($code);
            $device = iGlobal::get("device");
            $access_token = $device . "##" . time() . "##" . $code;
            iGlobal::set("access_token", $access_token);
            iGlobal::set("access_token_changed", true);
        } else {
            iGlobal::set("access_token_changed", false);
        }

        $access_token_index = "accesstoken_" . $access_token;
        self::$access_token_index = $access_token_index;
        self::$access_token_content = $access_token_content;
        if (iGlobal::get("access_token_changed")) {
            self::set($access_token_content, false); //当修改时需要同步，如果不同步，异步写入晚于后续同步写入，将会出现异常bug
        }

        //续期
        $timeout = (isset($access_token_content["id"]) && $access_token_content["id"] > 0) ? 3600 * 24 * 1 : 600;
        iServer::taskfn(function() use ($access_token_index, $timeout) {
            iSession::redis("expire", $access_token_index, $timeout);
        }, 0);

        self::$controllerObj->member = $access_token_content;
        return $access_token_content;
    }

    /**
     * 获取会话，当$name为空时返回会话全部内容
     * @param string $name 用户会话内容索引，
     * @param type $default 如果会话不存在或会话内容不存在，返回的默认值，默认为“”
     * @return type
     */
    static function get($name = "", $default = "") {
        $access_token_content = self::$access_token_content;
        if (empty($name)) {
            return $access_token_content ? : (is_array($default) ? $default : array());
        } else {
            return isset($access_token_content[$name]) ? $access_token_content[$name] : $default;
        }
    }

    /**
     * 设置会话
     * 基础数据包含：id,name
     * @param array $setdata
     * @param bool $sync 是否异步
     * @return bool 成功返回true,失败返回false
     */
    static function set($setdata = array(), $sync = false) {
        $setdata = (array) $setdata;

        if (empty($setdata)) {
            $access_token_content = array("id" => 0);
        } else {
            $session = self::get(); //修改前获取会话实时数据，避免，同时多进程同时修改
            $access_token_content = array_merge($session, $setdata);
        }

        self::$access_token_content = $access_token_content;
        $access_token_index = self::$access_token_index;

        if ($sync) {
            iServer::taskfn(function()use($access_token_index, $access_token_content) {
                $ret = iSession::redis("set", $access_token_index, json_encode($access_token_content));
                if (!$ret) {
                    iLog::write("session设置失败" . json_encode($access_token_content), "session");
                }
            });
            return true;
        }
        $ret = self::redis("set", $access_token_index, json_encode($access_token_content));
        if ($ret) {
            self::$controllerObj->member = $access_token_content;
        }
        return $ret;
    }

    /**
     * 消除会话
     * @return bool 成功返回true,失败返回false
     */
    static function destory($is_real_destory = false) {
        $access_token_index = self::$access_token_index;

        if ($is_real_destory) {
            self::redis("delete", $access_token_index);
        } else {
            self::set(null, true); //将session值设置为null
            self::redis("expire", $access_token_index, 600);
        }

        return true;
    }

    /**
     * 登出某用户
     * @param type $user_ids
     */
    static function logoutUser($user_ids) {
        if (!is_array($user_ids)) {
            $user_ids = [$user_ids];
        }
        foreach ($user_ids as $id) {
            $id = (int) $id;
            $loginToken = self::redis('get', APP_NAME . '_' . $id);
            if ($loginToken) {
                self::redis("delete", "accesstoken_" . $loginToken);
            }
        }
    }

    /**
     * 更新用户的权限分组
     * @param type $user_ids
     * @param type $group_ids
     */
    static function resetUserGroupIds($user_ids, $group_ids) {
        if (!is_array($user_ids)) {
            $user_ids = [$user_ids];
        }
        foreach ($user_ids as $id) {
            $id = (int) $id;
            $loginToken = self::redis('get', APP_NAME . '_' . $id);
            if ($loginToken) {
                $access_token_index = "accesstoken_" . $loginToken;
                $access_token_content = self::redis("get", $access_token_index);
                if ($access_token_content) {
                    $access_token_content = json_decode($access_token_content, TRUE);
                    if (is_array($access_token_content)) {
                        $access_token_content["group_ids"] = $group_ids;
                        self::redis("set", $access_token_index, json_encode($access_token_content));
                    }
                }
            }
        }
    }

    /**
     * 创建redis连接
     * @return \redis
     */
    private static function createRedis() {
        for ($i = 0; $i < 10; $i++) {
            $redis = new redis();
            $is_connect = $redis->pconnect(SESSION_HOST, SESSION_PORT);
            if (empty($is_connect)) {
                $redis->close();
                $str_logs = "redis连接失败，进行重连,"
                        . "连接参数：host:" . SESSION_HOST
                        . "；port:" . SESSION_PORT
                        . "；password:" . SESSION_PASSWORD;
                iLog::write($str_logs, "session");
            } else {
                return $redis;
            }
        }
        $str_logs = "Warning:redis重连10次失败，将放弃返回失败redis操作失败，"
                . "连接参数：host:" . SESSION_HOST
                . "；port:" . SESSION_PORT
                . "；password:" . SESSION_PASSWORD;
        iLog::write($str_logs, "session");
        return null;
    }

}
