<?php

/**
 * 数据库
 * 应该避免内部修改属性，导致其他请求受影响
 */
class iModel {

    //数据库模型
    protected $mysql_connect = null;
    public $db_sql = "";
    static public $commands = array();
    public $affected_rows = 0;
    public $insert_id = null;
    //具体模型需要声明
    protected $db_table = ""; //表名称：必填
    protected $fb_number = 0; //多少id进行分表，0表示不分表
    public $fb_id = ""; //当前分表标识id，必须本表存在
    //缓存标识，避免不同数据库的相同sql查询，缓存相互覆盖
    protected $cache_mark = "";
    protected $cache_time = 1; //缓存时间
    public $field = null;
    public $forbit_field = array();
    public static $affairsStatus = 0; //0：未开启事务1：事务正开启2：事务异常需要回滚
//    public $field = array(
//        "id",
//        "name",
//        "agentid",
//        "_agentinfo"=>array(
//            "data_model"=>"agent",//"Agent"
//            "data_type"=>"one",//one/lists/detail/max/min/sum/avg/count
//            "where"=>"",//(@irow.([a-z_]+))
//            "field"=>array(
//                //同当前，但受agent限制
//            ),
//            "order"=>"id desc",
//            "cache_time"=>10,//以防止并发和及时有效为标准，一般设置为
//            "limit"=>1
//        )
//    );
    protected $where = array();
    //模型对象集合
    static protected $modelObjs = array(); //公用对象池

    public function __construct($talbe_name = null) {
        if (is_string($talbe_name)) {
            $talbe_name = lcfirst(ltrim($talbe_name, "_"));
            $talbe_name = preg_replace_callback('/([A-Z]{1})/', function($matches) {
                return '_' . strtolower($matches[0]);
            }, $talbe_name);
            $this->db_table = $talbe_name;
        }
        $this->cache_mark = md5(DB_HOST . "|" . DB_PORT . "|" . DB_NAME);
    }

    /**
     * 创建数据库连接
     * @param type $last_errno
     * @return \mysqli
     */
    private function _createMysqli(&$last_errno = "") {
        for ($i = 0; $i < 10; $i++) {
            $mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, DB_PORT);
            if (mysqli_connect_errno() || !$mysqli->query('SET NAMES UTF8')) {
                $last_errno = mysqli_connect_errno();
                @$mysqli->close(); //及时回收
                $str_logs = "数据库连接失败,进行重连,"
                        . "连接参数：host:" . DB_HOST
                        . ";port:" . DB_PORT
                        . ";user:" . DB_USER
                        . ";password:" . DB_PASSWORD
                        . "db:" . DB_NAME . "\r\n"
                        . "errno:" . $last_errno;
                iLog::write($str_logs, "db_connect");
            } else {
                iLog::write("创建数据库连接" . microtime(TRUE), "db_connect");
                return $mysqli;
            }
        }

        $str_logs = "Warning:mysql重连10次失败，将放弃返回失败mysql操作失败，"
                . "连接参数：host:" . DB_HOST
                . ";port:" . DB_PORT
                . ";user:" . DB_USER
                . ";password:" . DB_PASSWORD
                . "db:" . DB_NAME . "\r\n"
                . "errno:" . $last_errno;
        iLog::write($str_logs, "db_connect");

        return null;
    }

    /**
     * 数据库单表操作函数：插入
     * @param array $data 将要插入数据键值对
     * @return int/false 上一步 INSERT 操作产生的 ID
     */
    public function _insert($data = array(), $is_asyn = false) {
        $table = $this->_getTable();
        $insert_column = "";
        $insert_value = "";
        $data = $this->_rule($data, "insert");
        if (empty($data)) {
            iLog::write("_rule后插入数据为空：{$table}", "db_error");
            return false;
        }
        foreach ($data as $k => $v) {
            $k = strval($k);
            $v = strval($v);
            $k = preg_replace("/[^a-zA-Z0-9_-]/", "", $k);
            $v = $this->_sqlstr($v);
            $insert_column .= "`{$k}`,";
            $insert_value .= "'{$v}',";
        }
        $insert_column = trim($insert_column, ",");
        $insert_value = trim($insert_value, ",");
        $ret = FALSE;
        if ($insert_column && $insert_value) {
            $sql = "INSERT INTO `{$table}`({$insert_column})VALUE({$insert_value})";
            $ret_db = $this->_query($sql, $is_asyn ? "asyn" : 0);
            if (is_array($ret_db)) {
                $ret = $ret_db["insert_id"];
            }
        } else {
            iLog::write("插入数据格式错误：{$table}-->" . json_encode($data), "db_error");
        }
        return $ret;
    }

    /**
     * 数据库单表操作函数：删除
     * @param mixed $where 删除目标数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where （当为""时表示不设置WHERE条件） 
     * @return int/false 删除影响行数
     */
    public function _delete($where = "", $is_asyn = false) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $sql = "DELETE FROM `{$table}` {$where}";
        $ret = false;
        $ret_db = $this->_query($sql, $is_asyn ? "asyn" : 0);
        if (is_array($ret_db)) {
            $ret = $ret_db["affected_rows"];
        }
        return $ret;
    }

    /**
     * 数据库单表操作：修改
     * @param array $data 将要修改数据键值对
     * @param mixed $where 修改目标数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where （当为""时表示不设置WHERE条件） 
     * @return int/false 修改影响行数
     */
    public function _update($data = array(), $where = "", $is_asyn = false) {
        $table = $this->_getTable();
        $update_kv = "";
        $format_error = FALSE;
        if (isset($data["id"])) {
            unset($data["id"]);
        }
        $data = $this->_rule($data, "update");
        if (empty($data)) {
            return false;
        }
        foreach ($data as $k => $v) {
            if (!is_string($k) || !(is_string($v) || is_numeric($v))) {
                $format_error = TRUE;
                break;
            }
            $k = preg_replace("/[^a-zA-Z0-9_-]/", "", $k);
            $v = substr($v, 0, 1) === "`" ? preg_replace("/[^0-9A-Za-z_\s+-`]/", "", $v) : "'" . $this->_sqlstr($v) . "'";
            $update_kv .= "`{$k}`={$v},";
        }
        $update_kv = trim($update_kv, ",");

        $where = $this->_where($where);
        $ret = false;
        if ($format_error == FALSE && $update_kv) {
            $sql = "UPDATE `{$table}` SET {$update_kv} {$where}";
            $ret_db = $this->_query($sql, $is_asyn ? "asyn" : 0);
            if (is_array($ret_db)) {
                $ret = $ret_db["affected_rows"];
            }
        } else {
            iLog::write("数据更新格式错误{$table}-->" . json_encode($data) . (string) $format_error . "k:" . (string) $k . json_encode($v), "db_error");
        }
        return $ret;
    }

    /**
     * 数据库单表操作：查询
     * @param mixed $where 查询条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param string $order 默认为null,表示：ORDER BY `id`；不为空时表示：ORDER BY $order
     * @param string $limit 格式例如0,10。表示从0开始最多10行数据，默认为null表示不设置LIMIT
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询,当为null是常用$this->cache_time
     * @param string $field 数据字段,默认为*,以逗号分隔
     * @return array array()/二维数据数组
     */
    public function _lists($where = "", $order = null, $limit = null, $cache_time = null, $field = "*") {
        $table = $this->_getTable();
        if (is_array($where) && isset($where['create_at']) && $where['create_at'][0] == 'between' && count($where['create_at'][1]) == 2) {
            $where['create_at'][1][0] = strtotime($where['create_at'][1][0]);
            $where['create_at'][1][1] = strtotime($where['create_at'][1][1]);
        }
        if (is_array($where) && isset($where['update_at']) && $where['update_at'][0] == 'between' && count($where['update_at'][1]) == 2) {
            $where['update_at'][1][0] = strtotime($where['update_at'][1][0]);
            $where['update_at'][1][1] = strtotime($where['update_at'][1][1]);
        }
        $where = $this->_where($where);
        if (preg_match("/([0-9]+[\s]*,[\s]*[0-9]+)|([0-9]+)/", $limit)) {
            $limit = "LIMIT " . $limit;
        } else {
            $limit = "";
        }

        if (!empty($order)) {
            $order = "ORDER BY " . $order;
        }
        $cache_time = $cache_time === null ? $this->cache_time : intval($cache_time);
        if (is_string($field) && $field !== "*" && !empty($field)) {
            $field = preg_replace("/[^a-z0-9_,*]/", "", $field);
        } else {
            $field = "*";
        }

        $allow_table_field = array();
        $allow_join_field = array();
        if (is_array($this->field)) {
            foreach ($this->field as $k => $v) {
                if (substr($k, 0, 1) !== "_") {
                    if (is_numeric($k)) {
                        $allow_table_field[$v] = array();
                    } else {
                        $allow_table_field[$k] = $v;
                    }
                } else {
                    $allow_join_field[$k] = $v;
                }
            }
        }
        $real_field = "*";
        if ($field !== "*") {
            $field_arr = explode(",", $field);
            if ($allow_table_field) {
                $field_arr = array_intersect($field_arr, array_keys($allow_table_field));
            }
            $real_field = "`" . implode("`,`", $field_arr) . "`";
        } else if ($allow_table_field) {
            $real_field = "`" . implode("`,`", array_keys($allow_table_field)) . "`";
        }

        $sql = "SELECT $real_field FROM `{$table}` {$where} {$order} {$limit}";

        $lists = $this->_query($sql, $cache_time);

        if (!is_array($lists)) {
            $lists = array();
        } else {
            foreach ($allow_join_field as $k => $v) {
                if (!isset($v["data_model"])) {
                    $v["data_model"] = get_class($this);
                    if ($v["data_model"] === "iModel") {
                        $v["data_model"] = $this->db_table;
                    }
                }
                if (!isset($v["data_type"])) {
                    $v["data_type"] = "lists";
                }
                if (!isset($v["where"])) {
                    $v["where"] = "";
                }
                if (!isset($v["cache_time"])) {
                    $v["cache_time"] = null;
                }
                if (!isset($v["field"])) {
                    $v["field"] = "*";
                }
                if (!isset($v["order"])) {
                    $v["order"] = null;
                }
                switch ($v["data_type"]) {
                    case "lists":
                        if (!isset($v["limit"])) {
                            $v["limit"] = null;
                        }
                        break;
                    default:
                }
                $allow_join_field[$k] = $v;
            }
            foreach ($lists as $k => $v) {
                foreach ($v as $kk => $vv) {
                    if (in_array($kk, $this->forbit_field)) {
                        unset($lists[$k][$kk]);
                        continue;
                    }
                    $lists[$k][$kk] = $this->_sqlstr($vv, "nation");
                }
                foreach ($allow_join_field as $jkk => $jvv) {
                    $modelObj = self::getModelObj($jvv["data_model"]);
                    //替换where语句中的内容
                    $this->_replaceIrowKv($jvv["where"], $v);
                    switch ($jvv["data_type"]) {
                        case "sum":
                            $lists[$k][$jkk] = $modelObj->_sum($jvv["field"], $jvv["where"], $jvv["cache_time"], $jvv["field"]);
                            break;
                        case "avg":
                            $lists[$k][$jkk] = $modelObj->_avg($jvv["field"], $jvv["where"], $jvv["cache_time"], $jvv["field"]);
                            break;
                        case "max":
                            $lists[$k][$jkk] = $modelObj->_max($jvv["field"], $jvv["where"], $jvv["cache_time"], $jvv["field"]);
                            break;
                        case "min":
                            $lists[$k][$jkk] = $modelObj->_min($jvv["field"], $jvv["where"], $jvv["cache_time"], $jvv["field"]);
                            break;
                        case "count":
                            $lists[$k][$jkk] = $modelObj->_count($jvv["where"], $jvv["cache_time"]);
                            break;
                        case "lists":
                            $lists[$k][$jkk] = $modelObj->_lists($jvv["where"], $jvv["order"], $jvv["limit"], $jvv["cache_time"], $jvv["field"]);
                            break;
                        case "one":
                            $lists[$k][$jkk] = $modelObj->_lists($jvv["where"], $jvv["order"], 1, $jvv["cache_time"], $jvv["field"]);
                            if ($lists[$k][$jkk]) {
                                $lists[$k][$jkk] = $lists[$k][$jkk][0];
                            }
                            break;
                        default://"detail"
                            $lists[$k][$jkk] = $modelObj->_detail($jvv["where"], $jvv["cache_time"], $jvv["field"]);
                            break;
                    }
                }
            }
        }
        return $lists;
    }

    /**
     * 数据库单表操作：查询一个数据
     * @param mixed $where 查询条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param null $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @param string $field 数据字段,默认为*
     * @return array array()/二维数据数组
     */
    public function _detail($where, $cache_time = null, $field = "*") {
        $ret = $this->_lists($where, null, 1, $cache_time, $field);
        if ($ret) {
            $ret = $ret[0];
        }
        return (array) $ret;
    }

    /**
     * 数据库单表操作：查询一个数据(_detail别名)
     * @param mixed $where 查询条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param null $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @param string $field 数据字段,默认为*
     * @return array array()/二维数据数组
     */
    public function _read($where, $cache_time = null, $field = "*") {
        return $this->_detail($where, $cache_time, $field);
    }

    /**
     * 数据库单表操作：统计数量
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _count($where = "", $cache_time = null) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $cache_time = intval($cache_time);
        $sql = "SELECT count(*) as num FROM `{$table}` {$where}";
        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $num = 0;
        } else {
            $num = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $num;
    }

    /**
     * 数据库单表操作：统计数量,sum
     * @param mixed $field 统计字段
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _sum($field, $where = "", $cache_time = null) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $cache_time = intval($cache_time);
        $sql = "SELECT sum({$field}) as num FROM `{$table}` {$where}";

        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $num = 0;
        } else {
            $num = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $num;
    }

    /**
     * 数据库单表操作：统计数量,avg
     * @param mixed $field 统计字段
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _avg($field, $where = "", $cache_time = null) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $cache_time = intval($cache_time);
        $sql = "SELECT avg({$field}) as num FROM `{$table}` {$where}";

        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $num = 0;
        } else {
            $num = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $num;
    }

    /**
     * 数据库单表操作：统计数量,max
     * @param mixed $field 统计字段
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _max($field, $where = "", $cache_time = null) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $cache_time = intval($cache_time);
        $sql = "SELECT max({$field}) as num FROM `{$table}` {$where}";

        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $num = 0;
        } else {
            $num = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $num;
    }

    /**
     * 数据库单表操作：统计数量,min
     * @param mixed $field 统计字段
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _min($field, $where = "", $cache_time = null) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $cache_time = intval($cache_time);
        $sql = "SELECT min({$field}) as num FROM `{$table}` {$where}";

        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $num = 0;
        } else {
            $num = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $num;
    }

    /**
     * 执行sql 
     * @param string $sql
     * @param string/int $chance 可以失败的机会/asyc：异步执行
     * @return boolean
     */
    public function _doSql($sql, $chance = 3) {
        $error = "";
        //查看连接是否存在，如果不存在则创建
        $mysqli = iGlobal::get("pool_mysql");
        if (empty($mysqli)) {
            $mysqli = $this->_createMysqli($error);
            if ($mysqli === null) {
                return false;
            }
            iGlobal::set("pool_mysql", $mysqli); //重新设置该进程的mysql连接
        }

        //访问数据库
        $mysqli_ex_begin_time = microtime(TRUE);

        if ($sql == 'begin') {
            $mysqli->autocommit(FALSE);
            self::$affairsStatus = 1; //开启事务
            return TRUE;
        } elseif ($sql == "end") {
            if (self::$affairsStatus == 1) {
                $mysqli->commit();
            }
            $mysqli->autocommit(TRUE); //todo 每个接口都执行，是否会对数据库造成压力？即使原本就是自动提交，针对于多个数据库连接
            self::$affairsStatus = 0; //关闭事务，除此之外，请求的进程会话开始会检查事务状态，会初始化事务状态为0
            return TRUE;
        }

        if ($chance === "asyc") {
            iServer::taskfn([], function()use($mysqli, $sql) {
                $mysqli->query($sql);
            }, 0);
            return true;
        }

        $head_sql = strtoupper(substr($sql, 0, 4));
        if (!in_array($head_sql, array("SHOW", "SELE")) && self::$affairsStatus === 2) {//如果他们不是查询语句，并且当前处于需要事务异常过程中，所有后续操作语句不执行，直接返回false
            iLog::write("md", "md");
            return false;
        }

        $ret = $mysqli->query($sql);

        $send_data = array(
            'insert_id' => 0,
            'affected_rows' => 0,
            'rows' => array()
        );

        if ($ret === TRUE) {
            $send_data["insert_id"] = $mysqli->insert_id;
            $send_data["affected_rows"] = $mysqli->affected_rows;
            unset($send_data["rows"]);
        } else if ($ret === FALSE) {//如果返回false，说明语句出错
            if (self::$affairsStatus == 1) {//当事务开启时出现返回false,要求滚回，当任何db请求返回false时必须处理，特别是事务时
                self::$affairsStatus = 2;
                $mysqli->rollback();
            }
            iLog::write("数据库操作失败。sql:【{$sql}】。errno:【" . $mysqli->errno . "】 error:【" . $mysqli->error . "】", "db_error");
            if ($mysqli->errno == 2013 || $mysqli->errno == 2006) {
                $mysqli->close();
                $mysqli = null;
                iGlobal::set("pool_mysql", null); //关闭该进程的mysql连接
                //如果没有过限制循环次数，once again
                if ($chance > 0) {
                    $chance--;
                    $send_data = $this->_doSql($sql, $chance);
                }
            }
        } else {//检索语句将返回数组，有几条内容数组中就有几个元素，0条内容，0个元素
            $rows = array();
            while ($row = $ret->fetch_assoc()) {
                $rows[] = $row;
            }
            $send_data["rows"] = $rows;
            unset($send_data["insert_id"]);
            unset($send_data["affected_rows"]);
        }

        $mysqli_ex_end_time = microtime(TRUE);
        $spend_time = ($mysqli_ex_end_time - $mysqli_ex_begin_time) * 1000;
        $sql_spend_time_total = iGlobal::get("process_sql_spend_time_total", 0);
        $sql_spend_time_total += $spend_time;
        iGlobal::set("process_sql_spend_time_total", $sql_spend_time_total);
        $sql_times = iGlobal::get("process_sql_times", 0);
        $sql_times++;
        iGlobal::set("process_sql_times", $sql_times);
        $sql_spend_time_avg = $sql_spend_time_total / $sql_times;

        iLog::write("sql:" . $sql . "，执行数据库操作,耗时：{$spend_time}ms,进程数据库操作次数：{$sql_times},平均耗时：{$sql_spend_time_avg}ms", "db_sql_spend");
        self::$commands[] = $sql . "[fd][spt:{$spend_time}]";

        return $send_data;
    }

    /**
     * sql请求
     * @param string $sql
     * @param int/array $cache_time 数据缓存时间，0：不缓存//需要修改为数字形式和数组形式，数组形式提供{cache_time=有效时间,cache_index=缓存索引，方便其他地方更新或删除缓存,cache_method：存储方式,主要是操作redis，默认set}
     * @return mixed 成功返回true/数据库数据列表或空数组 失败返回false
     */
    public function _query($sql, $cache_time = null) {
        //记录最后一条sql和添加到总的sql集合
        $this->db_sql = $sql;

        //解析缓存参数cache_time
        //尝试读取sql缓存
        $cache_index = "sqlche_" . sha1($this->cache_mark . "_" . md5($sql));
        if (is_array($cache_time)) {
            if (isset($cache_time["cache_index"])) {
                $cache_index = $cache_time["cache_index"];
            }
            if (isset($cache_time["cache_time"])) {
                $cache_time = $cache_time["cache_time"];
            }
        }
        if ($cache_time === null) {
            $cache_time = (int) $this->cache_time;
        }
        if (is_numeric($cache_time) && $cache_time > 0) {
            $cache_ex_begin_time = microtime(TRUE);
            $ret = iCache::get($cache_index);
            $cache_ex_end_time = microtime(TRUE);
            if ($ret) {
                $cache_ex_end_time = microtime(TRUE);
                $spend_time = ($cache_ex_end_time - $cache_ex_begin_time) * 1000;
                $cache_spend_time_total = iGlobal::get("process_cache_spend_time_total", 0);
                $cache_spend_time_total += $spend_time;
                iGlobal::set("process_cache_spend_time_total", $cache_spend_time_total);
                $cache_times = iGlobal::get("process_cache_times", 0);
                $cache_times++;
                iGlobal::set("process_cache_times", $cache_times);
                $cache_spend_time_avg = $cache_spend_time_total / $cache_times;
                iLog::write("sql:" . $sql . "，从缓存获取,耗时：{$spend_time}ms,进程从缓存获取次数：{$cache_times},平均耗时：{$cache_spend_time_avg}ms", "db_sql_spend");
                self::$commands[] = $sql . "[fc][spt:{$spend_time}]";
                return $ret;
            }
        }
        if ($cache_time === "asyn") {
            $this->_doSql($sql, "asyn");
            return array("affected_rows" => 0, "insert_id" => 0);
        }
        //执行sql
        $ret = $this->_doSql($sql);
        if (is_array($ret)) {
            if (isset($ret["insert_id"])) {
                $this->insert_id = $ret["insert_id"];
            }
            if (isset($ret["affected_rows"])) {
                $this->affected_rows = $ret["affected_rows"];
            }
            if (isset($ret["rows"])) {
                $ret = $ret["rows"];
            }
        }
        //尝试缓存
        if ($cache_time > 0 && $ret !== FALSE) {
            iServer::taskfn(function()use($cache_index, $ret, $cache_time) {
                iCache::set($cache_index, $ret, $cache_time);
            });
        }

        return $ret;
    }

    /**
     * 获取操作数据库真实表名，增加分表判断，数据库表名末尾字母不能为数字，否则可能判断为自动id分表
     * @return string 返回数据库真实表名
     */
    public function _getTable() {
        $fb = "";
        $last_char_of_db_table = substr($this->db_table, -1);
        if ($this->fb_number > 0 && !is_numeric($last_char_of_db_table)) {
            $fb = "_" . floor($this->fb_id / $this->fb_number);
        }
        return $this->db_table . $fb;
    }

    /**
     * 设置表名
     * @param type $talbe_name
     * @return \App\Model
     */
    public function _setTable($talbe_name) {
        $this->db_table = $talbe_name;
        return $this;
    }

    /**
     * 格式化数据，确保数据库安全
     * @param array $data
     * @param string $type 格式化模式，insert or update
     * @return array
     */
    protected function _rule($data, $type = "insert") {
        $data = (array) $data;
        switch ($type) {
            case "insert":
                $data["create_at"] = iGlobal::get("TIME_NOW", 0);
                break;
            case "update":
                $data["update_at"] = iGlobal::get("TIME_NOW", 0);
                break;
            default:
        }
        //过滤非法字段
        $this->_filterFields($data);
        return $data;
    }

    /**
     * 过滤非法字段
     * @param array $data
     * @return type
     */
    protected function _filterFields(&$data) {
        $all_field = $this->getTableFields();
        foreach ($data as $k => $v) {
            if (!in_array($k, $all_field)) {
                $all_field_str = json_encode($all_field);
                iLog::write("非法字段{$k}被过滤，允许字段{$all_field_str}", "db_error");
                unset($data[$k]);
                continue;
            }
        }
    }

    /**
     * 获取数据库字段
     * @return type
     */
    protected function getTableFields() {
        $table_field_info = iGlobal::get("table_field_info_" . $this->db_table, null);
        $time_now = iGlobal::get("TIME_NOW", 0);
        if (!$table_field_info || $table_field_info["create_time"] - -60 < $time_now) {
            $table_name = $this->_getTable();
            $table_field_info = $this->_query("show full fields from " . $table_name);
            if ($table_field_info) {
                $table_field_info = array(
                    "create_time" => $time_now,
                    "field_info" => $table_field_info
                );
            } else {
                iLog::write("获取数据表{$table_name}字段信息失败", "db_error");
                return array();
            }

            iGlobal::set("table_field_info_" . $this->db_table, $table_field_info);
        }
        $all_field = array_column($table_field_info["field_info"], "Field");
        return $all_field;
    }

    /**
     * 条件转换
     * @param type $where 只接受一级数组条件
     * @return string 空或WHERE xxx
     * 
     *   $where = array(
     *       "name" => "liwei",
     *       1 => "or",
     *       "age" => array(
     *           "between" => [20, 30]
     *       ),
     *       "description" => array(
     *           "like",
     *           "%开发%"
     *       ),
     *       2 => array(
     *           "status" => 1
     *       )
     *   );
     * 
     */
    protected function _where($where, $WHERE_P = null) {
        $allow_filed = $this->getTableFields();
        if ($WHERE_P === null) {
            $WHERE_P = $this->_where($this->where, "");
            if ($WHERE_P) {
                $WHERE_P = " WHERE(" . $WHERE_P . ") AND ";
            } else {
                $WHERE_P = " WHERE ";
            }
        }
        if (is_numeric($where)) {
            $where = (int) $where;
            return $WHERE_P . "(`id`=" . $where . ")";
        } elseif (is_string($where) && $where) {
            return $WHERE_P . "(" . $where . ")";
        } elseif (is_array($where)) {
            $where_all_arr = array();
            $need_ljf = FALSE;
            $arrysf = array("and", "or", "AND", "OR");
            foreach ($where as $k => $v) {
                $k = preg_replace("/[^a-zA-Z0-9_]/", "", $k);
                if ($need_ljf) {
                    //需要连接符
                    if (is_numeric($k) || substr($k, 0, 1) === "_") {
                        if (in_array($v, $arrysf)) {
                            $where_all_arr[] = strtoupper($v);
                            $need_ljf = FALSE;
                            continue;
                        }
                    }
                    if ($where_all_arr && !in_array(end($where_all_arr), $arrysf)) {
                        $where_all_arr[] = "AND";
                    }

                    $need_ljf = FALSE;
                }

                if (is_numeric($k) || substr($k, 0, 1) === "_") {
                    if (is_array($v)) {
                        $v = $this->_where($v, "");
                    }
                    if (!is_string($v)) {
                        continue;
                    }
                    $where_all_arr[] = "($v)";
                } else {
                    if (!in_array($k, $allow_filed)) {
                        continue;
                    }
                    if (is_array($v) && isset($v[1])) {
                        $ysf = strtolower($v[0]);//一定是比较运算符
                        $nationv = $v[1];
                        $v[1] = $this->_sqlstr($v[1]);
                        switch ($ysf) {
                            case "=":
                            case ">":
                            case "<":
                            case ">=":
                            case "<=":
                            case "<>":
                                $where_all_arr[] = "`" . $k . "` " . $ysf . " " . (is_numeric($v[1]) ? $v[1] : "'{$v[1]}'");
                                break;
                            case "like":
                                $v[1] = $this->_sqlstr($nationv, "safe", array("%"));
                                $where_all_arr[] = "`" . $k . "` " . $ysf . " '" . $v[1] . "'";
                                break;
                            case "in":
                                if (is_string($v[1])) {
                                    $v[1] = explode(",", $v[1]);
                                }
                                if (isset($v[1]) && is_array($v[1])) {
                                    $new_v_arr = array();
                                    foreach ($v[1] as $vv) {
                                        if (is_numeric($vv)) {
                                            $new_v_arr[] = $vv;
                                        } else if (is_string($vv) && $vv) {
                                            $new_v_arr[] = "'" . $vv . "'";
                                        }
                                    }
                                    $where_all_arr[] = "`" . $k . "` " . $ysf . "(" . implode(",", $new_v_arr) . ")";
                                }
                                break;
                            case "between":
                                if (isset($v[1]) && is_array($v[1]) && $v[1][1]) {
                                    $p_isdate = "/^[1-9][0-9][0-9][0-9]-[0-9]{1,2}-[0-9]{1,2}( [0-9]{1,2}(:[0-9]{1,2}){1,2})?$/";
                                    $between_min = preg_match($p_isdate, (string) $v[1][0]) ? (string) $v[1][0] : (int) $v[1][0];
                                    $between_max = preg_match($p_isdate, (string) $v[1][1]) ? (string) $v[1][1] : (int) $v[1][1];
                                    $where_all_arr[] = "`" . $k . "` " . $ysf . " '{$between_min}' AND '{$between_max}'";
                                }
                                break;
                            default :
                                continue;
                        }
                    } else {
                        $v = $this->_sqlstr($v);
                        if (is_array($v)) {
                            $v = "";
                        }
                        $where_all_arr[] = "`" . $k . "`=" . (is_numeric($v) ? $v : "'$v'");
                    }
                }
                $need_ljf = TRUE;
            }
            if ($where_all_arr) {
                $where_all = $WHERE_P . "(" . implode(" ", $where_all_arr) . ")";
            } else {
                $where_all = $WHERE_P . "TRUE";
            }
            return $where_all;
        } else {
//            iLog::write("where格式错误;model:" . get_class($this) . ";where:" . json_encode($where), "db_error");
//            return "WHERE FALSE";
            return "";
        }
    }

    /**
     * sql变量转换
     * @param mixed $var                   转换的变量,可以是字符串或者数组
     * @param string $model                safe/nation,指定转换为安全字符还是还原为原始字符
     * @param array $left                  保留不转化的字符串
     * @return mixed                       返回转换后的结果，$var 为数组时，返回数组；为非数组时返回字符串（非字符串类型将被强制转换为字符串）
     */
    protected function _sqlstr($var, $model = "safe", $left = array()) {
        static $safe_vars = array('व', 'र', 'न', 'झ');
        static $nation_vars = array("'", "%", "\\", "#");
        if (is_array($var)) {
            $ret = array();
            foreach ($var as $vark => $varv) {
                $ret[$vark] = self::_sqlstr($varv, $model, $left);
            }
            return $ret;
        } else {
            foreach ($left as $left_one) {
                $k = array_search($left_one, $nation_vars);
                if ($k !== FALSE) {
                    unset($nation_vars[$k]);
                    unset($safe_vars[$k]);
                }
            }
            if ($model == "safe") {//安全模式===》输出数据严格禁止单引号（’），百分号（%），转义符（\）,井号（#）
                $var = strval($var);
                return str_replace($nation_vars, $safe_vars, $var);
            } else {//原始模式
                $var = str_replace("[:backslash ]", "\\", strval($var));
                $ret = htmlspecialchars_decode(str_replace($safe_vars, $nation_vars, strval($var)));
                return $ret;
            }
        }
    }

    /**
     * 使用$value替换irow
     * @param array/string $where
     * @param array $values
     */
    private function _replaceIrowKv(&$where, $values) {
        if (is_array($where)) {
            foreach ($where as $k => $v) {
                $this->_replaceIrowKv($where[$k], $values);
            }
        } else {
            if (preg_match_all("/(@irow.([a-z_]+))/", $where, $matches, PREG_SET_ORDER) > 0) {
                foreach ($matches as $match) {
                    $v = isset($values[$match[2]]) ? $this->_sqlstr($values[$match[2]]) : '';
                    if (intval($v) != $v) {
                        $v = "'" . $v . "'";
                    }
                    $where = str_replace($match[0], $v, $where);
                }
            }
        }
    }

    /**
     * 获取模型对象，如果没有特殊声明，这回创建imodel对象，并设置表名
     * @param type $name
     * @return type
     */
    public static function getModelObj($name) {
        $model_name = ucfirst($name);
        if (!isset(self::$modelObjs[$model_name])) {
            $class_name = "Model\\" . $model_name;

            if (substr($model_name, 0, 1) !== "_" && class_exists($class_name)) {
                self::$modelObjs[$model_name] = new $class_name();
            } else {
                self::$modelObjs[$model_name] = new iModel($model_name);
            }
        }
        return self::$modelObjs[$model_name];
    }

    /**
     * 开启事务
     */
    static public function _begin() {
        $model = new iModel();
        $model->_doSql("begin");
    }

    /**
     * 关闭事务
     */
    static public function _end() {
        $model = new iModel();
        $model->_doSql("end");
    }

}
