<?php

namespace App;

class Model {

//数据库模型
    protected $pool_db = null;
    protected $list_cache_time = 0; //列表缓存时间
    public $db_sql = "";
    public $affected_rows = 0;
    public $insert_id = null;
    //具体模型需要声明
    protected $cur_pool_name = "v3"; //选择数据库连接池
    protected $db_table = ""; //表名称：必填
    protected $fb_number = 0; //多少id进行分表，0表示不分表
    public $fb_id = ""; //当前分表标识id，必须本表存在

    public function __construct($pool_name = null, $talbe_name = null) {
        if (is_string($pool_name)) {
            $this->cur_pool_name = $pool_name;
        }
        if (is_string($talbe_name)) {
            $this->db_table = $talbe_name;
        }
        $this->pool_db = new YYpool("mysql", $this->cur_pool_name);
        $this->pool_cache = new YYpool("redis", "data");
    }

    /**
     * sql变量转换
     * @param mixed $var                   转换的变量,可以是字符串或者数组
     * @param string $model                safe/nation,指定转换为安全字符还是还原为原始字符
     * @param array $left                  保留不转化的字符串
     * @return mixed                       返回转换后的结果，$var 为数组时，返回数组；为非数组时返回字符串（非字符串类型将被强制转换为字符串）
     */
    protected function sqlstr($var, $model = "safe", $left = array()) {
        static $safe_vars = array('[:single-quotes]', '[:percent]', '[:backslash]', '[:silo]');
        static $nation_vars = array("'", "%", "\\", "#");
        if (is_array($var)) {
            $ret = array();
            foreach ($var as $vark => $varv) {
                $ret[$vark] = self::sqlstr($varv, $model, $left);
            }
            return $ret;
        } else {
            foreach ($left as $left_one) {
                $k = array_search($left_one, $nation_vars);
                if ($k !== FALSE) {
                    unset($nation_vars[$k]);
                    unset($safe_vars[$k]);
                }
            }
            if ($model == "safe") {//安全模式===》输出数据严格禁止单引号（’），百分号（%），转义符（\）,井号（#）
                $var = strval($var);
                return str_replace($nation_vars, $safe_vars, $var);
            } else {//原始模式
                $var = str_replace("[:backslash ]", "\\", strval($var));
                $ret = htmlspecialchars_decode(str_replace($safe_vars, $nation_vars, strval($var)));
                return $ret;
            }
        }
    }

    /**
     * 记录日志
     * @param type $message
     * @param type $type
     */
    protected function log($message, $type = "common") {
        \App\YYlog::write($message, $type);
    }

    /**
     * ++++++++++++++++++++++++++++++++++++++++
     * db相关
     * ++++++++++++++++++++++++++++++++++++++++
     */

    /**
     * sql请求
     * @param string $sql
     * @param int $cache_time 数据缓存时间，0：不缓存//需要修改为数字形式和数组形式，数组形式提供{cache_time=有效时间,cache_index=缓存索引，方便其他地方更新或删除缓存,cache_method：存储方式,主要是操作redis，默认set}
     * @return mixed 成功返回true/数据库数据列表或空数组 失败返回false
     */
    public function _query($sql, $cache_time = 0) {
        //记录最后一条sql
        $this->db_sql = $sql;
        //尝试读取sql缓存
        if ($cache_time > 0) {
            $cache_index = sha1("sqlche_" . $this->cur_pool_name . "_" . md5($sql));
            $ret = $this->pool_cache->redis("get", $cache_index);
            if ($ret) {
                return $ret;
            }
        }
        //执行sql
        $ret = $this->pool_db->sync($sql);
        if (is_array($ret)) {
            if (isset($ret["insert_id"])) {
                $this->insert_id = $ret["insert_id"];
            }
            if (isset($ret["affected_rows"])) {
                $this->affected_rows = $ret["affected_rows"];
            }
            if (isset($ret["rows"])) {
                $ret = $ret["rows"];
            }
        }
        //尝试缓存
        if ($cache_time > 0 && $ret !== FALSE) {
            $this->pool_cache->redis("set", $cache_index, $ret, $cache_time);
        }
        return $ret;
    }

    /**
     * 数据库单表操作函数：插入
     * @param array $data 将要插入数据键值对
     * @return int/false 上一步 INSERT 操作产生的 ID
     */
    public function _insert($data = array()) {
        $table = $this->_getTable();
        $insert_column = "";
        $insert_value = "";
        $data = $this->rule($data, "insert");
        if (empty($data)) {
            return false;
        }
        foreach ($data as $k => $v) {
            $k = strval($k);
            $v = strval($v);
            $k = preg_replace("/[^a-zA-Z0-9_-]/", "", $k);
            $v = $this->sqlstr($v);
            $insert_column.="`{$k}`,";
            $insert_value.="'{$v}',";
        }
        $insert_column = trim($insert_column, ",");
        $insert_value = trim($insert_value, ",");
        $ret = FALSE;
        if ($insert_column && $insert_value) {
            $sql = "INSERT INTO `{$table}`({$insert_column})VALUE({$insert_value})";
            $ret_db = $this->_query($sql);
            if (is_array($ret_db)) {
                $ret = $ret_db["insert_id"];
            }
        } else {
            $this->log("插入数据格式错误：{$table}-->" . json_encode($data), "restdb");
        }
        return $ret;
    }

    /**
     * 数据库单表操作函数：删除
     * @param mixed $where 删除目标数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where （当为""时表示不设置WHERE条件） 
     * @return int/false 删除影响行数
     */
    public function _delete($where = "") {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $sql = "DELETE FROM `{$table}` {$where}";
        $ret = false;
        $ret_db = $this->_query($sql);
        if (is_array($ret_db)) {
            $ret = $ret_db["affected_rows"];
        }
        return $ret;
    }

    /**
     * 数据库单表操作：修改
     * @param array $data 将要修改数据键值对
     * @param mixed $where 修改目标数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where （当为""时表示不设置WHERE条件） 
     * @return int/false 修改影响行数
     */
    public function _update($data = array(), $where = "") {
        $table = $this->_getTable();
        $update_kv = "";
        $format_error = FALSE;
        $data = $this->rule($data, "update");
        if (empty($data)) {
            return false;
        }
        foreach ($data as $k => $v) {
            if (!is_string($k) || !(is_string($v) || is_numeric($v))) {
                $format_error = TRUE;
                break;
            }
            $k = preg_replace("/[^a-zA-Z0-9_-]/", "", $k);
            $v = $this->sqlstr($v);
            substr($v, 0, 1) == "`" || $v = "'{$v}'";
            $update_kv.= "`{$k}`={$v},";
        }
        $update_kv = trim($update_kv, ",");

        $where = $this->_where($where);
        $ret = false;
        if ($format_error == FALSE && $update_kv) {
            $sql = "UPDATE `{$table}` SET {$update_kv} {$where}";
            $ret_db = $this->_query($sql);
            if (is_array($ret_db)) {
                $ret = $ret_db["affected_rows"];
            }
        } else {
            $this->log("数据更新格式错误{$table}-->" . json_encode($data) . (string) $format_error . "k:" . (string) $k . json_encode($v), "restdb");
        }
        return $ret;
    }

    /**
     * 数据库单表操作：查询
     * @param mixed $where 查询条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param string $order 默认为null,表示：ORDER BY `id`；不为空时表示：ORDER BY $order
     * @param string $limit 格式例如0,10。表示从0开始最多10行数据，默认为null表示不设置LIMIT
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询,当为null是常用$this->list_cache_time
     * @param string $field 数据字段,默认为*
     * @return array array()/二维数据数组
     */
    public function _lists($where = "", $order = null, $limit = null, $cache_time = null, $field = "*") {
        $table = $this->_getTable();
        $where = $this->_where($where);
        if (preg_match("/([0-9]+[\s]*,[\s]*[0-9]+)|([0-9]+)/", $limit)) {
            $limit = "LIMIT " . $limit;
        } else {
            $limit = "";
        }

        if (!empty($order)) {
            $order = "ORDER BY " . $order;
        }
        $cache_time = $cache_time === null ? $this->list_cache_time : intval($cache_time);
        if (is_string($field) && $field !== "*" && !empty($field)) {
            $field = preg_replace("/[^`a-z0-9_,*]/", "", $field);
        } else {
            $field = "*";
        }
        if ($field !== "*") {
            $field_arr = explode(",", $field);
            $field = "`" . implode("`,`", $field_arr) . "`";
        }
        $sql = "SELECT $field FROM `{$table}` {$where} {$order} {$limit}";

        $lists = $this->_query($sql, $cache_time);
//        echo "<pre>";
        if (!is_array($lists)) {
            $lists = array();
        } else {
            foreach ($lists as $k => $v) {
                foreach ($v as $kk => $vv) {
                    $lists[$k][$kk] = $this->sqlstr($vv, "nation");
                }
            }
        }
        return $lists;
    }

    /**
     * 数据库单表操作：查询一个数据
     * @param mixed $where 查询条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param null $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @param string $field 数据字段,默认为*
     * @return array array()/二维数据数组
     */
    public function _detail($where, $cache_time = null, $field = "*") {
        $ret = $this->_lists($where, null, null, $cache_time, $field);
        if ($ret) {
            $ret = $ret[0];
        }
        return (array) $ret;
    }

    /**
     * 数据库单表操作：查询一个数据(_detail别名)
     * @param mixed $where 查询条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param null $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @param string $field 数据字段,默认为*
     * @return array array()/二维数据数组
     */
    public function _read($where, $cache_time = null, $field = "*") {
        return $this->_detail($where, $cache_time, $field);
    }

    /**
     * 数据库单表操作：统计数量
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _count($where = "", $cache_time = null) {
        $table = $this->_getTable();
        $where = $this->_where($where);
        $cache_time = intval($cache_time);
        $sql = "SELECT count(id) as num FROM `{$table}` {$where}";
        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $count = 0;
        } else {
            $count = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $count;
    }

    /**
     * 数据库单表操作：统计数量,sum
     * @param mixed $where 统计字段
     * @param mixed $where 统计数据行条件：当为数字时表示WHERE `id`=$where,当为string时表示 WHERE $where（当为""时表示不设置WHERE条件）
     * @param int $cache_time 数据缓存时间，期间从缓存读取，不经过数据库查询
     * @return int 统计数量
     */
    public function _sum($field, $where = "", $cache_time = null) {
        $table = $this->_getTable();
        if (is_numeric($where)) {
            $where = "WHERE `id`=" . $where;
        } else if (!empty($where)) {
            $where = "WHERE " . $where;
        }
        $cache_time = intval($cache_time);
        $sql = "SELECT sum({$field}) as num FROM `{$table}` {$where}";

        $lists = $this->_query($sql, $cache_time);
        if (!is_array($lists)) {
            $count = 0;
        } else {
            $count = isset($lists[0]["num"]) ? $lists[0]["num"] : 0;
        }
        return $count;
    }

    /**
     * 获取操作数据库真实表名，增加分表判断，数据库表名末尾字母不能为数字，否则可能判断为自动id分表
     * @return string 返回数据库真实表名
     */
    public function _getTable() {
        $fb = "";
        $last_char_of_db_table = substr($this->db_table, -1);
        if ($this->fb_number > 0 && !is_numeric($last_char_of_db_table)) {
            $fb = "_" . floor($this->fb_id / $this->fb_number);
        }
        return $this->db_table . $fb;
    }

    /**
     * 设置表名
     * @param type $talbe_name
     * @return \App\Model
     */
    public function _setTable($talbe_name) {
        $this->db_table = $talbe_name;
        return $this;
    }

    /**
     * 格式化数据，确保数据库安全
     * @param array $data
     * @param string $type 格式化模式，insert or update
     * @return array
     */
    protected function rule($data, $type = "insert") {
        return (array) $data;
    }

    /**
     * 条件转换
     * @param type $where 值接受一级数组条件
     * @return string 空或WHERE xxx
     * 
     *   $where = array(
     *       "name" => "liwei",
     *       1 => "or",
     *       "age" => array(
     *           "between" => [20, 30]
     *       ),
     *       "description" => array(
     *           "like",
     *           "%开发%"
     *       ),
     *       2 => array(
     *           "status" => 1
     *       )
     *   );
     * 
     */
    protected function _where($where, $WHERE_P = " WHERE ") {
        if (is_numeric($where)) {
            $where = (int) $where;
            return $WHERE_P . "`id`=$where";
        } elseif (is_string($where) && $where) {
            return $WHERE_P . $where;
        } elseif (is_array($where)) {
            $where_all_arr = array();
            $need_ljf = FALSE;
            foreach ($where as $k => $v) {
                $k = preg_replace("/[^a-zA-Z0-9_]/", "", $k);
                if ($need_ljf) {
                    //需要连接符
                    if (is_numeric($k) || substr($k, 0, 1) === "_") {
                        if (in_array($v, array("and", "or", "AND", "OR"))) {
                            $where_all_arr[] = strtoupper($v);
                            $need_ljf = FALSE;
                            continue;
                        }
                    }
                    $where_all_arr[] = "AND";
                    $need_ljf = FALSE;
                }

                if (is_numeric($k) || substr($k, 0, 1) === "_") {
                    if (is_array($v)) {
                        $v = $this->_where($v, "");
                    }
                    if (!is_string($v)) {
                        continue;
                    }
//                    $where_all_arr[] = "and";
                    $where_all_arr[] = "($v)";
                } else {
                    if (is_array($v) && isset($v[1])) {
                        $ysf = strtolower($v[0]);
                        $nationv = $v[1];
                        $v[1] = $this->sqlstr($v[1]);
                        switch ($ysf) {
                            case "=":
                            case ">":
                            case "<":
                            case ">=":
                            case "<=":
                            case "<>":
                                $where_all_arr[] = "`" . $k . "` " . $ysf . " " . (is_numeric($v[1]) ? $v[1] : "'{$v[1]}'");
                                break;
                            case "like":
                                $v[1] = $this->sqlstr($nationv, "safe", array("%"));
                                $where_all_arr[] = "`" . $k . "` " . $ysf . " '" . $v[1] . "'";
                                break;
                            case "in":
                                if (isset($v[1]) && is_array($v[1])) {
                                    $new_v_arr = array();
                                    foreach ($v[1] as $vv) {
                                        if (is_numeric($vv)) {
                                            $new_v_arr[] = $vv;
                                        } else {
                                            $new_v_arr[] = "'" . $vv . "'";
                                        }
                                    }
                                    $where_all_arr[] = "`" . $k . "` " . $ysf . "(" . implode(",", $new_v_arr) . ")";
                                }
                                break;
                            case "between":
                                if (isset($v[1]) && is_array($v[1]) && $v[1][1]) {
                                    $between_min = (int) $v[1][0];
                                    $between_max = (int) $v[1][1];
                                    $where_all_arr[] = "`" . $k . "` " . $ysf . "{$between_min} AND {$between_max}";
                                }
                                break;
                            default :
                                continue;
                        }
                    } else {
                        $v = $this->sqlstr($v);
                        if (is_array($v)) {
                            $v = "";
                        }
                        $where_all_arr[] = "`" . $k . "`=" . (is_numeric($v) ? $v : "'$v'");
                    }
                }
                $need_ljf = TRUE;
            }
//            if ($need_ljf === FALSE) {
//                array_pop($where_all_arr);
//            }
            return $where_all_arr ? $WHERE_P . implode(" ", $where_all_arr) : "";
        } else {
            return "";
        }
    }

}
