<?php

class YYtoken {

    /**
     * 创建唯一token
     * 如何保证唯一：
     * 1.
     * token有device和appid为基础生成，保证正常情况下access_token对单一设备产生，
     * 并使用uniqid和随机数，保证在时间维度上token不重复
     * 2.token源，使用128位随机字符，算法对外公开也无法生成重复token，防止非法用户通过撞击生成与某正常用户相同的token凭证
     * 3.通过https协议保证token不在中间网络传输过程中被盗取
     * 4.通过使用老的token刷新新的token方式，定时刷新token,保证用户会话安全
     * 5.token只做算法验证，会话登陆依靠token和uid建立联系实现，未登陆用户会话过期时间为600秒，需要不断续期
     * 保证：在token请求被攻击情况下：每秒生成1万token,600秒最多产生600万垃圾token，同时600万token过期，
     * 每个垃圾token占用1k，则最高垃圾token对会话redis占用6G,但并发和带宽首先达到评价，不会出现会话崩溃
     * @param type $appid
     * @param type $secret
     * @param type $device
     * @return type
     */
    static function create($appid, $secret, $device) {
        $access_token = $device . "##" . $appid . "##" . $secret . "##" . uniqid();
        for ($i = 0; $i < 128; $i++) {
            $access_token.=chr(rand(33, 126));
        }
        return $appid . "##" . $device . "##" . md5(md5($access_token));
    }

}
