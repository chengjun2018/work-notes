<?php

class iCache {

    static $commands = array();

    /**
     * 缓存redis操作
     * @global type $php
     * @return boolean
     */
    static function redis() {
        $params = func_get_args();
        $method = array_shift($params);
        //查看连接是否存在，如果不存在则创建
        $pool = iGlobal::get("pool_cache");
        if (empty($pool)) {
            $pool = self::createRedis();
            if ($pool === null) {
                return false;
            }
            iGlobal::set("pool_cache", $pool);
        }
        //查看连接是否断开，如果断开需要重新连接
        $ping = $pool->ping();
        if ($ping != "+PONG") {
            $pool->close();
            $pool = self::createRedis();
            if ($pool === null) {
                return false;
            }
            iGlobal::set("pool_cache", $pool);
        }

        //访问redis
        $redis_ex_begin_time = microtime(TRUE);
        $ret = call_user_func_array(array($pool, $method), $params);
        $redis_ex_end_time = microtime(TRUE);
        $spend_time = ($redis_ex_end_time - $redis_ex_begin_time) * 1000;
        self::$commands[] = $method . "|" . json_encode($params, JSON_UNESCAPED_UNICODE) . "[fd][spt:{$spend_time}]";
        return $ret;
    }

    /**
     * 获取缓存
     * @param string $name 缓存名
     * @return mixed 缓存是什么类型就返回什么类型
     */
    static function get($name, $default = null) {
        $ret = self::redis("get", $name);
        if ($ret === null) {
            return $default;
        } else {
            $is_json = in_array(substr($ret, 0, 1), array("{", "["));
            if ($is_json) {
                return json_decode($ret, true) ?: $ret;
            } else {
                return $ret;
            }
        }
    }

    /**
     * 设置缓存
     * @param string $name 缓存名
     * @param mixed $data 缓存数据
     * @return bool 成功返回true,失败返回false
     */
    static function set($name, $data, $time = 86400) {
        if (is_array($data)) {
            $data = json_encode($data, JSON_UNESCAPED_UNICODE);
        }
        return self::redis("set", $name, $data, $time);
    }

    /**
     * 删除缓存
     * @param string $name 删除缓存名
     * @return bool 成功返回true,失败返回false
     */
    static function delete($name) {
        return self::redis("delete", $name);
    }

    /**
     * 创建redis连接
     * @return \redis
     */
    static function createRedis() {
        for ($i = 0; $i < 10; $i++) {
            $redis = new redis();
            $is_connect = $redis->pconnect(CACHE_HOST, CACHE_PORT);
            if (empty($is_connect)) {
                $redis->close();
                $str_logs = "redis连接失败，进行重连,"
                        . "连接参数：host:" . CACHE_HOST
                        . "；port:" . CACHE_PORT
                        . "；password:" . CACHE_PASSWORD;
                iLog::write($str_logs, "reids");
            } else {
                return $redis;
            }
        }

        $str_logs = "Warning:redis重连10次失败，将放弃返回失败redis操作失败，"
                . "连接参数：host:" . CACHE_HOST
                . "；port:" . CACHE_PORT
                . "；password:" . CACHE_PASSWORD;
        iLog::write($str_logs, "reids");

        return null;
    }

}
