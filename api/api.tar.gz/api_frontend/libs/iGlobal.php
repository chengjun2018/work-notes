<?php

/**
 * 进程变量，除非自己释放，否则将一直保持，主要用于保持连接
 */
class iGlobal {

    public static $global = array();
    public static $global_cache_time = array();

    /**
     * 获取进程作用域变量
     * @param type $name
     * @param type $default
     * @param type $cache_time 缓存时间，如果进程缓存过期
     * @param bool $try_cache 是否尝试从缓存获取
     * @return type
     */
    static public function get($name, $default = null, $cache_time = 0, $try_cache = false) {
        if (isset(self::$global[$name])) {
            $cache_time = intval($cache_time);
            if ($cache_time === 0) {
                return self::$global[$name];
            } else {
                $cache_last_time = isset(self::$global_cache_time[$name]) ? self::$global_cache_time[$name] : 0;
                $now = time();
                if ($now - $cache_last_time > $cache_time) {
                    return $try_cache ? iCache::get("iGlobalVar_" . $name, $default) : $default;
                } else {
                    return self::$global[$name];
                }
            }
        } else {
            return $default;
        }
    }

    /**
     * 设置进程作用于变量
     * @param type $name
     * @param type $value
     */
    static public function set($name, $value) {
        self::$global[$name] = $value;
        self::$global_cache_time[$name] = time();
    }

    /**
     * 销毁进程作用域变量
     * @param type $name
     */
    static public function delete($name) {
        if (isset(self::$global[$name])) {
            unset(self::$global[$name]);
        }
    }

}
