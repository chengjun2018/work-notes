<?php

require_once __DIR__.'/../vendor/autoload.php';

use PhpES\EsClient\Client;
use PhpEs\EsClient\DSLBuilder;

/**
 * ES操作类
 * Class iElasticsearch
 */

class iElasticsearch  {

    public $host = [
        'host' => '192.168.1.207',
        'port' => '9200'
    ];

    public $client = null;

    public function __construct()
    {
        if (null == $this->client) {
            $this->client = new Client();
            $this->client->setHost('192.168.1.207', 9200);
        }
    }


    public function searchAdminLogs($action='', $time=[], $ip='') {
        $res = $this->client
//            ->select('*')
            ->select(array('id', 'from_username','ip'))
            ->from('logs', 'admin_logs')
//            ->orWhereBegin()
//            ->where('actions',DSLBuilder::OPERATOR_EQ,'/admin/user/add_user')
//            ->where('actions',DSLBuilder::OPERATOR_EQ,'/admin/user/reg')
//            ->where('actions',DSLBuilder::OPERATOR_EQ,'/admin/user/login')
//            ->where('actions',DSLBuilder::OPERATOR_EQ,'/admin/user/find_password')
//            ->orWhereEnd()
//            ->where('ip',DSLBuilder::OPERATOR_EQ,'192.168.1.146')
//            ->match('from_username', 'adm',DSLBuilder::MATCH_TYPE_PHRASE_PREFIX, DSLBuilder::MATCH)
//            ->match('desc','1','phrase','should')
//            ->where('id', 'between', array(2000, 999999999999999))
//            ->match('title', '中国')
//            ->match('title', '中国', DSLBuilder::MATCH_TYPE_PHRASE, DSLBuilder::SHOULD)
//            ->match('content', '中国', DSLBuilder::MATCH_TYPE_PHRASE, DSLBuilder::SHOULD)
//            ->orderBy('id', 'DESC')
//            ->groupBy('id', '_count', 'desc')
            ->offset(0)
            ->limit(20)
            ->debug()
//            ->orderBy('id','desc')
            ->search();
        print_r($res->getFormat());
    }


    function getUnquireId() {
        return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }


}



