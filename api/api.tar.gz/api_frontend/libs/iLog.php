<?php

/**
 * 日志
 */
class iLog {

    /**
     * 记录日志
     * @param string $log     记录日志内容
     * @return boolean        记录失败返回false,成功返回true
     */
    static function write($log, $type = "common") {
        $route = iGlobal::get("ACCESS_ROUTE","");
        $path_log = PATH_RUNTIME . "/logs/";
        if (!is_dir($path_log)) {
            mkdir($path_log);
        }
        iServer::taskfn(function() use ($log,$type,$route,$path_log) {//避免当前堵塞
            if (!is_string($log)) {
                $log = json_encode($log);
            }
            $time = time();
            $day = date("Y-m-d", $time);

            $date = date('Y-m-d H:i:s', $time);
            $log = 'route:' . $route . '====>' . $log . "";
            $log_str = $time . '====>' . $date . '====>' . $log . "\r\n";
            
            $log_file = $path_log . 'Log-' . $type . '-' . $day . '.php';
            if (!is_file($log_file)) {
                $createlog_ret = is_dir(dirname($log_file)) && file_put_contents($log_file, "Log start\r\n");
                if ($createlog_ret == FALSE) {
                    return FALSE;
                }
            }

            $log_text = (string) file_get_contents($log_file);
            $log_pos = strrpos($log_text, $log);
            if ($log_pos !== FALSE) {
                $log_time_pos = $log_pos - 39;
                if ($log_time_pos >= 0) {//可以更新日志时间，但应该查看是否过期
                    $log_time = substr($log_text, $log_time_pos, 10);
                    $log_time = intval($log_time);
                    $log_expire_time = $log_time + 60;
                    if ($time > $log_expire_time) {//日志过期，则更新时间
                        $new_log_text = substr_replace($log_text, $time . '====>' . $date, $log_time_pos, 34);
                        file_put_contents($log_file, $new_log_text);
                    }
                }
            } else {
                file_put_contents($log_file, $log_str, FILE_APPEND);
            }
            return TRUE;
        });
    }

}
