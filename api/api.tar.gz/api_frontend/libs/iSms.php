<?php

//require_once __DIR__ . '/alidayu/TopSdk.php';

class iSms {

//    const PUSH_CONTENT_USER = "559484";
//    // 密码MD5加密大写后有效
//    const PUSH_CONTENT_PASS = "dx2017!@#$";
//    // 登陆后查看配置
//    //http://dx.106msg.com
//    const GWID = "c82d243";

    const ALIDAYU_KEY = '23852425';
    const ALIDAYU_SECRET = '4c15a83c196dfbb3ed1c83cca1f76158';
    const EXPIRE_TIME_DISTANCE = 60; //超过这个间隔时间可以重发，短信有效期为10分钟

    /**
     * @param $phone
     * @return mixed|\ResultSet|\SimpleXMLElement
     * 阿里大于发送code短信
     */

    public static function send($type, $phone) {
//        if (substr($phone, 0, 1) === "0" || true) {
//            $sms_code = 6666;
//            $is_success = true;
//        } else {
//            $sms_code = rand(1000, 9999);
//            $c = new \TopClient();
//            $c->appkey = self::ALIDAYU_KEY;
//            $c->secretKey = self::ALIDAYU_SECRET;
//            $req = new \AlibabaAliqinFcSmsNumSendRequest;
//            $req->setExtend("123456");
//            $req->setSmsType("normal");
//            $req->setSmsFreeSignName("xxx");
//            $req->setSmsParam("{\"code\":\"" . $sms_code . "\",\"valid_minute\":\"10\",\"tel\":\"18681636591\"}");
//            $req->setRecNum($phone);
//            $req->setSmsTemplateCode("SMS_67780222");
//            $resp = $c->execute($req);
//            // 发送成功
//            $is_success = $resp->result->success;
//        }
//        $now = time();
//        if ($is_success) {
//            $sms_code_info_index = "smscodeinfo_" . $type . "_" . $phone;
//            iCache::set($sms_code_info_index, array('sms_code' => $sms_code, 'send_time' => $now), 600);
//            return array("status" => true, "msg" => "短信发送成功", "sms_code" => $sms_code, "left_time" => self::EXPIRE_TIME_DISTANCE, "expire_time" => $now + self::EXPIRE_TIME_DISTANCE);
//        } else {
//            return array("status" => false, "msg" => $resp->sub_msg, "sms_code" => $sms_code, "left_time" => self::EXPIRE_TIME_DISTANCE, "expire_time" => $now + self::EXPIRE_TIME_DISTANCE);
//        }
        return false;
    }

    /**
     * 获取发送的验证码信息
     * @param string $type login/register/bind_phone
     * @param number $phone
     * @return array/null
     */
    public static function getSend($type, $phone) {
        $sms_code_info_index = "smscodeinfo_" . $type . "_" . $phone;
        $ret = iCache::get($sms_code_info_index);
        if ($ret) {
            $now = time();
            $left_time = self::EXPIRE_TIME_DISTANCE - ($now - $ret["send_time"]);
            $ret["left_time"] = $left_time;
        }
        return $ret;
    }

}
