<?php

require_once __DIR__ . '/../vendor/autoload.php';

/**
 * Class iElasticBuild
 * ES操作类
 *
 */
class iElasticBuild
{

    public $params;
    public $client = null;

    public function __construct()
    {
        if (null == $this->client) {
            $this->params['hosts'] = array(
                '192.168.1.207:9200'
            );
            $this->client = Elasticsearch\ClientBuilder::create()->setHosts(['192.168.1.207:9200'])->build();
        }
    }

    public function create_db($index)
    {

        if (!$index) return false;

        $params = [
            'index' => $index,
            'body' => [
                'settings' => [
                    'number_of_shards' => 1,
                    'number_of_replicas' => 0
                ]
            ]
        ];

        try {
            return $this->client->indices()->create($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }

    }

    //获取索引信息
    public function get_index($index) {

        if (!$index) return false;

        $params = [
            'index' => $index,
            'client' => [
                'ignore' => 404
            ]
        ];

        try {
            return $this->client->indices()->getSettings($params);//获取库索引设置
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    public function delete_db($index)
    {

        if (!$index) return false;

        $deleteParams = [
            'index' => $index
        ];
        try {
            return $this->client->indices()->delete($deleteParams);
        } catch (\Exception $e) {
            return ['errpr' => $e->getMessage()];
        }
    }

    //创建字段
    public function create_mappings($index, $type, $filed)
    {
        if (!$index || !$type || empty($filed)) return false;

        $params = [
            'index' => $index,
            'type' => $type,
            'body' => [
                $type => [
                    '_source' => [
                        'enabled' => true
                    ],
                    '_all'=>[   //  是否开启所有字段的检索
                        'enabled' => false
                    ],
                    'properties' => $filed
                ]
            ]
        ];

        try {
            return $this->client->indices()->putMapping($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }


    // 查看字段
    public function get_mapping($index, $type)
    {
        if (!$type || !$index) return false;

        $params = [
            'index' => $index,
            'type' => $type
        ];
        try {
            return $this->client->indices()->getMapping($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }


    // 添加数据
    public function add_doc($index, $type, $id, $doc)
    {
        $params = [
            'index' => $index,
            'type' => $type,
//            'id' => $id,
            'body' => $doc
        ];
        $params['body']['params'] = json_encode($doc['params']);

        try {
            return $this->client->index($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 判断文档存在
    public function exists_doc($index, $type, $id = 1)
    {
        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id
        ];

        try {
            return $this->client->exists($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }


    // 获取文档
    public function get_doc($index, $type, $id = 0)
    {
        if (!$index || !$type || !$id) return false;

        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id // es 自动生成/自己录入的
        ];
        try {
            return $this->client->get($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 更新文档
    public function update_doc($index, $type, $id = 0, $data = [])
    {

        if (!$index || !$type || !$id || empty($data)) return false;

        // 可以灵活添加新字段,最好不要乱添加
        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id,
            'body' => [
                'doc' => $data
            ]
        ];

        try {
            return $this->client->update($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 删除文档
    public function delete_doc($index, $type, $id = 0)
    {

        if (!$index || !$type || !$id) return false;
        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id
        ];

        try {
            return $this->client->delete($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }

    }

    // 清空文档
    public function clean_doc($index, $type)
    {

        if (!$index || !$type) return false;
        $params = [
            'index' => $index,
            'type' => $type,
            'body' => [
                'query' => ['match_all'=>(object)[],]
            ]
        ];

        try {
            return $this->client->deleteByQuery($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }

    }

    // 查询文档 (分页，排序，权重，过滤)
    public function search_doc($index, $type, $keywords, $from = 0, $size = 2)
    {

        if (!$index || !$type) return false;

        $params = [
            'index' => $index,
            'type' => $type,
            'body' => [
                'query' => [
                    'bool' => [
                        'should' => [
                            ['match' => ['title' => [
                                'query' => $keywords,
                                'boost' => 3, // 权重大
                            ]]],
                            ['match' => ['content' => [
                                'query' => $keywords,
                                'boost' => 2,
                            ]]],
                        ],
                    ],
                ],
                'sort' => ['price' => ['order' => 'desc']]
                , 'from' => $from, 'size' => $size
            ]
        ];

        try {
            return $this->client->search($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }

    }

    /**
     * 记录后台用户操作日志
     * @param array $data
     * @return bool
     * @throws Exception
     */
    public function insAdminLogs($data=[]) {

        if (empty($data))
            return false;

        if (empty($data['ip']) || empty($data['desc']) || empty($data['action']) || empty($data['post']))
            return false;

        $params = [
            'index' => 'admin_logs',
            'type' => 'logs',
            'body' => $data
        ];
        $params['body']['post'] = json_encode($params['post']);

        try {
            $res = $this->client->index($params);
            unset($data, $params);
            if ($res['_id']) return $res['_id'];
            return false;
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            iLog::write($msg,'es_error');
            unset($data, $params, $msg);
            return false;
        }

    }


    /**
     * 记录前台用户操作日志
     * @param array $data
     * @return bool
     * @throws Exception
     */
    public function insFrontendLogs($data=[]) {

        if (empty($data))
            return false;

        if (empty($data['ip']) || empty($data['desc']) || empty($data['action']) || empty($data['post']) || empty($data['userid']) || empty($data['username']) || empty($data['device']))
            return false;

        $params = [
            'index' => 'frontend_log',
            'type' => 'logs',
            'body' => $data
        ];
        $params['body']['post'] = json_encode($data['post']);

        try {
            $res = $this->client->index($params);
            unset($data, $params);
            if ($res['_id']) return $res['_id'];
            return false;
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            iLog::write($msg,'es_error');
            unset($data, $params, $msg);
            return false;
        }

    }


    /**
     * 记录系统错误日志
     * @param array $data
     * @return bool
     * @throws Exception
     */
    public function insErrorLogs($data=[]) {

        if (empty($data))
            return false;

        if (empty($data['desc']) || empty($data['action']))
            return false;

        $params = [
            'index' => 'error_log',
            'type' => 'logs',
            'body' => $data
        ];

        try {
            $res = $this->client->index($params);
            unset($data, $params);
            if ($res['_id']) return $res['_id'];
            return false;
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            iLog::write($msg,'es_error');
            unset($data, $params, $msg);
            return false;
        }

    }


    //批量插入测试
    public function batch_insert() {
//        $a = 11000000;
        $a = 0;
        for($i=1;$i<=10;$i++) {
            $b = $a + (($i - 1) * 100000);

            iServer::taskfn(function () use ($b){
                $stime=microtime(true); #获取程序开始执行的时间

                $client = Elasticsearch\ClientBuilder::create()->setHosts(['192.168.1.207:9200'])->build();

//                $params = [
//                    'index' => 'logs',
//                    'type' => 'admin_logs',
//                ];
                for ($j=1;$j<=100000;$j++) {
                    $id = (int) $b+=1;
                    $params['body'][] = [
                        'index' => [
                            '_index' => 'logs',
                            '_type' => 'admin_logs',
                            '_id'  =>$id
                        ]
                    ];
                    $params['body'][] = [
                        'id' => $id,
                        'actions' => '/admin/user/reg',
                        'params' => json_encode(['username'=>'admin','password'=>'123qwe']),
                        'from_username' => 'admin',
                        'to_username' => '',
                        'desc' => '用户注册',
                        'time' => date('Y-m-d H:i:s',time()),
                        'ip'=>'192.168.1.146'
                    ];
                }

                try {
                    $ret = $client->bulk($params);
                    unset($params,$client);

                    #你写的php代码
                    $etime=microtime(true); #获取程序执行结束的时间
                    $total=$etime-$stime;   #计算差值
                    iLog::write($total."\r\n","es");
                } catch (\Exception $e) {
                    unset($params,$client);
                    $msg = $e->getMessage();
                    $msg = json_decode($msg, true);
                    iLog::write($msg,"eserror");
                    return $msg;
                }

            });

        }

    }


    public function getNum() {


        $a = 1000000;
        for($i=1;$i<=10;$i++) {
            $b = $a + (($i - 1) * 100000);

            $str = '';
            for ($j=1;$j<=100000;$j++) {
                $id = (int) $b+=1;
                $str .= "{$id}\r\n";
//                echo $id."<br />";
//                iLog::write($id."\r\n","es");
            }

            iLog::write($str."\r\n","es");
        }


    }


    function getUnquireId() {
        return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }
}





