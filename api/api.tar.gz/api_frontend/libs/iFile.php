<?php

class iFile {

    /**
     * 多层目录创建
     * @param string $dir 目录路径
     * @return boolean 成功返回true,失败返回false
     */
    static function mkdirs($dir, $mode = 0777) {
        if (!is_string($dir) || trim($dir) === "") {
            return false;
        }
        if (!file_exists($dir)) {
            if (!self::mkdirs(dirname($dir), $mode)) {
                return false;
            }
            if (!@mkdir($dir, $mode)) {
                return false;
            }
        }
        return true;
    }

}
