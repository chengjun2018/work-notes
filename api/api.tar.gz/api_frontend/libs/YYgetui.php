<?php

namespace App;

require_once(rtrim(__DIR__, "/") . '/os-php-4.0.1.5/IGt.Push.php');
require_once(rtrim(__DIR__, "/") . '/os-php-4.0.1.5/igetui/IGt.AppMessage.php');
require_once(rtrim(__DIR__, "/") . '/os-php-4.0.1.5/igetui/IGt.APNPayload.php');
require_once(rtrim(__DIR__, "/") . '/os-php-4.0.1.5/igetui/template/IGt.BaseTemplate.php');
require_once(rtrim(__DIR__, "/") . '/os-php-4.0.1.5/IGt.Batch.php');
require_once(rtrim(__DIR__, "/") . '/os-php-4.0.1.5/igetui/utils/AppConditions.php');

/**
 * Class Push
 * 个推
 */
class YYgetui {
    //HOST
    protected $HOST = 'http://sdk.open.api.igexin.com/apiex.htm';
    //用于鉴定身份是否合法，预先分配的第三方应用对应的Key，是您的应用与SDK通信的标识之一。
    protected $APPID = 'PGcswwrmAz5tQPVyDc79v5';
    //个推服务端API鉴权码，用于验证调用方合法性。在调用个推服务端API时需要提供.
    protected $APPKEY = 'WlWkkGo4hu5XgXejbThx58';
    //第三方客户端个推集成鉴权码，用于验证第三方合法性。在客户端集成SDK时需要提供。
    protected $APPSECRET = 'dLhbKrhckW57rEGlWyyulA';
    //由IGetui管理页面生成，是您的应用与SDK通信的标识之一，每个应用都对应一个唯一的AppID。
    protected $MASTERSECRET = 'xqOrm70s1v8d1tJFJkVj34';
    //通知应用logo名称
    protected $APPLOGO = 'jiaoyoufang.png';
    //通知应用logo url地址
    protected $APPLOGOURL = 'http://bazhua.igexin.com/file/2017/3/6/17/14914718967310481.txt';

    function tcToCient($content, $client_id) {
        $igt = new \IGeTui($this->HOST, $this->APPKEY, $this->MASTERSECRET);

        $template = new \IGtTransmissionTemplate();
        $template->set_appId($this->APPID); //应用appid
        $template->set_appkey($this->APPKEY); //应用appkey

        $template->set_transmissionType(2); //收到消息是否立即启动应用：1为立即启动，2则广播等待客户端自启动
        $template->set_transmissionContent($content); //透传内容，不支持转义字符

        $time_now = time();
        $template->set_duration(date("Y-m-d H:i:s", $time_now), date("Y-m-d H:i:s", $time_now + 3600 * 24 * 7));

        //APN高级推送
        $apn = new \IGtAPNPayload();
        $apn->add_customMsg("payload", $content);
        //      $apn->contentAvailable=1;
        $apn->category = "ACTIONABLE";
        $template->set_apnInfo($apn);
        
        //定义"SingleMessage"
        $message = new \IGtSingleMessage();

        $message->set_isOffline(true); //是否离线
        $message->set_offlineExpireTime(3600 * 12 * 1000); //离线时间
        $message->set_data($template); //设置推送消息类型
        $message->set_PushNetWorkType(0); //设置是否根据WIFI推送消息，2为4G/3G/2G，1为wifi推送，0为不限制推送
        //接收方
        $target = new \IGtTarget();
        $target->set_appId($this->APPID);
        $target->set_clientId($client_id);

        try {
            $rep = $igt->pushMessageToSingle($message, $target);
        } catch (RequestException $e) {
            $requstId = $e->getRequestId();
            //失败时重发
            $rep = $igt->pushMessageToSingle($message, $target, $requstId);
        }
        return $rep;
    }

}
