<?php

class iUploadImg
{
    private $file;          //文件信息
    private $fileList;      //文件列表
    private $temFiles;      //上传的临时文件
    private $inputName;     //标签名称
    private $uploadPath;    //上传路径
    private $fileMaxSize;   //最大尺寸
    private $uploadFiles;   //上传文件
    //允许上传的文件类型
    private $allowExt = array('bmp', 'jpg', 'jpeg', 'png', 'gif');

    /**
     * ImageUploadTool constructor.
     * @param $temFile 传入 $_FILES
     * @param $inputName input标签的name属性
     * @param $uploadPath 文件上传路径
     */
    public function __construct($temFile, $inputName, $uploadPath)
    {
        $this->temFiles = $temFile;
        $this->inputName = $inputName;
        $this->uploadPath = $uploadPath . (substr($uploadPath, -1) ==  '/' ? '' : '/');
        $this->fileList = array();
        $this->file = $file = array(
            'name' => null,
            'type' => null,
            'tmp_name' => null,
            'size' => null,
            'errno' => null,
            'error' => null
        );
    }

    /**
     * 设置允许上传的图片后缀格式
     * @param $allowExt 文件后缀数组
     */
    public function setAllowExt($allowExt)
    {
        if (is_array($allowExt)) {
            $this->allowExt = $allowExt;
        } else {
            $this->allowExt = array($allowExt);
        }
    }

    /**
     * 设置允许上传的图片规格
     * @param $fileMaxSize 最大文件尺寸
     */
    public function setMaxSize($fileMaxSize)
    {
        $this->fileMaxSize = $fileMaxSize;
    }

    /**
     * 获取上传成功的文件数组
     * @return mixed
     */
    public function getUploadFiles()
    {
        return $this->uploadFiles;
    }

    /**
     * 得到文件上传的错误信息
     * @return array|mixed
     */
    public function getErrorMsg()
    {
        if (count($this->fileList) == 0) {
            return $this->file['error'];
        } else {
            $errArr = array();
            foreach ($this->fileList as $item) {
                array_push($errArr, $item['error']);
            }
            return $errArr;
        }
    }

    /**
     * 初始化文件参数
     * @param $isList
     */
    private function initFile($isList)
    {
        if ($isList) {
            foreach ($this->temFiles[$this->inputName] as $iK => $iV) {
                foreach ($iV as $jK => $jV) {
                    if ($jK == 'error') {
                        $this->fileList[$iK]['error'] = null;
                        $this->fileList[$iK]['errno'] = $jV;
                    } else {
                        $this->fileList[$iK][$jK] = $jV;
                    }
                }
            }
        } else {
            $this->file['name'] = $this->temFiles[$this->inputName]['name'];
            $this->file['type'] = $this->temFiles[$this->inputName]['type'];
            $this->file['tmp_name'] = $this->temFiles[$this->inputName]['tmp_name'];
            $this->file['size'] = $this->temFiles[$this->inputName]['size'];
            $this->file['errno'] = $this->temFiles[$this->inputName]['error'];
        }
    }

    /**
     * 上传错误检查
     * @param $errno
     * @return null|string
     */
    private function errorCheck($errno)
    {
        switch ($errno) {
            case UPLOAD_ERR_OK:
                return null;
            case UPLOAD_ERR_INI_SIZE:
                return '文件尺寸超过服务器限制';
            case UPLOAD_ERR_FORM_SIZE:
                return '文件尺寸超过表单限制';
            case UPLOAD_ERR_PARTIAL:
                return '只有部分文件被上传';
            case UPLOAD_ERR_NO_FILE:
                return '没有文件被上传';
            case UPLOAD_ERR_NO_TMP_DIR:
                return '找不到临时文件夹';
            case UPLOAD_ERR_CANT_WRITE:
                return '文件写入失败';
            case UPLOAD_ERR_EXTENSION:
                return '上传被扩展程序中断';
        }
    }

    private function headCheck($filePath)
    {
        $tempfile = @fopen($filePath, "rb");
        $bin = fread($tempfile, 2); //只读2字节
        fclose($tempfile);
        $strInfo = @unpack("C2chars", $bin);
        $typeCode = intval($strInfo['chars1'] . $strInfo['chars2']);
        $fileType = '';
        switch ($typeCode) { // 6677:bmp 255216:jpg 7173:gif 13780:png 7790:exe 8297:rar 8075:zip tar:109121 7z:55122 gz 31139
            case 255216:
                $fileType = 'jpg';
                break;
            case 7173:
                $fileType = 'gif';
                break;
            case 13780:
                $fileType = 'png';
                break;
            case 6677:
                $fileType = 'bmp';
                break;
            case 8297:
                $fileType = 'rar';
                break;
            case 8075:
                $fileType = 'zip';
                break;
            default:
                $fileType = 'unknown';
        }

        if (!in_array($fileType, $this->allowExt)) {
            throw new Exception('暂不允许被上传的文件类型');
//            return array('status' => FALSE, 'error' => '文件类型：' . $fileType . ' 暂不允许被上传', 'msg' => '文件类型：' . $fileType . ' 暂不允许被上传');
        }
    }

    /**
     * 上传文件校验
     * @param $file
     * @throws Exception
     */
    private function fileCheck($file)
    {
        //图片上传过程是否顺利
        if ($file['errno'] != 0) {
            $error = $this->errorCheck($file['errno']);
            throw new Exception($error);
        }
        //图片尺寸是否符合要求
        if (!empty($this->fileMaxSize) && $file['size'] > $this->fileMaxSize) {
            throw new Exception('文件尺寸超过' . ($this->fileMaxSize / 1024) . 'KB');
        }
        //图片类型是否符合要求
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (!in_array(strtolower($ext), $this->allowExt)) {
            throw new Exception('不符合要求的文件类型');
        }
        //判断头信息
        $this->headCheck($file['tmp_name']);

        //图片上传方式是否为HTTP
        if (!is_uploaded_file($file['tmp_name'])) {
            throw new Exception('文件不是通过HTTP方式上传的');
        }
        //图片是否可以读取
        if (!getimagesize($file['tmp_name'])) {
            throw new Exception('图片文件损坏');
        }
        //检查上传路径是否存在
        if (!file_exists($this->uploadPath)) {
            mkdir($this->uploadPath, null, true);
        }
    }

    /**
     * 单文件上传，成功返回true
     * @return bool
     */
    public function acceptSingleFile()
    {
        $this->initFile(false);
        try {
            $this->fileCheck($this->file);
            $uniq_name = date('Ymd') . substr(uniqid(microtime(true), true), -14)
                        . '.' . pathinfo($this->file['name'], PATHINFO_EXTENSION);
            if (move_uploaded_file($this->file['tmp_name'], $this->uploadPath . $uniq_name)) {
                $this->uploadFiles = array($this->uploadPath . $uniq_name);
            } else {
                throw new Exception('文件上传失败');
            }
        } catch (Exception $e) {
            $this->file['error'] = $e->getMessage();
        } finally {
            if (file_exists($this->file['tmp_name'])) {
                unlink($this->file['tmp_name']);
            }
        }
        return empty($this->file['error']) ? true : false;
    }

    /**
     * 多文件上传，全部成功返回true
     * @return bool
     */
    public function acceptMultiFile()
    {
        $this->initFile(true);

        $this->uploadFiles = array();
        for ($i = 0; $i < count($this->fileList); $i++) {
            try {
                $this->fileCheck($this->fileList[$i]);
                $ext = pathinfo($this->fileList[$i]['name'], PATHINFO_EXTENSION);
                $uniq_name = date('YmdHis') . substr(uniqid(microtime(true), true), -14) . '.' . $ext;
                if (move_uploaded_file($this->fileList[$i]['tmp_name'], $this->uploadPath . $uniq_name)) {
                    array_push($this->uploadFiles, $this->uploadPath . $uniq_name);
                } else {
                    throw new Exception('文件上传失败');
                }
            } catch (Exception $e) {
                $this->fileList[$i]['error'] = $e->getMessage();
            } finally {
                if (file_exists($this->fileList[$i]['tmp_name'])) {
                    unlink($this->fileList[$i]['tmp_name']);
                }
            }
        }
        $isAll = true;
        foreach ($this->fileList as $item) {
            if (!empty($item['error'])) {
                $isAll = false;
            }
        }
        if ($isAll == false) {
            foreach ($this->uploadFiles as $item) {
                unlink($item);
            }
        }
        return $isAll;
    }
}
