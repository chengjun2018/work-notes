<?php

define("SERVER_HOST", "0.0.0.0");
define("SERVER_PORT", "20001");
define("SERVER_WORKER_NUM", 3);
define("SERVER_TASK_WORKER_NUM",1);
define("APP_NAME", "admin"); //原则上和应用目录名一致
define("APP_DIR", __DIR__);
define("DAEMONIZE", true);
define("DEBUG", TRUE);

include __DIR__ . "/../../server_http.php";
