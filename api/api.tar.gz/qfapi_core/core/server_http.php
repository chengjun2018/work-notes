<?php

/**
 * 使用websocket完成socket通信和http通信
 * http/websocket服务器都是继承自swoole_server，所以swoole_server提供的API，如task/finish/tick等都可以使用
 * dispatch_mode=1/3时，底层会屏蔽onConnect/onClose事件，原因是这2种模式下无法保证onConnect/onClose/onReceive的顺序
 * 
 * 启动环境
 * 引入通用库和对象
 * 执行对应方法
 * 返回数据
 */
/**
 * 基础常量定义与检查
 */
defined("APP_DIR") || exit("Have not define APP_DIR");
defined("APP_NAME") || exit("Have not define APP_NAME");
defined("PATH_RUNTIME") || define("PATH_RUNTIME", __DIR__ . "/../runtime");
defined("FILE_SERVER_LOGS") || define("FILE_SERVER_LOGS", PATH_RUNTIME . "/" . APP_NAME . ".server_log");

define("FILE_MASTER_PID", PATH_RUNTIME . "/" . APP_NAME . ".master_pid");
define("FILE_MANAGER_PID", PATH_RUNTIME . "/" . APP_NAME . ".manager_pid");
define("CORE_DIR", __DIR__);
/**
 * 时区设置
 */
date_default_timezone_set('PRC');

/**
 * 命令行管理程序启动（start）/停止（stop）/重启（reload）
 * TODO:当前该功能还有不足，没有实现柔性重启，因为没有想到办法进入对应的主进程，发送柔性重启命令
 */
if ($argc > 1) {
    $do = $argv[1];
} else {
    $do = "start";
}

$master_pid = is_file(FILE_MASTER_PID) ? file_get_contents(FILE_MASTER_PID) : 0;
$manager_pid = is_file(FILE_MANAGER_PID) ? file_get_contents(FILE_MANAGER_PID) : 0;

if ($do !== "start") {
    if ($master_pid) {
        swoole_process::kill($master_pid);
        is_file(FILE_MASTER_PID) && unlink(FILE_MASTER_PID);
    }
    if ($manager_pid) {
        while (swoole_process::kill($manager_pid, 0)) {
            sleep(1);
            echo "wait manage exit ...\r\n";
        }
        is_file(FILE_MANAGER_PID) && unlink(FILE_MANAGER_PID);
    }
}

if ($do === "stop") {
    echo "server stop success\r\n";
    return;
} else if ($do === "reload") {
    echo "server stoped , starting ……\r\n";
}
sleep(1);

/**
 * 引入配置文件
 */
include APP_DIR . "/config.php";
include __DIR__ . "/config.php";

/**
 * 补充配置
 */
defined("SERVER_HOST") || define("SERVER_HOST", "0.0.0.0");
defined("SERVER_PORT") || define("SERVER_PORT", isset($argv[2]) ? $argv[2] : 80); //默认80端口
defined("SERVER_WORKER_NUM") || define("SERVER_WORKER_NUM", isset($argv[3]) ? $argv[3] : 1); //默认1个工作进程
defined("SERVER_TASK_WORKER_NUM") || define("SERVER_TASK_WORKER_NUM", isset($argv[4]) ? $argv[4] : ceil(SERVER_WORKER_NUM / 2)); //默认工作进程/2，在向上取整个任务进程
defined("DEBUG") || define("DEBUG", FALSE);
defined("DAEMONIZE") || define("DAEMONIZE", FALSE);
defined("SERVER_MAX_REQUEST") || define("SERVER_MAX_REQUEST", 100000);
defined("PACKAGE_MAX_LENGTH") || define("PACKAGE_MAX_LENGTH", 1024 * 1024 * 10);

//连接，无需建立连接池，对每个进程启用连接专线，减少切换，当前无需建立连接池
$IG_MYSQL_CONNECT = NULL;
$IG_SESSION_CONNECT = NULL;
$IG_CACHEDATA_CONNECT = NULL;
if (!isset($IG_CRONTAB)) {
    $IG_CRONTAB = $IG_CRONTAB_COMMON;
} else {
    $IG_CRONTAB = array_merge($IG_CRONTAB_COMMON, $IG_CRONTAB);
}

/**
 * 异步io设置
 */
swoole_async_set(array(
    "socket_buffer_size" => 1024 * 1024 * 20,
    "socket_dontwait" => true,
    "log_file" => PATH_RUNTIME . "/asynio.log"
));

/**
 * 注册自动加载
 */
spl_autoload_register(function ($class) {
    //尝试加载model
    $class_name_arr = explode('\\', trim($class, '\\'), 2);
    if (count($class_name_arr) > 1) {
        $name_space = $class_name_arr[0];
        $class_name = $class_name_arr[1];

        if ($name_space === "Model") {
            $file_class = APP_DIR . "/model/" . $class_name . ".php";
            if (is_file($file_class)) {
                require_once $file_class;
                return;
            }
            $file_class = __DIR__ . "/model/" . $class_name . ".php";
            if (is_file($file_class)) {
                require_once $file_class;
                return;
            }
        }
        return;
    }

    //尝试加载controller,优先级：core libs>core controller>controller 避免核心类被覆盖，造成异常
    if (substr($class, -10) === "Controller") {
        $file_class = __DIR__ . "/libs/" . $class . ".php";
        if (is_file($file_class)) {
            require_once $file_class;
            return;
        }
        $file_class = __DIR__ . "/controller/" . $class . ".php";
        if (is_file($file_class)) {
            require_once $file_class;
            return;
        }
        $file_class = APP_DIR . "/controller/" . $class . ".php";
        if (is_file($file_class)) {
            require_once $file_class;
            return;
        }
        return;
    }

    //尝试加载class,优先级：core libs>core class>class 避免核心类被覆盖，造成异常
    $file_class = __DIR__ . "/libs/" . $class . ".php";
    if (is_file($file_class)) {
        require_once $file_class;
        return;
    }
    $file_class = __DIR__ . "/class/" . $class . ".php";
    if (is_file($file_class)) {
        require_once $file_class;
        return;
    }
    $file_class = APP_DIR . "/class/" . $class . ".php";
    if (is_file($file_class)) {
        require_once $file_class;
        return;
    }

    return;
//    iLog::write("Class加载失败：" . $class);
});

$spend_time_t = 0;
$run_times = 0;

/**
 * 服务管理
 * Server启动在主进程的主线程回调此函数，
 *
 * 在此事件之前Swoole Server已进行了如下操作
 *
 * 已创建了manager进程
 * 已创建了worker子进程
 * 已监听所有TCP/UDP端口
 * 已监听了定时器
 *
 * 接下来要执行
 *
 * 主Reactor开始接收事件，客户端可以connect到Server
 *
 * onStart回调中，仅允许echo、打印Log、修改进程名称。不得执行其他操作。onWorkerStart和onStart回调是在不同进程中并行执行的，不存在先后顺序。
 *
 * 可以在onStart回调中，将$server->master_pid和$server->manager_pid的值保存到一个文件中。这样可以编写脚本，向这两个PID发送信号来实现关闭和重启的操作。
 */
class iServer {

    public $server;
    static public $swoole_server;
    private $eof = '"""'; //json_encode字符串中不可以存在3个连续的双引号
    private $connect_start_time = 0;
    private $work_ids = [];

    public function __construct() {
        $this->server = new swoole_websocket_server(SERVER_HOST, SERVER_PORT);
        self::$swoole_server = $this->server;

        /**
         * 创建内存表
         */
        $table = new swoole_table(1024);
        $table->column('int', swoole_table::TYPE_INT);
        $table->column('data', swoole_table::TYPE_STRING, 1024);
        $table->create();

        iGlobal::set("table", $table);

        /**
         * 申明会话、缓存、数据库连接，写时将被分配到进程，使保持连接，并自动断线重连
         */
        iGlobal::set("pool_session", null);
        iGlobal::set("pool_cache", null);
        iGlobal::set("pool_mysql", null);
        iGlobal::set("swoole_server", $this->server);

        //初始化swoole服务
        $this->server->set(array(
            'max_request' => SERVER_MAX_REQUEST,
            'reactor_num' => 16,
            'worker_num' => SERVER_WORKER_NUM,
            'task_worker_num' => SERVER_TASK_WORKER_NUM,
            'daemonize' => DAEMONIZE, //是否作为守护进程,此配置一般配合log_file使用
            'log_file' => FILE_SERVER_LOGS,
            'dispatch_mode' => 2, //dispatch_mode=1/3时，底层会屏蔽onConnect/onClose事件，原因是这2种模式下无法保证onConnect/onClose/onReceive的顺序
            'package_max_length' => PACKAGE_MAX_LENGTH,
            'open_eof_check' => true,
            'package_eof' => $this->eof,
            'enable_static_handler' => true,
            'document_root' => APP_DIR, // . '/static',
            'http_parse_post' => true,
            'upload_tmp_dir' => PATH_RUNTIME . '/uploadfiles/',
            'task_enable_coroutine' => true
        ));

        //Server启动在主进程的主线程回调此函数
        $this->server->on('Start', array($this, 'onStart'));

        //当工作进程（work/task_work）创建或者重启时
        $this->server->on('WorkerStart', array($this, 'onWorkerStart'));
        //新的连接进入
        $this->server->on('Connect', array($this, 'onConnect'));

        //socket
        $this->server->on("Open", array($this, 'onOpen'));
        $this->server->on("Message", array($this, 'onMessage'));

        //http
        $this->server->on("Request", array($this, 'onRequest'));

        //task需要的事件
        $this->server->on("Task", array($this, 'onTask'));
        $this->server->on("Finish", array($this, 'onFinish'));

        //当连接关闭
        $this->server->on("Close", array($this, 'onClose'));

        $this->server->start();
    }

    public function onStart($server) {
        $this->console(SWOOLE_VERSION . " onStart2\n");
        $master_pid = $server->master_pid;
        $manager_pid = $server->manager_pid;
        file_put_contents(FILE_MASTER_PID, $master_pid);
        file_put_contents(FILE_MANAGER_PID, $manager_pid);
        echo "server is runing\r\n";
    }

    /**
     * 当工作进程（work/task_work）创建
     * @param type $server
     * @param type $work_id
     */
    public function onWorkerStart($server, $work_id) {
        $this->console("onworkerstart" . $work_id . "\n");
        $this->work_ids[] = $work_id;
        if ($work_id == 0) {
            global $IG_CRONTAB;
            if (is_array($IG_CRONTAB)) {
                foreach ($IG_CRONTAB as $v) {
                    if (isset($v["time"]) && isset($v["task"]) && isset($v["task"]["path_info"])) {
                        $time = (int) $v["time"];
                        $task = (array) $v["task"];
                        swoole_timer_tick($time, function($timer_id, $task) {
                            $data = [];
                            $data["type"] = "task";
                            $data["fd"] = "0";
                            $data["path_info"] = $task["path_info"];
                            $data["data"] = isset($task["data"]) ? $task["data"] : [];
                            $this->server->task($data, 0);
                        }, $task);
                        echo "start_timer:" . $v["task"]["path_info"];
                    }
                }
            }
        }
    }

    /**
     * 客户端建立连接
     */
    public function onConnect($server, $fd) {
        $this->console("onconnect:connect a Client connect with fd[{$fd}].\n");
    }

    /**
     * 客户端关闭：
     * 1.当http请求，请求完后将执行close
     * 2.当socket请求，请求断开后将执行close
     */
    public function onClose($server, $fd) {
        $time_now = microtime(true);
        $spend_time = $time_now - $this->connect_start_time;
        $worker_id = $server->worker_id;
        $GLOBALS["run_times"] ++;
        $GLOBALS["spend_time_t"]+=$spend_time;
        $spend_time_v = $GLOBALS["spend_time_t"] / $GLOBALS["run_times"];
        $num_per_s = $GLOBALS["run_times"] / $GLOBALS["spend_time_t"];
        $this->console("Client fd:[{$fd}] was Closed.Server worker id:[{$worker_id}].当前耗时：" . ($spend_time * 1000) . "ms.平均耗时[" . ($spend_time_v * 1000) . "ms.当前进程处理数[{$GLOBALS["run_times"]}].平均每秒处理数[$num_per_s]\n");
    }

    /**
     * 当websocket建立连接和握手后
     * @param swoole_websocket_server $server
     * @param type $request
     */
    function onOpen($server, $request) {
        $this->console("onopen:open a websocket with fd{$request->fd}.\n");
    }

    /**
     * 当收到客户端send的消息后，进入会话期
     * @param object $server
     * @param object $frame 
     */
    function onMessage($server, $frame) {
        /**
         * frame=array("fd"=>"xx","data"=>"","opcode"=>"",finish=>"");
         */
        $app = new iApp("websocket", $server, $frame);
        $ret = $app->run();
        if (is_array($ret)) {
            $ret = json_encode($ret, JSON_UNESCAPED_UNICODE);
        }
        $server->push($frame->fd, $ret);
    }

    /**
     * 当收到http请求，进入会话期
     * @param object $request
     * @param object $response
     */
    function onRequest($request, $response) {
        $this->connect_start_time = microtime(true);
        $data = array(
            "request" => $request,
            "response" => $response
        );

        $app = new iApp("http", $this->server, $data);
        $ret = $app->run();
        if (is_array($ret)) {
            $ret = json_encode($ret, JSON_UNESCAPED_UNICODE);
        }
        $response->end($ret);
    }

    /**
     *  task异步任务
     * @param objetct $server
     * @param int $task_id
     * @param int $from_id
     * @param array $data  array("type"=>"websocket/http","fd"=>0,"path_info"=>"index/index","data"=>array("get"=>array(),"post"=>array(),"input"=>""))
     */
    public function onTask($server, $task) {
//        public function onTask($server, $task_id, $from_id, $data) {
        $data = array(
            "from_id" => $task->worker_id,
            "task_id" => $task->id,
            "data" => $task->data
        );
        $app = new iApp("task", $server, $data["data"]);
        $ret = $app->run();
        if (is_array($ret)) {
            $ret = json_encode($ret, JSON_UNESCAPED_UNICODE);
        }

        if (isset($data["data"]["type"]) && $data["data"]["type"] === "websocket") {
            $server->push($data["fd"], $ret);
        } else {
            return $ret;
        }
    }

    /**
     * task finish
     * @param type $server
     * @param type $task_id
     * @param type $data
     */
    public function onFinish($server, $task_id, $data) {
        $this->console("Task[{$task_id}] finish.\n");
    }

    /**
     * 统一输出(DEBUG模式下，输出到控制台)
     * @param string $msg
     */
    public function console($msg) {
        if (defined("DEBUG") && DEBUG === TRUE) {
            file_put_contents(FILE_SERVER_LOGS, $msg, FILE_APPEND);
        } else {
            echo $msg . "\r\n";
        }
    }

    /**
     * 添加异步任务[函数]
     * @param type $fn onfinish函数
     * @param type $taskid 任务进程id
     * @return type
     * 调用成功，返回值为整数$task_id，表示此任务的ID。如果有finish回应，onFinish回调中会携带$task_id参数
     * 调用失败，返回值为false，$task_id可能为0，因此必须使用===判断是否失败
     */
    static function taskfn($fn, $taskid = -1, $data = array()) {
        $server = self::$swoole_server;
        if ($server->taskworker) {
            return go($fn);
        }
        return $server->task([], $taskid, $fn);
    }

}

new iServer();

/**
 * 应用
 */
class iApp {

    private $type = null;
    private $server = null;
    private $controller = "_Empty";
    private $action = "Index";
    private $action_params = "";
    private $data = null;
    private $fd = 0;
    private $opcode = ""; //WEBSOCKET_OPCODE_TEXT = 0x1 ，文本数据   WEBSOCKET_OPCODE_BINARY = 0x2 ，二进制数据
    private $finish = true;
    private $run_start_time = 0;
    private $run_end_time = 0;
    private $request = null;
    private $response = null;

    /**
     * 应用初始化
     * 1.引用swoole_server对象
     * 2.根据类型，设置app路由：controller  action  及 data
     * 
     * 当type=http时，data为数组，包含request/response 对象
     * 当type=websocket时，data为字符串，表示send的数据
     * 当type=task时，data为数组，包含get/post/input的数据
     * 
     * @param string $type
     * @param type $server
     * @param type $data
     */
    function __construct($type, $server, $data) {
        $this->run_start_time = microtime(true);
        $this->server = $server;
        //此处设header,如果$type="websocket"不设置header,$type=task 这只执行事务，返回数据将return
        $path_info = "";
        if ($type === "websocket") {
            $this->data = $data->data; //index/index|get|json数据
            $this->fd = $data->fd;
            $this->opcode = $data->opcode;
            $this->finish = $data->finish;
            $data_short = substr($this->data, 0, 100);
            $pos = strpos($data_short, "|");
            if ($pos) {
                $path_info = substr($data_short, 0, $pos);
                $this->data = substr($this->data, $pos + 1);
            } else {
                $path_info = "Index/Index";
            }
        } else if ($type === "http") {
            $this->data = $data;
            $request = $data["request"];
            $this->request = $request;
            $this->response = $data["response"];
            $path_info = trim($request->server["path_info"], "/");
            if (empty($path_info)) {
                $path_info = "Index/Index";
            }
        } else {
            $type = "task";
            $path_info = isset($data["path_info"]) ? $data["path_info"] : "";
            $this->data = isset($data["data"]) ? $data["data"] : array(); // $data["data"]=array("get"=>array(),"post"=>array(),"input"=>"")
        }
        $this->type = $type;
        if ($path_info) {
            $path_info_arr = explode("/", $path_info, 3);
            $this->controller = ucfirst($path_info_arr[0]);
            $this->action = isset($path_info_arr[1]) ? ucfirst($path_info_arr[1]) : "Index";
            $this->action_params = isset($path_info_arr[2]) ? $path_info_arr[2] : "";
        }

        iGlobal::set("TIME_NOW", time());
        iModel::$commands = array();
        iSession::$commands = array();
        iCache::$commands = array();
    }

    /**
     * 应用运行，返回运行结果
     * @return mixed 字符串或者数组
     */
    function run() {
        ob_start();
        //避免进程崩溃，需要对应用处理进行try catch 处理
        try {
            include_once CORE_DIR . "/libs/iController.php";
            $controller = $this->controller . "Controller";
            $controller_file = APP_DIR . "/controller/" . $controller . ".php";
            if (is_file($controller_file)) {
                include_once $controller_file;
                if (class_exists($controller)) {
                    $controllerObj = new $controller();
                    $controllerObj->server = &$this->server;
                    $controllerObj->controller = $this->controller;
                    $controllerObj->action = $this->action;
                    $controllerObj->params = explode("/", $this->action_params);

                    iGlobal::set("MODULE", $controllerObj->controller);
                    iGlobal::set("ACTION", $controllerObj->action);
                    iGlobal::set("PARAMS", $controllerObj->params);
                    iGlobal::set("ACCESS_ROUTE", APP_NAME . "/" . lcfirst($this->controller) . "/" . lcfirst($this->action) . ($this->action_params !== "" ? "/" . lcfirst($this->action_params) : ""));

                    $controllerObj->route = iGlobal::get("ACCESS_ROUTE", "");
                    $data = $this->data;
                    $type = $this->type;
                    switch ($type) {
                        case "http":
                            $controllerObj->request = $data["request"];
                            $controllerObj->response = $data["response"];
                            $controllerObj->GET = isset($this->request->get) ? $this->request->get : [];
                            $controllerObj->POST = isset($this->request->post) ? $this->request->post : [];
                            $controllerObj->COOKIE = isset($this->request->cookie) ? $this->request->cookie : [];
                            break;
                        case "websocket":
                            $data_short = substr($data, 0, 10);
                            $pos = strpos($data_short, "|");
                            if ($pos) {
                                $request_type = substr($data_short, 0, $pos);
                                if ($request_type === "get") {
                                    $data = substr($data, $pos + 1);
                                    $controllerObj->GET = json_decode($data, true)? : [];
                                } else if ($request_type === "post") {
                                    $data = substr($data, $pos + 1);
                                    $controllerObj->POST = json_decode($data, true)? : [];
                                } else {
                                    $controllerObj->INPUT = $data;
                                }
                            } else {
                                $controllerObj->INPUT = $data;
                            }
                            break;
                        default://task 异步任务需要给出get/post/input数据，或者空
                            $type = "task";
                            $controllerObj->GET = isset($data["get"]) ? (array) $data["get"] : array();
                            $controllerObj->POST = isset($data["post"]) ? (array) $data["post"] : array();
                            $controllerObj->INPUT = isset($data["input"]) ? (array) $data["input"] : "";
                    }
                    $controllerObj->type = $type;
                    $device = $controllerObj->input("post.device", false) ? : ($controllerObj->input("get.device", false) ? : $controllerObj->input("cookie.device", "brower"));
                    $access_token = $controllerObj->input("post.access_token", false) ? : ($controllerObj->input("get.access_token", false) ? : $controllerObj->input("cookie.access_token", false));
                    iGlobal::set("device", $device);
                    iGlobal::set("access_token", $access_token);
                    iGlobal::set("access_ip", $controllerObj->request->header['x-real-ip']);

                    $action = "action" . $controllerObj->action;
                    if (method_exists($controllerObj, $action)) {
                        return $this->doAction($controllerObj, $action, $controllerObj->params);
                    } else {
                        return array("code" => 404, "msg" => "访问地址不存在" . DEBUG ? ("|no action:" . $action) : "");
                    }
                } else {
                    return array("code" => 404, "msg" => "访问地址不存在" . DEBUG ? ("|no controller:" . $controller) : "");
                }
            } else {
                return array("code" => 404, "msg" => "访问地址不存在" . DEBUG ? ("|no controller file:" . $controller_file) : "");
            }
        } catch (Exception $e) {
            $e_arr = array(
                "code" => $e->getCode(),
                "file" => $e->getFile(),
                "line" => $e->getLine(),
                "message" => $e->getMessage(),
                "trace" => $e->getTrace()
            );
            $e_str = json_encode($e_arr);
            iLog::write("异常" . $e_str, "exception");
            return array("code" => 500, "msg" => "服务异常，稍后再试", "error" => $e_arr);
        }
    }

    /**
     * 执行具体行为
     * @param string $controllerObj
     * @param string $action
     * @return string/array
     */
    function doAction($controllerObj, $action, $params = []) {
        iModel::_end(); //初始化
        iSession::start($controllerObj); //初始会话
        $access_token_changed = iGlobal::get("access_token_changed", false);
        $access_token = iGlobal::get("access_token", "");

        if ($controllerObj->checkAccess() === false) {
            if (iSession::get("id", 0) == 0) {
                $ret = array("code" => 401, "msg" => "请登录");
            } else {
                $ret = array("code" => 403, "msg" => "权限不足，你无法进行此操作");
            }
        } else {
            ob_clean();
            $ret = $controllerObj->beforeAction();
            if ($ret === TRUE) {//如果beforeAction返回true，则执行具体行为
                $ret = call_user_func_array(array($controllerObj, $action), $params);
                $ret2 = ob_get_contents();
                if ($ret === null) {
                    $ret = $ret2;
                }
            }
        }

        if ($this->type === "http") {
            $this->response->header('Charset', 'UTF-8');

            $origin = isset($this->request->server['HTTP_ORIGIN']) ? $this->request->server['HTTP_ORIGIN'] : '';

            $this->response->header('Access-Control-Allow-Methods', 'OPTIONS');
            $this->response->header('Access-Control-Allow-Headers', 'x_requested_with, x-requested-with,session_id,Content-Type,token,Origin');
            $this->response->header('Access-Control-Max-Age', '86400');
            $this->response->header('Access-Control-Allow-Credentials', 'true');
            if (ALLOW_ORIGINS === "*") {
                $this->response->header('Access-Control-Allow-Origin', $origin);
            } else {
                $allow_origin = explode(",", ALLOW_ORIGINS);
                if (in_array($origin, $allow_origin)) {
                    $this->response->header('Access-Control-Allow-Origin', $origin);
                }
            }
            if ($controllerObj->contentType === "auto") {
                if (is_array($ret)) {
                    $this->response->header('Content-Type', 'application/json');
                } else if ($ret) {
                    $this->response->header('Content-Type', 'text/html');
                }
            } else {
                $this->response->header('Content-Type', $controllerObj->contentType);
            }
            if ($access_token_changed && $controllerObj->sendCookie === TRUE) {
                $this->response->cookie("access_token", $access_token, time() + 3600 * 24 * 1, "/", COOKIE_DOMAIN);
            }
        }

        $this->run_end_time = microtime(true);
        if (is_array($ret)) {
            if ($access_token_changed) {
                $ret["access_token"] = $access_token;
            }
            //挤出状态
            $occupy_status = iSession::get('occupy_status');
            if ($occupy_status == 1) {
                $ret['occupy_status'] = 1;
            }
            $ret["spend_time_all"] = ($this->run_end_time - $this->run_start_time) * 1000;
            if (DEBUG) {
                $ret["_request"] = $this->request;
                $ret["_sql_commands"] = iModel::$commands;
                $ret["_session_commands"] = iSession::$commands;
                $ret["_cache_commands"] = iCache::$commands;
                $ret["_ACCESS_ROUTE"] = iGlobal::get("ACCESS_ROUTE");
                $ret["_ALL_GROUP_ROUTES"] = iGlobal::get("ALL_GROUP_ROUTES", null);
                $ret["_session"] = iSession::get();
            }
        }
        return $ret;
    }

}
