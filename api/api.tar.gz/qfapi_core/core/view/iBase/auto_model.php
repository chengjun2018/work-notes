<ul>
<?php
foreach($data as $info){
	echo "<li>{$info}</li>";
}
?>
</ul>