<?php
echo "<?php\r\n";
?>

namespace Model;

<?php
include __DIR__ . "/auto_model_note.php";
?>
<?php
echo "\r\n";
?>
class <?php echo $this->getViewData("object_name") ?> extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "<?php echo $this->getViewData("table_name") ?>";//表名

}
<?php
echo "\r\n?>";
?>