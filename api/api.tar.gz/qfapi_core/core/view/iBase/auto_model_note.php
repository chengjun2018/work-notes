/**
 # 模型解释 start：

模型名：<?php
echo $this->getViewData("object_name");
echo "\r\n";
?>
表明：<?php
echo $this->getViewData("table_name");
echo "\r\n";
?>
<?php
$table_info = $this->getViewData("table_info", array());
?>
引擎：<?php
echo $table_info["Engine"]? : "";
echo "\r\n";
?>

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
<?php
$fields_info = $this->getViewData("fields_info", array());
foreach ($fields_info as $field) {
    echo "  | " . str_pad($field["Field"], 20) .
    " | " . str_pad($field["Type"], 20) .
    " | " . str_pad($field["Null"], 4) .
    " | " . str_pad($field["Key"], 4) .
    " | " . str_pad($field["Default"], strlen($field["Default"]) - mb_strlen($field["Default"])*2 + 12) .
    " | " . str_pad($field["Comment"], strlen($field["Comment"]) - mb_strlen($field["Comment"])*2 + 48) . " |\r\n";
}
?>
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：<?php
echo $table_info["Comment"]? : "";
echo "\r\n\r\n";  
?>
# 模型解释 end：
*/