<html>
    <head>
        <meta charset="utf-8">
        <title>接口文档_<?php echo APP_NAME ?></title>
        <!-- Set render engine for 360 browser -->
        <!--网页字符编码：utf-8-->
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta name="robots" content="" />

        <!-- Set render engine for 360 browser -->
        <meta name="renderer" content="webkit" />

        <!--移动屏幕的缩放:1比1-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <!--忽略页面中的数字识别为电话号码-->
        <meta name="format-detection" content="telephone=no" />

        <!-- Add to homescreen for Chrome on Android -->
        <meta name="mobile-web-app-capable" content="yes" />
        <link rel="icon" sizes="192x192" href="/staic/images/favicon.png" />

        <!-- Add to homescreen for Safari on iOS -->
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black" />
        <meta name="apple-mobile-web-app-title" content="qiaqianiu"/>
        <link rel="apple-touch-icon-precomposed" href="/staic/images/favicon.png" />


        <!-- Tile icon for Win8 (144x144 + tile color) -->
        <meta name="msapplication-TileImage" content="/staic/images/favicon.png" />
        <meta name="msapplication-TileColor" content="#0e90d2" />
        <meta name="renderer" content="webkit">
        <!-- Elementui UI CSS文件 -->
        <link rel="stylesheet" href="https://unpkg.com/element-ui/lib/theme-chalk/index.css">
        <!-- import Vue Javascript -->
        <script src="https://unpkg.com/vue/dist/vue.js"></script>
        <!-- import Vuex Javascript -->
        <script src="https://unpkg.com/vuex@2.0.0"></script>
        <!-- import Elementui JavaScript -->
        <script src="https://unpkg.com/element-ui/lib/index.js"></script>

        <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
        <script src="https://cdn.bootcss.com/qs/6.5.1/qs.min.js"></script>
    </head>
    <body>
        <div id="app">
            <div id="left_menu">
                <el-scrollbar>
                    <el-menu default-active="2">
                        <el-submenu v-for="(module,mi) in doc" @click="showContent(module)" :index="mi">
                            <template slot="title">{{module.module_name}}</template>
                            <el-menu-item @click="showContent(module,null)">模块介绍</el-menu-item>
                            <el-menu-item v-for="(action,ai) in module.actions" @click="showContent(module,action)">
                                {{action.action_name}}
                            </el-menu-item>
                        </el-submenu>
                    </el-menu>
                </el-scrollbar>
            </div>
            <div id="right_content">
                <el-scrollbar>
                    <h1 class='m_title' :name="content.module_index"> <span class="el-icon el-icon-document"></span> {{content.module_name}}</h1>
                    <div class="m_des" v-if="!action">
                        <pre class='m_description'>{{content.module_description?content.module_description:'无言'}}</pre>
                        <h3 v-if="content.module_model_info && content.module_model_info.model_description">#模块模型#</h3>
                        <pre class='m_description' v-if="content.module_model_info && content.module_model_info.model_description">{{content.module_model_info.model_description}}</pre>
                    </div>
                    <div class="a_apis" v-if="action" :name="action.action_index">
                        <div class="a_api_name">{{action.action_name}}</div>
                        <div class="a_api">{{url}}/{{content.module_index}}/{{action.action_index}}</div>
                        <pre class="a_api_des"><code>{{action.action_description}}</code><div class="testbt" @click="showtest(content.module_index,action.action_index)">测试</div></pre>
                    </div>
                </el-scrollbar>
            </div>
            <div v-if="showtestbox" id="testbox">
                <div id="testsubmitcloser" @click="closetest">关闭</div>
                <el-scrollbar>
                    <textarea id="testarea" v-model="testvalue" ></textarea>
                    <div id="testsubmit" @click="submittest">提交测试</div>
                    <div id="testarea2"><el-scrollbar><pre v-html="backvalue">{{backvalue}}</pre></el-scrollbar></div>
                </el-scrollbar>
            </div>
        </div>

        <script type="text/javascript">
new Vue({
    el: '#app',
    data: {
        url: "",
        doc:<?php echo json_encode($data["doc"]) ?>,
        testvalue: "",
        backvalue: "",
        content: {
            module_index: "index",
            module_name: "iswoole自动化文档系统",
            module_description: "欢迎使用iswoole自动化文档系统，使用过程中欢迎提出优化建议，让系统更加完善",
            actions: []
        },
        action: null,
        testapi: "",
        showtestbox: false
    },
    created: function () {
        this.url = location.host
        console.log(this.doc)
    },
    methods: {
        showContent: function (module, action) {
            console.log(module)
            console.log(action)
            this.content = module
            this.action = action
        },
        showtest: function (module_index, action_index) {
            this.testapi = "http://" + this.url + "/api/" + module_index + "/" + action_index
            this.showtestbox = true
        },
        closetest: function () {
            this.showtestbox = false
        },
        submittest: function () {
            var postdata = {}
            try {
                postdata = eval('(' + this.testvalue + ')')
            } catch (e) {
                alert("请求数据格式错误，必须是对象")
                return
            }
            if (typeof postdata === "object") {
                postdata.device = "test"
                postdata.access_token = localStorage.getItem("access_token") || "";
                that = this;
                postdata = Qs.stringify(postdata);
                axios.post(this.testapi, postdata)
                        .then(function (response) {
                            that.backvalue = that.syntaxHighlight(response);
                            if(typeof response.data.access_token==="string"){
                                localStorage.setItem("access_token",response.data.access_token);
                            }
                        })
                        .catch(function (error) {
                            console.log(error);
                            alert("网络请求失败了");
                        });
            }
        },
        syntaxHighlight: function (json) {
            if (typeof json != 'string') {
                json = JSON.stringify(json, undefined, 2);
            }
            json = json.replace(/&/g, '&').replace(/</g, '<').replace(/>/g, '>');
            return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
                var cls = 'number';
                if (/^"/.test(match)) {
                    if (/:$/.test(match)) {
                        cls = 'key';
                    } else {
                        cls = 'string';
                    }
                } else if (/true|false/.test(match)) {
                    cls = 'boolean';
                } else if (/null/.test(match)) {
                    cls = 'null';
                }
                return '<span class="' + cls + '">' + match + '</span>';
            });
        }
    }
})
        </script>

        <style>

            #app{
                margin: 10px;
            }
            pre{
                margin:10px 0;
                padding:10px 10px 10px 20px;
                /*background: #1f1f1f;*/
                /*color:#fff;*/
                border-radius: 3px;
                margin: 15px;
                line-height: 1.7;
            }
            h3{
                /*background: #222;*/
                position: relative;
                line-height: 40px;
                font-size: 20px;
                font-weight: normal;
                color: #009966;
            }
            #testarea2 pre {margin:0;padding:0}
            .string { color: green; }
            .number { color: darkorange; }
            .boolean { color: blue; }
            .null { color: magenta; }
            .key { color: red; }
            .m_description{
                /*border-bottom: 10px solid #eee;*/
            }

            #left_menu{
                width:240px;
                position: fixed;
                top:0;
                bottom: 0;
                left: 0;
                height: 100%;
                border-right: 1px solid #ddd;
            }
            #right_content{
                position: fixed;
                top:0;
                bottom: 0;
                left: 244px;
                right:0;
                height: 100%;
                padding: 10px;
                background: #fafafa;
            }
            .m_title{
                padding: 15px 5px;
                border-bottom: 1px solid #ddd;
                margin-bottom: 20px;
                padding-left: 10px;
            }
            .el-menu{
                border-right: none;
            }
            .el-menu-item{
                padding-left: 40px !important;
                border-bottom: 1px solid #eee;
            }
            .a_apis,.m_des{
                position: relative;
                margin: 30px 20px;
                padding: 30px;
                background: #fff;
                box-shadow: 0 0 3px #ddd;
            }
            .a_apis:before{
                content: "#接口说明#";
                font-size: 20px;
                color: #009966;
            }
            .m_des:before{
                content: "#模块介绍#";
                font-size: 20px;
                color: #009966;
            }

            .a_api_name{
                line-height: 40px;
                padding-top: 20px;
            }
            .a_api_name:before{
                content: "接口名称：";
            }
            .a_api{
                line-height: 40px;
            }
            .a_api:before{
                content: "接口地址：";
            }
            .a_apis pre{
                margin: 10px 5px;
                position: relative;
                min-height: 300px;
            }
            .testbt,#testsubmitcloser{
                position: absolute;
                right: 0px;
                top: 0px;
                width: 100px;
                height: 30px;
                line-height: 30px;
                text-align: center;
                background: #111;
                color: #fff;
                cursor: pointer;
            }
            .testbt:hover,#testsubmitcloser:hover{
                background: #f22;
                box-shadow: 0 0 3px #f22;
            }
            .a_api_des{
                padding: 10px;
                background: #333;
                color:#fff;
            }
            #testbox{
                position: fixed;
                bottom: 110px;
                width: 1200px;
                left: 50%;
                margin-left: -600px;
                top:100px;
                z-index: 999;
                background: #fff;
                box-shadow: 0 0 8px #ccc;
                padding: 10px;
                overflow: hidden;
            }
            #testbox:before{
                content: "# 测试盒子";
                font-size: 20px;
                color: #888;
                line-height: 40px;

            }
            #testbox textarea,#testarea2{
                display: block;
                width: 1170px;
                margin: 15px;
                height:300px;
                border: 0;
                background: #eee;
                padding: 10px;
            }
            #testsubmit{
                height: 35px;
                line-height: 35px;
                background: #009966;
                color: #fff;
                text-align: center;
                width: 200px;
                margin: 30px;
                cursor: pointer;
            }
            #testsubmit{
                background: #f22;
            }
            .el-submenu__title:before{
                content: "m ";
                font-size: 10px;
                color: #009966;
            }

        </style>


    </body>
</html>