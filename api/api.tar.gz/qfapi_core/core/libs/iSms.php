<?php

use GuzzleHttp\Client;

class iSms
{

    const APIURL = 'https://sms.yunpian.com/v2/sms/single_send.json';
    const APIKEY = 'afb739376d018febad5147847742214d';

    /**
     * @param $phone
     * @return mixed|\ResultSet|\SimpleXMLElement
     */

    public static function send($phone)
    {
        $sms_code = rand(1000, 9999);
        $text = '【TYKF提示】亲爱的用户，您的短信验证码：' . $sms_code;
        $res = static::curl_post_content(static::APIURL, ['apikey' => static::APIKEY, 'mobile' => $phone, 'text' => $text]);
        if ($res['code'] > 0) {
            iLog::write($res['msg'], 'error-send-mobile-code');
            return ['status' => false, 'msg' => '发送短信验证码失败'];
        }
        return ['status' => true, 'code' => $sms_code];
    }

    private static function curl_post_content($url, $data, $conn_timeout = 7, $timeout = 5) {
        $headers = [
            'Content-Type: application/x-www-form-urlencoded;charset=utf-8',
            'Accept: application/json;charset=utf-8'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $conn_timeout);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        if ($data) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        }
        $res = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);
        if (($err) || ($httpcode !== 200)) {
            iLog::write(['result' => $res, 'message' => '创建用户失败，返回数据格式错误', 'param' => $data], 'error-send-mobile-code');
            return null;
        }
        return json_decode($res);
    }

}
