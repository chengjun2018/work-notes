<?php

require_once __DIR__ . '/../vendor/autoload.php';

use Aws\ElasticsearchService\ElasticsearchPhpHandler;
use Elasticsearch\ClientBuilder;

/**
 * Class iElasticBuild
 * ES操作类
 *
 */
class iElasticBuild {

    protected $client = null;
    protected $host = "";
    protected $port = "";

    /**
     * 如果客户端为null，建立连接
     */
    public function __construct() {
        $this->client = ClientBuilder::create();
//        $handler = new ElasticsearchPhpHandler('us-west-2');
//            $this->client ->setHandler($handler);
        $this->client->setHost($this->host, $this->port)->build();
    }

    /**
     * 获取客户端连接
     * @return type
     */
    public function getClient() {
        return $this->client;
    }

    public function create_db($index) {

        if (!$index)
            return false;

        $params = [
            'index' => $index,
            'body' => [
                'settings' => [
                    'number_of_shards' => 1,
                    'number_of_replicas' => 0
                ]
            ]
        ];

        try {
            return $this->client->indices()->create($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    //获取索引信息
    public function get_index($index) {

        if (!$index)
            return false;

        $params = [
            'index' => $index,
            'client' => [
                'ignore' => 404
            ]
        ];

        try {
            return $this->client->indices()->getSettings($params); //获取库索引设置
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    public function delete_db($index) {

        if (!$index)
            return false;

        $deleteParams = [
            'index' => $index
        ];
        try {
            return $this->client->indices()->delete($deleteParams);
        } catch (\Exception $e) {
            return ['errpr' => $e->getMessage()];
        }
    }

    //创建字段
    public function create_mappings($index, $type, $filed) {
        if (!$index || !$type || empty($filed))
            return false;

        $params = [
            'index' => $index,
            'type' => $type,
            'body' => [
                $type => [
                    '_source' => [
                        'enabled' => true
                    ],
                    '_all' => [   //  是否开启所有字段的检索
                        'enabled' => false
                    ],
                    'properties' => $filed
                ]
            ]
        ];

        try {
            return $this->client->indices()->putMapping($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 查看字段
    public function get_mapping($index, $type) {
        if (!$type || !$index)
            return false;

        $params = [
            'index' => $index,
            'type' => $type
        ];
        try {
            return $this->client->indices()->getMapping($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 添加数据
    public function add_doc($index, $type, $id, $doc) {
        $params = [
            'index' => $index,
            'type' => $type,
//            'id' => $id,
            'body' => $doc
        ];
        $params['body']['params'] = json_encode($doc['params']);

        try {
            return $this->client->index($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 判断文档存在
    public function exists_doc($index, $type, $id = 1) {
        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id
        ];

        try {
            return $this->client->exists($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 获取文档
    public function get_doc($index, $type, $id = 0) {
        if (!$index || !$type || !$id)
            return false;

        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id // es 自动生成/自己录入的
        ];
        try {
            return $this->client->get($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 更新文档
    public function update_doc($index, $type, $id = 0, $data = []) {

        if (!$index || !$type || !$id || empty($data))
            return false;

        // 可以灵活添加新字段,最好不要乱添加
        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id,
            'body' => [
                'doc' => $data
            ]
        ];

        try {
            return $this->client->update($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 删除文档
    public function delete_doc($index, $type, $id = 0) {

        if (!$index || !$type || !$id)
            return false;
        $params = [
            'index' => $index,
            'type' => $type,
            'id' => $id
        ];

        try {
            return $this->client->delete($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 清空文档
    public function clean_doc($index, $type) {

        if (!$index || !$type)
            return false;
        $params = [
            'index' => $index,
            'type' => $type,
            'body' => [
                'query' => ['match_all' => (object) [],]
            ]
        ];

        try {
            return $this->client->deleteByQuery($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    // 查询文档 (分页，排序，权重，过滤)
    public function search_doc($index, $type, $keywords, $from = 0, $size = 2) {

        if (!$index || !$type)
            return false;

        $params = [
            'index' => $index,
            'type' => $type,
            'body' => [
                'query' => [
                    'bool' => [
                        'should' => [
                            ['match' => ['title' => [
                                        'query' => $keywords,
                                        'boost' => 3, // 权重大
                                    ]]],
                            ['match' => ['content' => [
                                        'query' => $keywords,
                                        'boost' => 2,
                                    ]]],
                        ],
                    ],
                ],
                'sort' => ['price' => ['order' => 'desc']]
                , 'from' => $from, 'size' => $size
            ]
        ];

        try {
            return $this->client->search($params);
        } catch (\Exception $e) {
            $msg = $e->getMessage();
            $msg = json_decode($msg, true);
            return $msg;
        }
    }

    function getUnquireId() {
        return date('Ymd') . substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }

}
