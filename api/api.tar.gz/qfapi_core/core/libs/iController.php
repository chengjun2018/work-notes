<?php

/**
 * 总控制器
 */
class iController {

    private $models = array();
    protected $viewData = array();
    protected $toDelImg = [];
    protected $uploadPath = UPLOAD_PATH . '/'; // Linux 区分大小写，目录请全部小写，多个单词以_链接
    public $contentType = "auto";
    public $member = array();
    public $needCheckAccess = false;
    public $sendCookie = false;
    public $type = null; //http/socket/task
    public $request = null; //需要获取请求数据
    public $response = null; //只做header等特殊处理
    public $GET = array();
    public $POST = array();
    public $COOKIE = array();
    public $INPUT = "";
    public $server = null;
    public $controller = "";
    public $action = "";
    public $params = "";
    public $route = "";
    public $layout = FALSE;
    public $isRestApi = FALSE;
    protected $moduleModel = null; //模块默认模型
    public $noNeedCheckAction = array(); //免鉴权行为，行为名称必须是大写开头，如：Index
    public $noNeedLogAction = array(); //免日志记录行为，行为名称必须是大写开头，如：Index
    //会话相关
    protected $preg = array(
        //邮箱
        'email' => '/^[\w-\.]+@[\w-]+(\.(\w)+)*(\.(\w){2,4})$/',
        //手机号码
        'mobile' => '/^1[3-9]\d{9}$/',
        //固定电话带分机号
        'tel' => '/^((0\d{2,3})-)(\d{7,8})(-(\d{1,4}))?$/',
        //固定电话不带分机号
        'phone' => '/^\d{3}-?\d{8}|\d{4}-?\d{7}$/',
        //域名
        'domain' => '/^(?=^.{3,255}$)[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+$/i',
        //日期
        'date' => '/^[1-9][0-9][0-9][0-9]-[0-9]{1,2}-[0-9]{1,2}$/',
        //日期时间
        'datetime' => '/^[1-9][0-9][0-9][0-9]-[0-9]{1,2}-[0-9]{1,2} [0-9]{1,2}(:[0-9]{1,2}){1,2}$/',
        //时间
        'time' => '/^[0-9]{1,2}(:[0-9]{1,2}){1,2}$/',
        /* --------- 数字类型 -------------- */
        'int' => '/^\d{1,11}$/', //十进制整数
        'hex' => '/^0x[0-9a-f]+$/i', //16进制整数
        'bin' => '/^[01]+$/', //二进制
        'oct' => '/^0[1-7]*[0-7]+$/', //8进制
        'float' => '/^\d+\.[0-9]+$/', //浮点型
        /* ---------字符串类型 -------------- */
        //utf-8中文字符串
        'chinese' => '/^[\x{4e00}-\x{9fa5}]+$/u',
        'bank_branch' => '/^[\x{4e00}-\x{9fa5}A-Za-z0-9]+$/u', //开户支行
        /* ---------常用类型 -------------- */
        'english' => '/^[a-z0-9_\.]+$/i', //英文
        'username' => "/^[0-9A-Za-z]{5,11}$/", //用户名
        'nickname' => '/^[\x{4e00}-\x{9fa5}a-z_\.]+$/ui', //昵称，可以带英文字符和数字
        'realname' => '/^[\x{4e00}-\x{9fa5}{2,7}]+$/u', //真实姓名
        'password' => '/^.{6,12}$/ui', //密码
        'fundpwd' => '/^[0-9A-Za-z]{4,6}$/i', //资金密码
        'wechat' => '/^[-_a-zA-Z0-9]{5,19}+$/i', //微信号
        'imgcode' => '/^[0-9]{4}$/i', //验证码
        'tjcode' => '/^[a-zA-Z0-9]{6}$/i', //推荐码
        'area' => '/^0\d{2,3}$/', //区号
        'version' => '/^\d+\.\d+\.\d+$/', //版本号
        'url' => '/^https?\:\/\/([\w\d\_\-]+\.)+\w+\/?\??[\w\-\.,@?^=%&:\/~\+#]*$/', //URL
        'smscode' => "/^[0-9]{6}$/",
        'notempty' => "/^[\S\s]+$/",
        'img_path' => '/^https?\:\/\/([\d\w\_\-]+\.)+\w+\/([\w\d\_\-\.]+\/)*[\d\w\.\_]+[(png)|(gif)|(jpg)|(jpeg)]$/'
    );

    function __construct($init = true) {
        
    }

    /**
     * 上传图片
     * 注意：  1 多图上传时一个上传失败，同时上传的其他图片全部删除
     *         2 file上传 文件名image_file跟随data数据一起提交 及 data[image_file]
     *
     * @param int $maxSize 最大尺寸 单位M 默认1M
     * @return array
     */
    protected function uplodImg($maxSize = 1, $inputName = 'image_file', $file = null, $maxWidth = '', $maxHight = '', $allExt = ['jpg', 'jpeg', 'png', 'gif']) {
        if (!$file)
            $file = $this->request->files['data'];

        $inputName = array_keys($file)[0];

        $path = $this->uploadPath . date('Ymd') . '/';
        if (!is_dir($path))
            iFile::mkdirs($path);
        require_once (CORE_DIR . '/libs/iUploadImg.php');
        $upload = new iUploadImg($file, $inputName, $path, $maxWidth, $maxHight);

        $upload->setAllowExt($allExt);
        $maxUpload = 1024 * 1024 * $maxSize;
        $upload->setMaxSize($maxUpload);
        // 判断上传
        $isMulti = is_numeric(array_keys($file[$inputName])[0]);
        $status = $isMulti ? $upload->acceptMultiFile() : $upload->acceptSingleFile();
        $error = $isMulti ? array_filter($upload->getErrorMsg())[0] : $upload->getErrorMsg();

        $img_path = $upload->getUploadFiles();
        if (is_array($img_path)) {
            foreach ($img_path as $key => $path) {
                $img_path[$key] = str_replace(UPLOAD_PATH, '/oss', $path);
            }
        }

        return $status ? $this->success(['img_path' => $img_path]) : $this->error($error);
    }

    // 删除图片
    protected function delImg() {
        if (empty($this->toDelImg)) {
            return true;
        }
        if (is_array($this->toDelImg)) {
            foreach ($this->toDelImg as $val) {
                $temp = str_replace('/oss/', UPLOAD_PATH . '/', $val);
                if (is_file($temp)) {
                    unlink($temp);
                }
            }
        } else {
            $path = str_replace('/oss/', UPLOAD_PATH . '/', $this->toDelImg);
            if (is_file($path)) {
                unlink($path);
            }
        }
    }

    /**
     * 权限校验
     * @return boolean
     */
    public function checkAccess() {
        return true;
    }

    /**
     * 访问接口前公共操作
     * @return boolean 需要跳过action则返回false
     */
    public function beforeAction() {
        return true;
    }

    /**
     * 头部获取和设置
     * @param type $name
     * @param type $value
     * @return boolean
     */
    protected function header($name = "", $value = null) {
        if ($value === null) {
            //获取header
            if (empty($this->request)) {
                return null;
            } else {
                return isset($this->request->header[$name]) ? $this->request->header[$name] : null;
            }
        } else {
            //设置header
            $value = strval($value);
            if ($this->response) {
                return false;
            } else {
                $ret = $this->response->header($name, $value);
                return $ret === false ? false : true;
            }
        }
    }

    /**
     * 获取外部数据,仅兼容get/post
     * @param string $name eg:post.name;get.id
     * @param mixed $default 如果数据不存在，返回的默认值
     * @return type
     */
    public function input($name, $default = "") {
        list($method, $name) = explode('.', $name, 2);
        $ret = $default;
        switch ($method) {
            case "get":
                $name_arr = explode(".", $name);
                if (isset($name_arr[1])) {
                    $ret = isset($this->GET[$name_arr[0]][$name_arr[1]]) ? $this->GET[$name_arr[0]][$name_arr[1]] : $default;
                } else {
                    $ret = isset($this->GET[$name]) ? $this->GET[$name] : $default;
                }
                break;
            case "post":
                $name_arr = explode(".", $name);
                if (isset($name_arr[1])) {
                    $ret = isset($this->POST[$name_arr[0]][$name_arr[1]]) ? $this->POST[$name_arr[0]][$name_arr[1]] : $default;
                } else {
                    $ret = isset($this->POST[$name]) ? $this->POST[$name] : $default;
                }
                break;
            case "data":
                $name_arr = explode(".", $name);
                if (isset($name_arr[1])) {
                    $ret = isset($this->POST["data"][$name_arr[0]][$name_arr[1]]) ? $this->POST["data"][$name_arr[0]][$name_arr[1]] : $default;
                } else {
                    $ret = isset($this->POST["data"][$name]) ? $this->POST["data"][$name] : $default;
                }
                break;
            case "cookie":
                $name_arr = explode(".", $name);
                if (isset($name_arr[1])) {
                    $ret = isset($this->COOKIE[$name_arr[0]][$name_arr[1]]) ? $this->COOKIE[$name_arr[0]][$name_arr[1]] : $default;
                } else {
                    $ret = isset($this->COOKIE[$name]) ? $this->COOKIE[$name] : $default;
                }
                break;
        }
        return $ret;
    }

    /**
     * 校验外部数据
     * @param type $preg 正则表达式or名
     * @param type $name 外部数据名
     * @param type $var 校验通过后地址引用
     * @return boolean 校验通过或$grep==null时返回true,校验失败，返回false
     */
    protected function validate($preg, $name, &$var = "", $default = null) {
        $input = $this->input($name, null);
        if ($input === null) {
            return false;
        }
        if (empty($preg)) {
            $var = $input;
            return true;
        }
        if (isset($this->preg[$preg])) {
            $preg = $this->preg[$preg];
        }
        $preg = (string) $preg;
        if ($preg && preg_match($preg, $input)) {
            $var = $input;
            return true;
        }
        if ($default !== null) {
            $var = $default;
            return true;
        }
        $var = "";
        return false;
    }

    /**
     * 记录行为日志
     * @param type $log 日志信息：array("to_username"=>"liming","desc"=>"管理员xxx，添加了用户bbb")
     */
    protected function logAction($log) {
        //记录行为日志
    }

    /**
     * 成功返回数据结果
     * @param type $data
     * @return type
     */
    protected function success($data = array(), $log = []) {
        if (!in_array($this->action, $this->noNeedLogAction)) {
            $this->logAction($log);
        }
        return $this->display(0, $data);
    }

    /**
     * 失败返回数据结果
     * @param type $code 当code为数字时表示错误码，当code不是数字时，表示错误信息，可以是客户端接受的任意数据，充当$data
     * @param type $data 当code为数字时，$data为客户端接收的错误信息，字符串消息以msg方式返回，数组类型以data方式返回
     * @return type
     */
    protected function error($code, $data = array()) {
        if (!is_numeric($code)) {
            $data = $code;
            $code = 1;
        }
        return $this->display($code, $data);
    }

    /**
     * 返回数据渲染
     * @param type $view 视图名或返回码，如果是数字，则非调用视图，返回数组array("code"=>$view,"data"=>$data)
     * @param type $data 视图渲染数据或返回数据
     * @return string
     */
    protected function display($view = null, $data = array(), $layout = null) {
        if ($view === null) {
            $view = $this->action;
        }
        if (is_numeric($view)) {
            $msg = is_string($data) ? $data : "";
            $data = is_array($data) ? $data : [];
            $ret = array(
                "code" => $view,
                "msg" => $msg,
                "data" => $data
            );
            return $ret;
        } else {
            $this->viewData = $data;
            $houzui = ".php";

            if (substr($view, 0, 1) === "/") {
                $VIEW_FILE = APP_DIR . "/bin/view" . lcfirst($view) . $houzui;
            } else {
                $VIEW_FILE = APP_DIR . "/bin/view/" . lcfirst($this->controller) . "/" . lcfirst($view) . $houzui;
            }
            if (!is_file($VIEW_FILE)) {
                $VIEW_FILE = CORE_DIR . "/view/" . lcfirst($this->controller) . "/" . lcfirst($view) . $houzui;
            }
            ob_clean();
            if (is_file($VIEW_FILE)) {
                $layout = $layout === null ? $this->layout : $layout;
                if (is_string($layout)) {
                    $layout_file = APP_DIR . "/bin/view/" . $layout . ".php";
                    if (is_file($layout_file)) {
                        include $layout_file;
                    } else {
                        include $VIEW_FILE;
                        iLog::write("布局文件不存在" . $layout_file);
                    }
                } else {
                    include $VIEW_FILE;
                }
            } else {
                return "404:" . $VIEW_FILE;
            }

            $content = ob_get_contents();
            ob_clean();

            return $content;
        }
    }

    /**
     * 获取视图数据
     * @param string $name 数据索引
     * @param mixed $default 如果数据不存在的默认值
     * @return mixed
     */
    protected function getViewData($name, $default = "") {
        return isset($this->viewData[$name]) ? $this->viewData[$name] : $default;
    }

    /**
     * 页面跳转
     * @param type $location
     */
    public function go($location) {
        header("location:" . $location);
    }

    /**
     * 数据库操作
     * @param string $name 兼容模式使用驼峰访问自定义模型类，如果不存在则调用iModel通用模型类，如果使用小写+下划线，则只能访问iModel通用模型类
     * @param string $mode 调用模式，0：兼容模式（默认），1：仅使用自定义模型，2：仅用原生iModel
     * @return mixed 模型类or null, 模式1可能返回null
     */
    public function model($name, $mode = 0) {
        if (empty($name)) {
            $name = $this->moduleModel ? : $this->controller;
        }
        $model_name = ucfirst($name);
        $mode = (int) $mode;
        $model_index = "m" . $mode . $model_name;
        if (!isset($this->models[$model_index])) {
            $class_name = "Model\\" . $model_name;
            if ($mode != 2 && class_exists($class_name)) {
                $this->models[$model_index] = new $class_name();
            } else if ($mode != 1) {
                $this->models[$model_index] = new iModel($model_name);
            } else {
                return null;
            }
        }
        return $this->models[$model_index];
    }

    /**
     * 密码加密
     * @param string $passowrd
     * @return string
     */
    protected function password($passowrd, $salt = "") {
        return MD5(MD5($passowrd) . $salt);
    }

    /**
     * 根据时间戳转62进制
     * @param type $num
     * @return type
     */
    protected function from10_to_long($num, $long) {
        $index = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $base = $long % 63 % 63;
        $index = substr($index, 0, $base);
        $ret = '';
        for ($t = floor(log10($num) / log10($long)); $t >= 0; $t --) {
            $a = floor($num / pow($long, $t));
            $ret .= substr($index, $a, 1);
            $num -= $a * pow($long, $t);
        }
        return $ret;
    }

    /**
     * 10进制转62
     * @param type $num
     * @return string
     */
    protected function f10t62($num) {
        $index = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return substr($index, $num % 62, 1);
    }

    /**
     * 62转10进制
     * @param string $char
     * @return string
     */
    protected function f62t10($char) {
        $index = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        return strpos($index, $char);
    }

    /**
     * curl 请求
     * @param type $url
     * @param type $post
     * @param type $timeout
     * @param type $header
     * @param type $ssl
     * @return type array("http_info" => $http_info, "response" => $response, "error" => $error, "errno" => $errno);
     */
    function curl($url, $post = array(), $timeout = 3, $header = array(), $ssl = FALSE) {
        $ch = curl_init();

        //设置：返回数据，不直接输入
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

        //设置：浏览器头
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1");

        //设置：超时时间
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

        //设置：url和get
        curl_setopt($ch, CURLOPT_URL, $url);

        //设置：post数据
        if (count($post) > 0) {
            curl_setopt($ch, CURLOPT_POST, TRUE);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post, JSON_UNESCAPED_UNICODE));
        }

        //设置：header
        if (count($header) > 0) {//array('Content-type: text/plain', 'Content-length: 100')
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
        }
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);

        //设置：ssl
        if ($ssl == TRUE) {
            curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
            curl_setopt($ch, CURLOPT_SSLCERT, '/var/cert/cert.pem');
            curl_setopt($ch, CURLOPT_SSLKEY, '/var/cert/key.pem');
            curl_setopt($ch, CURLOPT_CAINFO, '/var/cert/ca.pem');
        } else {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }

        //curl请求并返回信息
        $response = curl_exec($ch);
        $http_info = curl_getinfo($ch);
        $error = curl_error($ch);
        $errno = curl_errno($ch);
        curl_close($ch);
        $ret = array("http_info" => $http_info, "response" => $response, "error" => $error, "errno" => $errno);
        //记录日志
        $logret = $ret;
        $logret["response"] = json_decode($logret["response"], TRUE);
        iLog::write(json_encode($logret, JSON_UNESCAPED_UNICODE), "curl");
        return $ret;
    }

    /**
     * ++++++++++++++++++++++++++++++++++++++++++++
     * 
     * 基础通用接口
     * 
     * ++++++++++++++++++++++++++++++++++++++++++++
     */

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * @param array $data 添加数据，对应表结构，后台可以通过模型rule方法控制具体修改字段和权限，避免安全问题
     * @return array array("code"=>0,"data"=>array("status"=>ture/false,"insert_id"=>$insert_id),"msg"=>"")
     * @action_doc_end
     */
    protected function actionInsert() {
        $model_name = $this->moduleModel;
        $data = (array) $this->input("post.data");

        $Model = $this->model($model_name, 1);
        $ret = array(
            "status" => false,
            "insert_id" => 0
        );
        if ($Model) {
            $ret_insert = $Model->_insert($data);
            $ret = array(
                "status" => $ret_insert === FALSE ? FALSE : TRUE,
                "insert_id" => (int) $ret_insert
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('添加失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:删除
     * @action_description:
     * @return array array("code"=>0,"data"=>array("status"=>ture/false,"affected_rows"=>$affected_rows,"ids"=>array(1)),"msg"=>"")
     * @action_doc_end
     */
    protected function actionDelete() {
        $model_name = $this->moduleModel;
        $ids = array();
        if (!$this->checkWhereIdInt($ids)) {
            return $this->error(3, "信息删除，必须提供准确的id");
        }
        $where = $this->input("post.where");

        $Model = $this->model($model_name);
        $ret = array(
            "status" => false,
            "affected_rows" => 0,
            "ids" => []
        );
        if ($Model) {
            $ret_delete = $Model->_delete($where);
            $ret = array(
                "status" => $ret_delete === FALSE ? FALSE : TRUE,
                "affected_rows" => (int) $ret_delete,
                "ids" => $ids
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('删除失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:编辑
     * @action_description:
     * @param array $data 添加数据，对应表结构，可以通过模型成rule方法控制具体修改字段和权限
     * @return array array("code"=>0,"data"=>array("status"=>ture/false,"affected_rows"=>$affected_rows,"ids"=>array(1)),"msg"=>"")
     * @action_doc_end
     */
    protected function actionUpdate() {
        $model_name = $this->moduleModel;
        $ids = array();
        if (!$this->checkWhereIdInt($ids)) {
            return $this->error(3, "信息修改，必须提供准确的id");
        }
        $where = $this->input("post.where");
        $data = (array) $this->input("post.data");

        $Model = $this->model($model_name);
        $ret = array(
            "status" => false,
            "affected_rows" => 0,
            "ids" => []
        );
        if ($Model) {
            $ret_update = $Model->_update($data, $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int) $ret_update,
                "ids" => $ids
            );
        }

        return $ret['status'] ? $this->success($ret) : $this->error('修改失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:状态修改
     * @action_description:
     * 请求参数：
     * {
     *      where:{
     *          id:1,//id:["in",[1,2,3]]
     *      },
     *      data:{
     *          status:0,//-1：逻辑删除，0：待审核，1：正常，2：禁止
     *          remark:""//状态备注
     *      }
     * }
     * 返回值：
     * {
     *      code:0,
     *      msg:'',
     *      data:{
     *          status:true,//状态修改是否成功，true:成功，false：失败
     *          affected_rows:1//影响记录数
     *          ids:[1]
     *      }
     * }
     * @action_doc_end
     */
    protected function actionChangeStatus() {
        $model_name = $this->moduleModel;
        $ids = array();
        if (!$this->checkWhereIdInt($ids)) {
            return $this->error(3, "状态修改，必须提供准确的id");
        }
        $where = $this->input("post.where");
        $data['status'] = (int) $this->input("post.data.status");
        $data['remark'] = $this->input("post.data.remark", null);

        if ($data['remark'] === null) {
            unset($data['remark']);
        } else {
            $data['remark'] = (string) $data['remark'];
        }

        $Model = $this->model($model_name);
        $ret = array(
            "status" => false,
            "affected_rows" => 0,
            "ids" => []
        );

        if ($Model) {
            $ret_update = $Model->_update($data, $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int) $ret_update,
                "ids" => $ids
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('修改失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:list
     * @action_name:数据列表
     * @action_description:
     * @param int $offset 根据偏移分页
     * @param int $page_size 分页大小，默认10
     * @param int $page 分页，默认1
     * @param string $order 排序
     * @param string $attr 需要的字段
     * @param array $where 筛选，二维数字，
     *   $where = array(
     *       "name" => "liwei",
     *       1 => "or",
     *       "age" => array(
     *           "between" => [20, 30]
     *       ),
     *       "description" => array(
     *           "like",
     *           "%开发%"
     *       ),
     *       2 => array(
     *           "status" => 1
     *       )
     *   );
     * @param int $need_total 是否需要统计总数，默认0：不需要
     * @return array array("code"=>0,"data"=>array("lists"=>列表数据，对应数据库字段),"msg"=>"")
     * @action_doc_end
     */
    protected function actionLists() {
        $model_name = $this->moduleModel;
        $offset = (int) $this->input("post.offset", 0);
        $page_size = (int) $this->input("post.page_size", 10);
        $page = (int) $this->input("post.page", 1);
        $order = (string) $this->input("post.order", "id desc");
        $fields = (string) $this->input("post.attr", "*");
        $where = (array) $this->input("post.where", array());
        $need_total = (int) $this->input("post.need_total", 0);

        if (empty($order)) {
            $order = "id";
        } else {
            $order = preg_replace("/[^a-z0-9_,\s]/", "", $order);
        }

        if ($page_size === 0) {
            $page_size = 10;
        }
        $page_size = max(array(1, $page_size));
        $page = max(array(1, $page));

        $offset += ($page - 1) * $page_size;
        $limit = "$offset,$page_size";
        $fields = preg_replace("/[^a-z0-9_,*]/", "", $fields);

        $Model = $this->model($model_name);
        $ret = array("lists" => [], "page" => $page, "page_size" => $page_size, "offset" => $offset);
        if ($Model) {
            $ret_lists = $Model->_lists($where, $order, $limit, null, $fields);
            $ret = array(
                "lists" => $ret_lists
            );

            if ($need_total) {
                $total_num = $Model->_count($where, null);
                $ret["total_num"] = (int) $total_num;
                $ret["total_page"] = ceil($total_num / $page_size);
            }
        }

        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:count
     * @action_name:计数
     * @action_description:
     * @return array array("code"=>0,"data"=>array("count"=>列表数据数量),"msg"=>"")
     * @action_doc_end
     */
    protected function actionCount() {
        $model_name = $this->moduleModel;
        $where = (array) $this->input("post.where", array());
        $Model = $this->model($model_name);
        $num = 0;
        if ($Model) {
            $num = $Model->_count($where);
        }
        $ret = array(
            "count" => $num
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:sum
     * @action_name:求和
     * @action_description:
     * @return array array("code"=>0,"data"=>array("sum"=>求和值),"msg"=>"")
     * @action_doc_end
     */
    protected function actionSum() {
        $model_name = $this->moduleModel;
        $where = (array) $this->input("post.where", array());
        $field = (string) $this->input("post.field", 'id');
        $Model = $this->model($model_name);
        $sum = 0;
        if ($Model) {
            $sum = $Model->_sum($field, $where);
        }
        $ret = array(
            "sum" => $sum
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:avg
     * @action_name:计算平均值
     * @action_description:
     * @return array array("code"=>0,"data"=>array("avg"=>平均值),"msg"=>"")
     * @action_doc_end
     */
    protected function actionAvg() {
        $model_name = $this->moduleModel;
        $where = (array) $this->input("post.where", array());
        $field = (string) $this->input("post.field", 'id');
        $Model = $this->model($model_name);
        $avg = 0;
        if ($Model) {
            $avg = $Model->_avg($field, $where);
        }
        $ret = array(
            "avg" => $avg
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:max
     * @action_name:获取最大值
     * @action_description:
     * @return array array("code"=>0,"data"=>array("max"=>最大值),"msg"=>"")
     * @action_doc_end
     */
    protected function actionMax() {
        $model_name = $this->moduleModel;
        $where = (array) $this->input("post.where", array());
        $field = (string) $this->input("post.field", 'id');
        $Model = $this->model($model_name);
        $max = 0;
        if ($Model) {
            $max = $Model->_max($field, $where);
        }
        $ret = array(
            "max" => $max
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:min
     * @action_name:获取最小值
     * @action_description:
     * @return array array("code"=>0,"data"=>array("count"=>最小值),"msg"=>"")
     * @action_doc_end
     */
    protected function actionMin() {
        $model_name = $this->moduleModel;
        $where = (array) $this->input("post.where", array());
        $field = (string) $this->input("post.field", 'id');
        $Model = $this->model($model_name);
        $min = 0;
        if ($Model) {
            $min = $Model->_min($field, $where);
        }
        $ret = array(
            "avg" => $min
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * @return array array("code"=>0,"data"=>array("detail"=>数据详情),"msg"=>"")
     * @action_doc_end
     */
    protected function actionDetail($model_name = null) {
        $where = $this->input("post.where", 0); //默认值为0，如果未提供where不可检查出信息
        $fields = $this->input("post.attr", "*");

        $ret = ["detail" => null];

        $Model = $this->model($model_name);
        if ($Model) {
            $ret_detail = $Model->_detail($where, null, $fields);

            $ret = array(
                "detail" => empty($ret_detail) ? null : $ret_detail
            );
        }
        return $this->success($ret);
    }

    /**
     * 获取锁
     * @param type $name
     * @param type $timeout
     */
    public function getLock($name, $timeout = 60) {
        $name = "_iLock_" . $name;
        while (!iCache::redis("setnx", $name, 1)) {
            usleep(5);
        }
        iCache::redis("expire", $name, $timeout);
    }

    /**
     * 检查锁
     * @param type $name
     * @param type $timeout
     */
    public function checkLock($name) {
        $name = "_iLock_" . $name;
        return iCache::redis("get", $name);
    }

    /**
     * 解锁
     * @param type $name
     */
    public function unLock($name) {
        $name = "_iLock_" . $name;
        iCache::redis("delete", $name);
    }

    /**
     * 检查where参数id是否是int
     * //id 必须，并且格式是：id:12或id:["in",[1,2,3]]
     */
    public function checkWhereIdInt(&$ids = array()) {
        $ids = array();
        $id = $this->input("post.where.id", null);
        if ($id === null) {
            return false;
        }
        if (is_array($id) && isset($id[1]) && is_array($id[1]) && $id[0] === "in") {
            foreach ($id[1] as $id_one) {
                if (!is_numeric($id_one)) {
                    iLog::write($id, "testbdl");
                    return false;
                }
                $ids[] = $id_one;
            }
        } else if (!is_numeric($id)) {
            return false;
        } else {
            $ids[] = $id;
        }
        return true;
    }

    /**
     * 二维数组根据某个字段排序
     * @param array $array 要排序的数组
     * @param string $keys   要排序的键字段
     * @param string $sort  排序类型  SORT_ASC     SORT_DESC
     * @return array 排序后的数组
     */
    function arraySort($array, $keys, $sort = SORT_DESC) {
        $keysValue = [];
        foreach ($array as $k => $v) {
            $keysValue[$k] = $v[$keys];
        }
        array_multisort($keysValue, $sort, $array);
        return $array;
    }

    /**
     * 生成唯一推荐码
     * 推广码：系统默认生成，运营后台默认代理大写A开头 + A-Z、a-z和0-9中随机取5位生成；代理商后台（暂缺）默认大写D开头+ A-Z、a-z和0-9中随机取5位生成。
     *
     * @param bool $isPlatform
     * @return string
     */
    protected function createRmdCode($useTable = '', $isPlatform = true) {
        $str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
        $randStr = str_shuffle($str); //打乱字符串

        $rmdCode = ($isPlatform ? 'A' : 'D') . substr($randStr, 0, 5);

        $model = $this->model('uniquecode');
        $model->_insert(['rand_code' => $rmdCode, 'use_talbe' => $useTable]);
        if ($model->affected_rows > 0) {
            return $rmdCode;
        }

        $this->createRmdCode($useTable, $isPlatform);
    }

    /**
     * 大驼峰转换
     * @param string $uncamelized_words
     * @param type $separator
     * @return type
     */
    protected function toTuoFeng($uncamelized_words, $separator = '_') {
        $uncamelized_words = $separator . str_replace($separator, " ", strtolower($uncamelized_words));
        return ucfirst(ltrim(str_replace(" ", "", ucwords($uncamelized_words)), $separator));
    }

    /**
     * 通过redis锁获取全局唯一数字
     * @return array
     */
    public function uniqueNumber() {
        $lock_index = "uniqueNumber";
        $this->getLock($lock_index, 1);
        $time = iSession::redis("time");
        usleep(1);
        $this->unLock($lock_index);
        return $time;
    }

    /**
     * 获取app名称
     * @return string
     */
    public static function getAppNameByDevice() {
        $device = iGlobal::get('device');
        if ($device == 'ios' || $device == 'android') {
            $appName = 'app';
        } elseif ($device == 'mobile_web') {
            $appName = 'h5';
        } elseif ($device == 'pc_web') {
            $appName = 'pc';
        } elseif ($device == 'pc_client') {
            $appName = 'client';
        } else {
            $appName = 'test';
        }
        return $appName;
    }

    /**
     * 是否是app
     * @return boolean
     */
    static public function isApp() {
        $device = iGlobal::get('device');
        if ($device == 'ios' || $device == 'android') {
            return true;
        }
        return false;
    }

    /**
     * 是否是移动端
     * @return boolean
     */
    static public function isMobile() {
        $device = iGlobal::get('device');
        if ($device == 'ios' || $device == 'android' || $device == 'mobile_web') {
            return true;
        }
        return false;
    }

    /**
     * 获取唯一编号
     * @return string
     */
    static public function getUnquireId() {
        return date('Ymd') . substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }

}
