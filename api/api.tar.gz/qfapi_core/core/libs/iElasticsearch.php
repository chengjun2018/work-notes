<?php

require_once __DIR__ . '/../vendor/autoload.php';

use PhpES\EsClient\Client;

/**
 * ES操作类
 * Class iElasticsearch
 */
class iElasticsearch {

    protected $client = null;
    protected $host = "";
    protected $port = "";

    /**
     * 如果客户端为null，建立连接
     */
    public function __construct() {
        $this->client = new Client();
        $this->client->setHost($this->host, $this->port);
    }

    /**
     * 获取客户端连接
     * @return type
     */
    public function getClient() {
        return $this->client;
    }

}
