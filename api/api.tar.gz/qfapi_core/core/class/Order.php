<?php

/**
 * Class Orday
 * 订单相关
 */
class Order extends iController
{
    /**
     * 提款订单号格式：TK+日期+00001 ~ 99999 例如：今天 2019/04/24 提交的第一笔提款申请订单，那订单号就是：TK2019042400001；
        加款订单号格式：JK+日期+00001~99999
        扣款订单号格式：KK+日期+00001~99999
        彩金订单号格式：CJ+日期+00001~99999
        返水订单号格式：FS+日期+00001~99999
        转账订单号格式：ZZ+日期+00001~99999
     */


    public function createOrderNo($type, $model)
    {
        $day = date('Ymd');
        $orderModel = $this->model($model);
        $count = $orderModel->_count(['create_day' => $day]) + 1;

        $length = 5 - strlen($count);
        if ($length > 0) {
            $count = str_repeat('0', $length) . $count;
        }

        return $type . $day . ($count ? $count : 1);
    }
}
