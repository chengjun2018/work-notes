<?php

/**
 * Class Pay
 * 支付相关
 */
class Pay extends iController
{
    // 默讣微信、支付宝、京东钱包、QQ 钱包、网银、银联扫码、网银快捷
    static public $payData = [
        ['pay_code' => 'alipay', 'name' => '支付宝'],
        ['pay_code' => 'wechatpay', 'name' => '微信'],
        ['pay_code' => 'qpay', 'name' => 'QQ 钱包'],
        ['pay_code' => 'jdpay', 'name' => '京东钱包'],
        ['pay_code' => 'unionpay', 'name' => '网银'],
        ['pay_code' => 'unionpay_sm', 'name' => '银联扫码'],
        ['pay_code' => 'unionpay_kj', 'name' => '网银快捷'],
    ];

    static public $thirdPay = [
        ['channle_code' => 'bmw', 'name' => '宝马微信二维码'],
        ['channle_code' => 'test_pay', 'name' => '测试数据网银支付'],
        ['channle_code' => 'alipay', 'name' => '支付宝支付'],
        ['channle_code' => 'xxx', 'name' => 'XXX付银联扫码'],
    ];


    static public $payType = [
        ['pay_code' => 'bank', 'name' => '银行卡转账'],
        ['pay_code' => 'alipay', 'name' => '支付宝'],
        ['pay_code' => 'wechatpay', 'name' => '微信'],
        ['pay_code' => 'qpay', 'name' => 'QQ 钱包'],
        ['pay_code' => 'jdpay', 'name' => '京东钱包'],
        ['pay_code' => 'unionpay', 'name' => '网银'],
        ['pay_code' => 'unionpay_sm', 'name' => '银联扫码'],
        ['pay_code' => 'unionpay_kj', 'name' => '网银快捷'],
    ];


    static public $bankData = [
        ['bank' => 'ABC', 'name' => '中国农业银行'],
        ['bank' => 'BOC', 'name' => '中国银行'],
        ['bank' => 'BCM', 'name' => '交通银行'],
        ['bank' => 'CCB', 'name' => '中国建设银行'],
        ['bank' => 'ICBC', 'name' => '中国工商银行'],
        ['bank' => 'PSBC', 'name' => '中国邮政储蓄银行'],
        ['bank' => 'CMB', 'name' => '招商银行'],
        ['bank' => 'SPDB', 'name' => '浦东发展银行'],
        ['bank' => 'CEB', 'name' => '中国光大银行'],
        ['bank' => 'CITIC', 'name' => '中信银行'],
        ['bank' => 'SPABANK', 'name' => '平安银行'],
        ['bank' => 'CMBC', 'name' => '中国民生银行'],
        ['bank' => 'HXBANK', 'name' => '华夏银行'],
        ['bank' => 'GDB', 'name' => '广发银行'],
        ['bank' => 'BJBANK', 'name' => '北京银行'],
        ['bank' => 'SHBANK', 'name' => '上海银行'],
        ['bank' => 'CIB', 'name' => '兴业银行'],
    ];
}
