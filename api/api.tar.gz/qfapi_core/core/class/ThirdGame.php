<?php

/**
 * 第三方游戏类
 */
class ThirdGame extends iEs {

    static $static_client_search = null;
    static $static_client_build = null;
    protected $api_url = "";
    protected $operatorCode = "";
    protected $secretKey = "";
    protected $errCode = [
    ];
    protected $db = "";
    protected $table = "";
    protected $field = array(
    );

    public function __construct() {
        $this->host = ES_GAME_HOST;
        $this->port = ES_GAME_PORT;
        parent::__construct();
    }

//    public function getSearch() {
//        if (empty(self::$static_client_search)) {
//            if (iGlobal::get("pool_es_thirdgame_search")) {
//                self::$static_client_search = iGlobal::get("pool_es_thirdgame_search");
//            } else {
//                self::$static_client_search = parent::getSearch();
//                iGlobal::set("pool_es_thirdgame_search", self::$static_client_search);
//            }
//        }
//        return self::$static_client_search;
//    }
//
//    public function getBuild() {
//        if (empty(self::$static_client_build)) {
//            if (iGlobal::get("pool_es_thirdgame_build")) {
//                self::$static_client_build = iGlobal::get("pool_es_thirdgame_build");
//            } else {
//                self::$static_client_build = parent::getBuild();
//                iGlobal::set("pool_es_thirdgame_build", self::$static_client_build);
//            }
//        }
//        return self::$static_client_build;
//    }
    
        /**
     * 拉取游戏数据
     * @param type $try_create_index
     * @return boolean 成功返回true，失败返回false
     */
    public function getGameData($try_create_index = true) {
        return false;
    }

    /**
     * 创建数据库
     */
    public function createIndex() {
        $this->create_db($this->db);
        $this->create_mappings($this->db, $this->table, $this->field);
    }

    /**
     * 重建数据库
     * @return type
     */
    public function reIndex() {
        $this->delete_db($this->db);
        $result = [];
        $result["create_db"] = $this->create_db($this->db);
        $result["create_table"] = $this->create_mappings($this->db, $this->table, $this->field);
        return $result;
    }
    

    /**
     * 拉取内容
     * @param string $url 第三方接口地址
     * @param array $data 第三方参数
     * @return mixed 成功请求返回数组，失败返回false
     */
    public function curl($url, $data = array()) {
        $headers = array(
            'Content-Type: application/json'
        );
        if ($user_agent === null) {
            $user_agent = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36';
        }
        $headers[] = $user_agent;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        if ($data) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        $res = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);
        if (($err) || ($httpcode !== 200)) {
            iLog::write(['result' => $res, 'message' => '访问第三方游戏接口失败，返回数据格式错误', 'param' => $data], 'thirdgame_' . $this->db);
            return false;
        }
        if (DEBUG) {
            iLog::write(["url" => $url, "params" => $data, "res" => $res], 'thirdgame_' . $this->db);
        }
        return json_decode($res, true);
    }

}
