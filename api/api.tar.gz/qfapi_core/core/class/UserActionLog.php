<?php

/**
 * 第三方游戏类
 */
class UserActionLog extends iEs {

    static $static_client_search = null;
    static $static_client_build = null;

    public function __construct() {
        $this->host = ES_LOG_HOST;
        $this->port = ES_LOG_PORT;
        parent::__construct();
    }

    public function getSearch() {
        if (self::$static_client_search) {
            iGlobal::get("pool_mysql");
            if (iGlobal::get("pool_es_user_action_log_search", null, 60)) {
                self::$static_client_search = iGlobal::get("pool_es_user_action_log");
            } else {
                self::$static_client_search = parent::getSearch();
                iGlobal::set("pool_es_user_action_log", self::$static_client_search);
            }
        }
        return self::$static_client_search;
    }

    public function getBuild() {
        if (self::$static_client_build) {
            iGlobal::get("pool_mysql");
            if (iGlobal::get("pool_es_user_action_log_build", null, 60)) {
                self::$static_client_build = iGlobal::get("pool_es_user_action_log");
            } else {
                self::$static_client_build = parent::getBuild();
                iGlobal::set("pool_es_user_action_log", self::$static_client_build);
            }
        }
        return self::$static_client_build;
    }

}
