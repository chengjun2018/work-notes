<?php

/**
 * 第三方游戏：MG电子
 */
class GameElectricMg extends ThirdGame {

    private $api_url = "https://api.mtechgame.com/generic";
    private $agent = "RAINBOW";
    private $operatorCode = "564FBE2163284ED9B0CF572DA072B0B8";
    private $secretKey = "65D18CE33B624E3DBC988FD35FAFF5D7";
    private $errCode = [
        "-1" => "方法不支持", //"Method Not Supported ",
        "1" => "无效的平台", //" Invalid Platform ",
        "2" => "无效的操作码", //" Invalid OperatorCode ",
        "3" => "无效的ip,请检查ip白名单", //" Invalid IP ",
        "4" => "无效的操作指令", //" Invalid Command ",
        "5" => "无效的参数", //" Invalid Parameter ",
        "6" => "无效的货币", //" Invalid Currency ",
        "7" => "无效的秘钥", //" Invalid SecretKey ",
        "8" => "无效的签名", //" Invalid Sign ",
        "9" => "无效的数量", //" Invalid Amount ",
        "10" => "须要扩展参数", // " Require Extra Parameter ",
        "11" => "无效的语言", // " Invalid Language ",
        "12" => "用户已经存在", // " Username Exists ",
        "13" => "用户不存在", // " Username Not Exists ",
        "14" => "玩家余额不足", // " Player Insufficient Balance ",
        "15" => "重复序列号", // " Duplicate Serial No ",
        "18" => "用户前缀无效", // " Invalid Username Prefix ",
        "500" => "游戏提供商一般错误", // "Game Provider General Error"
    ];
    protected $db = "electric_mg_game_list";
    protected $table = "logs";
    protected $field = array(
        "order_id" => [
            "type" => "keyword"
        ],
        "username" => [
            "type" => "keyword"
        ],
        "amount" => [
            "type" => "float"
        ],
        "valid_amount" => [
            "type" => "float"
        ],
        "win" => [
            "type" => "float"
        ],
        "game_code" => [
            "type" => "keyword"
        ],
        "start_time" => [
            "type" => 'date',
            "format" => 'yyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_second'
        ],
        "end_time" => [
            "type" => 'date',
            "format" => 'yyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_second'
        ]
    );
    public $page_size = 20000; //bug:当单秒游戏数超过该值时需要特殊处理
    private $step = 1800;

    /**
     * 开始游戏
     * @param type $user 第三方用户对象
     * @param type $game_code 电子游戏code
     * @param type $model 是否试玩：test/real
     * @return boolean
     */
    public function startGame($user, $game_code = '', $model = '') {
        $isok = $this->checkOrCreateUser($user);
        if (!$isok) {
            return false;
        }
        $name = strtoupper($this->agent . $user["mg_user"]);
        $password = $user["mg_pwd"];
        $sign = strtoupper(md5("{$this->operatorCode}&{$password}&{$name}&{$this->secretKey}"));
        //登录
        $param = array(
            "gameprovider" => "2",
            "command" => "LOGIN",
            "sign" => $sign,
            "params" => [
                "username" => $name,
                "operatorcode" => $this->operatorCode,
                "password" => $password,
                "gamecode" => $game_code,
                "isfreegame" => $model == "test" ? "True" : "false",
                "ismobile" => iController::isMobile() ? "True" : "false",
                "language" => "CN",
                "extraparameter" => array(
                    "type" => "SMG"
                )
            ]
        );

        $res = $this->curl($this->api_url, $param);

        if (!is_array($res)) {
            return false;
        }

        switch ($res["ErrorCode"]) {
            case 0:
                return $res["Params"]["url"];
            default:
                iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-Mg');
                return false;
        }
    }

    /**
     * 获取余额
     * @param type $user 第三方用户
     * @return boolean
     */
    public function getBalance($user) {
        $isok = $this->checkOrCreateUser($user);
        if (!$isok) {
            return false;
        }
        $name = strtoupper($this->agent . $user["mg_user"]);
        $password = $user["mg_pwd"];
        $sign = strtoupper(md5("{$this->operatorCode}&{$password}&{$name}&{$this->secretKey}"));
        $param = array(
            "gameprovider" => "2",
            "command" => "GET_BALANCE",
            "sign" => $sign,
            "params" => [
                "username" => $name,
                "operatorcode" => $this->operatorCode,
                "password" => $password,
                "extraparameter" => array(
                    "type" => "SMG"
                )
            ]
        );

        $res = $this->curl($this->api_url, $param);

        switch ($res["ErrorCode"]) {
            case 0:
                return $res["Params"]["Balance"];
            default:
                iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-Mg');
                return false;
        }
    }

    /**
     * 提款,将余额转出第三方，转入中心钱包
     * @param object $user  第三方用户
     * @param int $amount 提款金额
     * @return mixed 成功返回订单号，失败返回false
     */
    public function changeIn($user, $amount) {
        $isok = $this->checkOrCreateUser($user);
        if (!$isok) {
            return false;
        }
        $name = strtoupper($this->agent . $user["mg_user"]);
        $password = $user["mg_pwd"];
        $serial_no = $this->getUnquireId();
        $sign = strtoupper(md5("{$amount}&{$this->operatorCode}&{$password}&{$serial_no}&{$name}&{$this->secretKey}"));

        $param = array(
            "gameprovider" => "2",
            "command" => "WITHDRAW",
            "sign" => $sign,
            "params" => [
                "username" => $name,
                "operatorcode" => $this->operatorCode,
                "password" => $password,
                "serialNo" => $serial_no,
                "amount" => $amount,
                "extraparameter" => array(
                    "type" => "SMG"
                )
            ]
        );

        $res = $this->curl($this->api_url, $param);

        switch ($res["ErrorCode"]) {
            case 0:
                if ($res["Params"]["success"] === TRUE) {
                    return $serial_no;
                }
        }
        iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-Mg');
        return false;
    }

    /**
     * 存款,将余额存入第三方
     * @param object $user  第三方用户
     * @param int $amount 存款金额
     * @return mixed 成功返回订单号，失败返回false
     */
    public function changeOut($user, $amount) {
        $isok = $this->checkOrCreateUser($user);
        if (!$isok) {
            return false;
        }
        $name = strtoupper($this->agent . $user["mg_user"]);
        $password = $user["mg_pwd"];
        $serial_no = $this->getUnquireId();
        $sign = strtoupper(md5("{$amount}&{$this->operatorCode}&{$password}&{$serial_no}&{$name}&{$this->secretKey}"));

        $param = array(
            "gameprovider" => "2",
            "command" => "DEPOSIT",
            "sign" => $sign,
            "params" => [
                "username" => $name,
                "operatorcode" => $this->operatorCode,
                "password" => $password,
                "serialNo" => $serial_no,
                "amount" => $amount,
                "extraparameter" => array(
                    "type" => "SMG"
                )
            ]
        );

        $res = $this->curl($this->api_url, $param);

        switch ($res["ErrorCode"]) {
            case 0:
                if ($res["Params"]["success"] === TRUE) {
                    return $serial_no;
                }
        }
        iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-Mg');
        return false;
    }

    /**
     * 转账状态查看
     * @param type $user 用户对象，必须报验用户id和用户名
     * @param type $order_id 第三方转账订单
     * @return boolean|int 失败返回false,成功返回状态值：（-1:不存在、0:成功、2:失败、3:处理中）
     */
    public function checkTransferStatus($user, $order_id) {
        $isok = $this->checkOrCreateUser($user);
        if (!$isok) {
            return false;
        }
        $name = strtoupper($this->agent . $user["mg_user"]);
        $password = $user["mg_pwd"];
        $serial_no = $order_id;
        $sign = strtoupper(md5("{$this->operatorCode}&{$password}&{$serial_no}&{$name}&{$this->secretKey}"));

        $param = array(
            "gameprovider" => "2",
            "command" => "CHECK_TRANSFER_STATUS",
            "sign" => $sign,
            "params" => [
                "username" => $name,
                "operatorcode" => $this->operatorCode,
                "password" => $password,
                "serialNo" => $serial_no
            ]
        );

        $res = $this->curl($this->api_url, $param);

        switch ($res["ErrorCode"]) {
            case 0:
                if ($res["Params"]["success"] === TRUE) {
                    switch ($res["Params"]["status"]) {
                        case "Not Found":
                            return -1;
                        case "Success":
                            return 0;
                        case "Failed":
                            return 2;
                        case "Pending":
                            return 3;
                    }
                }
        }
        iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-Mg');
        return false;
    }

    /**
     * 获取第三方游戏记录
     * @param $user
     * @param string $start_time
     * @param string $end_time
     * @param int $page
     * @param int $page_size
     * @return array
     */
    public function getGameList($user, $start_time = '', $end_time = '', $page = 1, $page_size = 10) {
        if (empty($user) || empty($user["mg_user"])) {
            return [];
        }

        $ess = $this->getSearch()
                ->select(['username', 'amount', 'valid_amount', 'win', 'game_code', 'order_id', 'start_time'])
                ->from($this->db, $this->table)
                ->orderBy('end_time', 'desc');

        $name = strtoupper($this->agent . $user["mg_user"]);
        $ess->where('username', '=', $name);

        if ($start_time && $end_time) {
            $start_time = strtotime($start_time);
            $end_time = strtotime($end_time);
            $ess->where('start_time', 'between', [$start_time, $end_time]);
        }

        $offset = ($page - 1) * $page_size;
        $result = $ess->offset($offset)->limit($page_size)->search()->getFormat();

        $Game = new iModel("Game");
        foreach ($result['data'] as $k => &$v) {
            $game_name = $Game->_detail(["code" => $v["game_code"]], 10, "title");
            $v["game_name"] = $game_name ? $game_name["title"] : "";
            $v["bet_time"] = $v["start_time"];
            unset($v['_index'], $v['_type'], $v['_score'], $v['start_time'], $v['game_code']);
        }

        $ret = [];
        $ret['total_num'] = (int) $result['total'];
        $ret['total_page'] = ceil($result['total'] / $page_size);
        $ret['lists'] = (array) array_values($result['data']);

        return $ret;
    }

    /**
     * 创建账号
     * @param type $user 第三方用户记录
     * @return boolean
     */
    private function checkOrCreateUser(&$user) {
        if (empty($user)) {
            return false;
        }
        $is_exist_user = true;
        if (empty($user['mg_user'])) {
            $is_exist_user = false;
            $user['mg_user'] = strtoupper($user['username']);
            $user['mg_pwd'] = substr(md5(rand(100000, 999999)), 0, 6);
            $rs = (new iModel('third_user'))->_update($user, ['id' => $user['id']]);
            if (false == $rs) {
                return false;
            }
        }

        if (false == $is_exist_user) {
            //创建账号
            $name = $this->agent . $user["mg_user"];
            $password = $user["mg_pwd"];
            $sign = strtoupper(md5("{$this->operatorCode}&{$password}&{$name}&{$this->secretKey}"));
            $param = array(
                "gameprovider" => "2",
                "command" => "CREATE_ACCOUNT",
                "sign" => $sign,
                "params" => [
                    "username" => $name,
                    "operatorcode" => $this->operatorCode,
                    "password" => $password
                ]
            );

            $res = $this->curl($this->api_url, $param);
            if (!is_array($res)) {
                return false;
            }
            switch ($res["ErrorCode"]) {
                case 0:
                case 12:
                    //ok
                    break;
                default:
                    iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-Mg');
                    return false;
            }
        }
        return true;
    }

    /**
     * 拉取游戏数据
     * @param type $try_create_index
     * @return boolean 成功返回true，失败返回false
     */
    public function getGameData($try_create_index = true) {
        /**
         * 获取最后一条数据的betUID，也就是order_id，该游戏以betUID+count书签式调用
         * 避免出现某时间内数据为0，但无法确定是没有游戏数据或者第三方服务数据延迟（可能按规定延迟1分钟，或15分钟，但极端情况下依旧可能延迟数天）
         */
        //获取最后游戏时间
        $ess = $this->getSearch();

        $last_data = $ess->select(['start_time', 'order_id'])
                        ->from($this->db, $this->table)
                        ->limit(1)
                        ->orderBy('start_time', 'desc')
                        ->search()->getFormat();
        //判断最后时间是否获取失败
        if (isset($last_data["state"]) && $last_data["state"] === false) {
            $error = json_decode($last_data["error"], true);
            if ($error["error"]["type"] === "index_not_found_exception" && $try_create_index === true) {
                $this->createIndex();
                return $this->getGameData(false);
            }
            iLog::write($last_data, "es");
            return false;
        }

        //判断是否有数据
        $now = time();
        $start_time = (int) iCache::get("start_time_of_" . $this->db, $now - 3600 * 24 * 45); //尝试从跃进板变量中获取开始时间，如果没有，默认开始时间为45天前
        $start_time = max($start_time, $now - 3600 * 24 * 45);

        $betUID = "";
        if ($last_data['total'] > 0) {
            $d = end($last_data["data"]);
            $start_time = max($start_time, (int) $d["start_time"]); //使用比较晚的开始时间，这样可以使用时间跳板，应对某时间段没有数据的问题
            $betUID = $d["order_id"];
        }

        //最快也要过一分钟才拉取数据
        if ($start_time - $now > -60) {
            iCache::set("start_time_of_" . $this->db, $start_time); //开始时间在1小时前
            return true; //不需要拉取
        }

        $end_time = min([$now - 60, $start_time + $this->step]); //间隔，每次拉取10分钟数据，拉取最近时间不会操作服务器当前时间的60秒前（延迟一分钟，避免服务器时间不同步）
        //mg存储时间为格林尼治时间：GMT+0，例如，用户8点投注，则记录到第三方数据库的时间是16点，东早西完，查询时间需要对应加3600*8，
        $r_start_time = date("Y-m-d H:i:s", min([$start_time, $end_time]) + 3600 * 8);
        $r_end_time = date("Y-m-d H:i:s", max([$start_time, $end_time]) + 3600 * 8);

        $sign = strtoupper(md5("{$this->operatorCode}&{$this->secretKey}"));
        $param = array(
            "gameprovider" => "2",
            "command" => "GET_GAME_DATA",
            "sign" => $sign,
            "params" => [
                "username" => "",
                "operatorcode" => $this->operatorCode,
                "extraparameter" => array(
                    "count" => "2000",
                    "id" => $betUID,
                    "startdate" => $r_start_time,
                    "enddate" => $r_end_time
                )
            ]
        );

        $res = $this->curl($this->api_url, $param);

        if (!is_array($res)) {
            return false;
        }
        switch ($res["ErrorCode"]) {
            case 0:
                //ok
                break;
            default:
                iLog::write(['result' => $res, 'message' => $res['ErrorMessage'], 'param' => $param], 'error-third-' . $this->db);
                return false;
        }

        $results = $res["Params"];
        if (!is_array($results)) {
            iLog::write(['result' => $res, 'message' => '内容格式错误', 'param' => $param], 'error-third-' . $this->db);
            return false;
        }
        if (count($results) > 0) {
            //如果有时间跃进，则将开始时间重置为时间跃进时
            $notempty_start_time = iCache::get("notempty_start_time_of_" . $this->db, null);
            if ($notempty_start_time !== null) {//复查模式
                if ($notempty_start_time < $start_time) {//赶上来了，复查完成
                    iCache::delete("notempty_start_time_of_" . $this->db);
                }
            } else {//非复查模式
                //是否需要进行复查,如果start_time>empty_start_time
                $empty_start_time = iCache::get("empty_start_time_of_" . $this->db, null);
                if ($empty_start_time !== null) {//有空内容，需要复查
                    iCache::set("notempty_start_time_of_" . $this->db, $start_time); //这个地方有数据了哦，复查下，所有处于empty_start_time_of_xx到notemtpy_start_time_of_xx的需要进行一次复查
                    iCache::set("start_time_of_" . $this->db, $empty_start_time); //将开始时间跳板转到为empty_start_time
                    iCache::delete("empty_start_time_of_" . $this->db);
                    return true;
                }
            }

            $bets = [];
            foreach ($results as $v) {
                $betUID = $v["betUID"];
                $s_start_time = strtotime("-8 hour", strtotime($v["gameStartTimeUTC"]));
                $s_end_time = strtotime("-8 hour", strtotime($v["gameEndTimeUTC"]));
                $bets[] = array(
                    "order_id" => $v["betUID"],
                    "username" => $v["playerId"],
                    "amount" => $v["betAmount"],
                    "valid_amount" => $v["betAmount"],
                    "win" => $v["payoutAmount"] - $v["betAmount"],
                    "start_time" => $s_start_time,
                    "end_time" => $s_end_time,
                    "game_code" => $v["gameCode"],
                    "bet_status" => $v["betStatus"],
                );
            }

            //插入投注记录
            $r = $this->batch_insert_bet_list($this->db, $bets);
            if ($r && count($bets) < $this->page_size) {
                iCache::set("start_time_of_" . $this->db, $end_time);
            }
        } else {
            //记录时间跃进
            iCache::set("start_time_of_" . $this->db, $end_time);
            $empty_start_time = iCache::get("empty_start_time_of_" . $this->db, null);
            if ($empty_start_time === null) {//如果没有为空开始时间，则设置当前开始时间为为空开始时间,非复查模式
                $notempty_start_time = iCache::get("notempty_start_time_of_" . $this->db, 0);
                if ($notempty_start_time < $start_time) {//复查模式：notempty_start_time>empty_start_time
                    iCache::set("empty_start_time_of_" . $this->db, $start_time);
                }
            }
        }
        return !DEBUG ? TRUE : ["url" => $this->api_url, "params" => $param, "res" => $res];
    }

}

?>