<?php

//AG第三方
class LiveAgFa
{

    private $api_url = "https://kyapi.ky206.com:189/channelHandle";

    private $agent = 70953;

    private $deskey = 'A175AC876F8CEC00';

    private $md5key = '209D9E980C3DAE64';

    /**
     * 开始游戏
     */
    public function startGame()
    {

        $timestamp = Utils::microtime_int();

        $orderid = $this->agent.date('YmdHis').'TEST02';

        $param = http_build_query([
            's' => 0,
            'account' => 'TEST02',
            'money' => 0,
            'orderid' => $orderid,
            'ip' => $this->header('x-real-ip') ? $this->header('x-real-ip') : '',
            'lineCode' => 'rainbow',
            'KindID' => 0,
            'lang' => 'zh-CN'
        ]);
        $param = Utils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent'=>$this->agent,'timestamp'=>$timestamp,'param'=>$param,'key'=>md5($this->agent.$timestamp.$this->md5key)]);
        $rs = $this->curl($this->api_url.'?'.$url);
        print_r($rs);

    }

    /**
     * 获取余额
     */
    public function getBlance()
    {

        $timestamp = Utils::microtime_int();

        $orderid = $this->agent.date('YmdHis').'test01';

        $param = http_build_query([
            's' => 7,
            'account' => 'test01',
            'money' => 0,
            'orderid' => $orderid,
            'ip' => $this->header('x-real-ip') ? $this->header('x-real-ip') : '',
            'lineCode' => 'rainbow',
            'KindID' => 0,
            'lang' => 'zh-CN'
        ]);
        $param = Utils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent'=>$this->agent,'timestamp'=>$timestamp,'param'=>$param,'key'=>md5($this->agent.$timestamp.$this->md5key)]);
        $rs = $this->curl($this->api_url.'?'.$url);
        print_r($rs);

    }

    function curl($url, $data = array(), $timeout = 5, $header = array(), $ssl = FALSE)
    {
        $headers = array(
            "Accept: application/json",
            "Cache-Control: no-cache",
            "Pragma: no-cache",
            "Accept-Charset: utf-8;q=1"
        );
        $user_agent = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36';
        $headers[] = $user_agent;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 7);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

        $res = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);

        if (($err) || ($httpcode !== 200)) {
            iLog::write(['result'=>$res, 'error'=>$err, 'code'=>$httpcode],'error-third-Ky');
            return null;
        }
        return json_decode($res, true);
    }

    private function param() {

    }


}


class Utils
{

    public static function desEncode($key, $str)
    {
        return self::openssl_desEncode($key, $str);
    }

    public static function desDecode($key, $str)
    {

        return self::openssl_desDecode($key, $str);
    }

    public static function openssl_desEncode($key, $str)
    {
        $str = self::pkcs5_pad(trim($str), 16);
        $encrypt_str = openssl_encrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA|OPENSSL_ZERO_PADDING);
        return base64_encode($encrypt_str);
    }

    public static function openssl_desDecode($key, $str)
    {
        $str = base64_decode($str);
        $decrypt_str = openssl_decrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA|OPENSSL_ZERO_PADDING);
        return trim(self::pkcs5_unpad($decrypt_str));
    }

    public static function pkcs5_pad($text, $blocksize)
    {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    public static function pkcs5_unpad($text)
    {
        $pad = ord($text{strlen($text)-1});
        if ($pad > strlen($text)) return false;
        if (strspn($text, chr($pad), strlen($text) - $pad) != $pad) return false;
        return substr($text, 0, -1 * $pad);
    }

    public static function microtime_int()
    {
        return (int)(microtime(true) * 1000);
    }

}