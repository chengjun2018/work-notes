<?php

/**
 * 开元棋牌第三方
 */
class GameChessKy extends TGame
{

    private $api_url = "https://kyapi.ky206.com:189/";
    private $agent = 70953;
    private $deskey = 'A175AC876F8CEC00';
    private $md5key = '209D9E980C3DAE64';
    private $errCode = [
        '1' => 'TOKEN ',
        '2' => '渠道不存在',
        '3' => '验证时间超时',
        '4' => '验证错误',
        '5' => '渠道白名单错误',
        '6' => '验证字段丢失',
        '8' => '不存在的请求',
        '15' => '渠道验证错误',
        '16' => '数据不存在',
        '20' => '账号禁用',
        '22' => 'AES ',
        '24' => '渠道拉取数据超过时间范围',
        '26' => '订单号不存在',
        '27' => '数据库异常',
        '28' => 'ip ',
        '29' => '订单号与订单规则不符',
        '30' => '获取玩家在线状态失败',
        '31' => '更新的分数小于或者等于 ',
        '32' => '更新玩家信息失败',
        '33' => '更新玩家金币失败',
        '34' => '订单重复',
        '35' => '获取玩家信息失败',
        '36' => 'KindID ',
        '37' => '登录瞬间禁止下分',
        '38' => '余额不足导致下分失败',
        '39' => '禁止同一账号登录带分',
        '40' => '单次上下分数量不能超过一千万',
        '41' => '拉取对局汇总统计时间范围有误',
        '42' => '代理被禁用',
        '43' => '拉单过于频繁',
        '44' => '订单正在处理中',
        '45' => '参数错误',
        '1001' => '注册会员账号系统异常',
        '1002' => '代理商金额不足',
    ];

    protected $db = "chess_ky_game_list";
    protected $table = "logs";
    protected $field = array(
        "order_id" => [
            "type" => "keyword"
        ],
        "username" => [
            "type" => "keyword"
        ],
        "amount" => [
            "type" => "float"
        ],
        "valid_amount" => [
            "type" => "float"
        ],
        "win" => [
            "type" => "float"
        ],
        "game_code" => [
            "type" => "keyword"
        ],
        "table_id" => [
            "type" => "long"
        ],
        "start_time" => [
            "type" => 'date',
            "format" => 'yyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_second'
        ],
        "end_time" => [
            "type" => 'date',
            "format" => 'yyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_second'
        ]
    );
        private $step = 3600;

    /**
     * 开始游戏
     */
    public function startGame($user, $game_code = '', $model = '')
    {
        if(empty($user)){
            return false;
        }
        if (empty($user['ky_user'])) {
            $user['ky_user'] = strtolower($user['username']);
            $rs = (new iModel('third_user'))->_update($user, ['id' => $user['id']]);
            if (false == $rs) return false;
        }

        $timestamp = KyUtils::microtime_int();

        $orderid = $this->agent . date('YmdHis') . $user['ky_user'];
        $ip = iGlobal::get('access_ip');

        $param = http_build_query([
            's' => 0,
            'account' => $user['ky_user'],
            'money' => 0,
            'orderid' => $orderid,
            'ip' => $ip ? $ip : '',
            'lineCode' => 'rainbow',
            'KindID' => 0,
            'lang' => 'zh-CN'
        ]);
        $param = KyUtils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl($this->api_url . 'channelHandle?' . $url);

        if ($res['d']['code']) {
            iLog::write(['result' => $res, 'message' => $this->errCode[$res['d']['code']], 'param' => $param], 'error-third-Ky');
            return false;
        }

        return $res['d']['url'];
    }

    public function curl($url, $data = array(), $timeout = 5, $header = array(), $ssl = FALSE)
    {
        $headers = array(
            "Accept: application/json",
            "Cache-Control: no-cache",
            "Pragma: no-cache",
            "Accept-Charset: utf-8;q=1"
        );
        $user_agent = 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36';
        $headers[] = $user_agent;

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 7);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

        $res = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_errno($ch);
        curl_close($ch);

        if (($err) || ($httpcode !== 200)) {
            iLog::write(['result' => $res, 'error' => $err, 'code' => $httpcode], 'error-third-Ky');
            return null;
        }
        return json_decode($res, true);
    }

    /**
     * 获取余额
     */
    public function getBalance($user)
    {
        $isok = $this->checkOrCreateUser($user);
        if (false == $isok) return false;

        $timestamp = KyUtils::microtime_int();

        $param = http_build_query([
            's' => 7,
            'account' => $user['ky_user'],
            'lang' => 'zh-CN'
        ]);
        $param = KyUtils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl($this->api_url . 'channelHandle?' . $url);

        if ($res['d']['code']) {
            iLog::write(['result' => $res, 'message' => $this->errCode[$res['d']['code']], 'param' => $param], 'error-third-Ky');
            return false;
        }
        return (float)$res['d']['totalMoney'];
    }

    /**
     * 将余额转入第三方（上分）
     * @param $user
     * @param $money
     * @return bool
     */
    public function changeOut($user, $money)
    {

        $isok = $this->checkOrCreateUser($user);
        if (false == $isok) return false;

        $timestamp = KyUtils::microtime_int();

        $orderid = $this->agent . date('YmdHis') . $user['ky_user'];

        $param = http_build_query([
            's' => 2,
            'money' => $money,
            'account' => $user['ky_user'],
            'orderid' => $orderid,
            'lang' => 'zh-CN'
        ]);
        $param = KyUtils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl($this->api_url . 'channelHandle?' . $url);
        if (!is_array($res)) {
            return false;
        }

        if ($res['d']['code']) {
            iLog::write(['result' => $res, 'message' => $this->errCode[$res['d']['code']], 'param' => $param], 'error-third-Ky');
            return false;
        }

        return true;
    }

    /**
     * 将第三方平台转入余额（下分）
     * @param $username
     * @param $money
     * @return bool
     */
    public function changeIn($user, $money)
    {

        $isok = $this->checkOrCreateUser($user);
        if (false == $isok) return false;

        $timestamp = KyUtils::microtime_int();

        $orderid = $this->agent . date('YmdHis') . $user['ky_user'];

        $param = http_build_query([
            's' => 3,
            'money' => $money,
            'account' => $user['ky_user'],
            'orderid' => $orderid,
            'lang' => 'zh-CN'
        ]);
        $param = KyUtils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl($this->api_url . 'channelHandle?' . $url);
        if (!is_array($res)) {
            return false;
        }

        if ($res['d']['code']) {
            iLog::write(['result' => $res, 'message' => $this->errCode[$res['d']['code']], 'param' => $param], 'error-third-Ky');
            return false;
        }
        return true;
    }


    /**
     * 获取第三方游戏记录
     * @param $user
     * @param string $startTime
     * @param string $endTime
     * @param int $page
     * @param int $pagesize
     * @return array
     */
    public function getGameList($user, $startTime = '', $endTime = '', $page = 1, $pagesize = 10)
    {

        if (empty($user)) return [];
        if (!$user['ky_user']) return [];

        $ess = $this->getSearch()
            ->select(['username', 'amount', 'valid_amount', 'win', 'game_code', 'order_id', 'start_time', 'table_id'])
            ->from($this->db, $this->table)
            ->orderBy('end_time', 'desc');

        $ess->where('username', '=', $user["ky_user"]);

        if ($startTime && $endTime) {
            $starttime = strtotime($startTime);
            $endtime = strtotime($endTime);
            $ess->where('start_time', 'between', [$starttime, $endtime]);
        }


        $offset = ($page - 1) * $pagesize;
        $result = $ess->offset($offset)->limit($pagesize)->search()->getFormat();

        foreach ($result['data'] as $k => &$v) {
            $v['game_name'] = KyUtils::$game_code[$v['game_code']];
            $v['table_name'] = KyUtils::$game_table[$v['game_code']][$v['table_id']];
            $v['bet_time'] = $v['start_time'];
            unset($v['_index'], $v['_type'], $v['_score'], $v['game_code'], $v['table_id'], $v['start_time']);
        }

        $ret['total_num'] = $result['total'];
        $ret['total_page'] = ceil($result['total'] / $pagesize);
        $ret['lists'] = array_values($result['data']);
        unset($res);
        return $ret;
    }

    public function getList(){

        $timestamp = KyUtils::microtime_int();

        $param = http_build_query([
            's' => 6,
//            'startTime' => $start,
//            'endTime' => $end,
            'startTime' => 1556328628000,
            'endTime' => 1556332228000,
            'lang' => 'zh-CN'
        ]);
        $param = KyUtils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl('https://kyrecord.ky206.com:190/getRecordHandle' . '?' . $url);
        print_r($res);

    }

    /**
     * 转账状态查看
     * @param type $user 用户对象，必须报验用户id和用户名
     * @param type $order_id 第三方转账订单
     * @return boolean|int 失败返回false,成功返回状态值：（-1:不存在、0:成功、2:失败、3:处理中）
     */
    public function checkTransferStatus($user, $orderid)
    {

        if (empty($user)) return false;
        if (!$user['ky_user']) return false;

        if (!$orderid) return false;

        $timestamp = KyUtils::microtime_int();

        $param = http_build_query([
            's' => 4,
            'orderid' => $orderid,
            'lang' => 'zh-CN'
        ]);
        $param = KyUtils::desEncode($this->deskey, $param);

        $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl($this->api_url . 'channelHandle?' . $url);
        if (!is_array($res)) {
            return false;
        }

        if ($res['d']['code']) {
            iLog::write(['result' => $res, 'message' => $this->errCode[$res['d']['code']], 'param' => $param], 'error-third-Ky');
            return false;
        }

        return $res['d']['status'];
    }


    /**
     * 创建账号
     * @param type $user 第三方用户记录
     * @return boolean
     */
    private function checkOrCreateUser(&$user) {
        if (empty($user)) {
            return false;
        }
        if (empty($user['ky_user'])) {
            $user['ky_user'] = $user['username'];
            $rs = (new iModel('third_user'))->_update($user, ['id' => $user['id']]);
            if (false == $rs) {
                return false;
            }

            $timestamp = KyUtils::microtime_int();

            $orderid = $this->agent . date('YmdHis') . $user['ky_user'];
            $ip = iGlobal::get('access_ip');

            $param = http_build_query([
                's' => 0,
                'account' => $user['ky_user'],
                'money' => 0,
                'orderid' => $orderid,
                'ip' => $ip ? $ip : '',
                'lineCode' => 'rainbow',
                'KindID' => 0,
                'lang' => 'zh-CN'
            ]);
            $param = KyUtils::desEncode($this->deskey, $param);

            $url = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
            $res = $this->curl($this->api_url . 'channelHandle?' . $url);

            if ($res['d']['code']) {
                iLog::write(['result' => $res, 'message' => $this->errCode[$res['d']['code']], 'param' => $param], 'error-third-Ky');
                return false;
            }
        }
        return true;
    }
    
    
    /**
     * 拉取游戏数据
     * @param type $try_create_index
     * @return boolean 成功返回true，失败返回false
     */
    public function getGameData($try_create_index = true) {
        /**
         * 获取最后一条数据的betUID，也就是order_id，该游戏以betUID+count书签式调用
         * 避免出现某时间内数据为0，但无法确定是没有游戏数据或者第三方服务数据延迟（可能按规定延迟1分钟，或15分钟，但极端情况下依旧可能延迟数天）
         */
        //获取最后游戏时间
        $ess = $this->getSearch();

        $last_data = $ess->select(['end_time', 'order_id'])
                        ->from($this->db, $this->table)
                        ->limit(1)
                        ->orderBy('end_time', 'desc')
                        ->search()->getFormat();
        //判断最后时间是否获取失败
        if (isset($last_data["state"]) && $last_data["state"] === false) {
            $error = json_decode($last_data["error"], true);
            if ($error["error"]["type"] === "index_not_found_exception" && $try_create_index === true) {
                $this->createIndex();
                return $this->getGameData(false);
            }
            iLog::write($last_data, "es");
            return false;
        }


        //判断是否有数据
        $now = time();
        $start_time = (int) iCache::get("start_time_of_" . $this->db, $now - 3600 * 24 * 1); //尝试从跃进板变量中获取开始时间，如果没有，默认开始时间为45天前
        $start_time = max($start_time, $now - 3600 * 24 * 1);

        if ($last_data['total'] > 0) {
            $d = end($last_data["data"]);
            $start_time = max($start_time, (int) $d["end_time"]); //使用比较晚的开始时间，这样可以使用时间跳板，应对某时间段没有数据的问题
        }

        //最快也要过一分钟才拉取数据
        if ($start_time - $now > -60) {
            iCache::set("start_time_of_" . $this->db, $start_time); //开始时间在1小时前
            return true; //不需要拉取
        }
        $end_time = min([$now - 60, $start_time + $this->step]); //间隔，每次拉取10分钟数据，拉取最近时间不会操作服务器当前时间的60秒前（延迟一分钟，避免服务器时间不同步）
        //mg存储时间为格林尼治时间：GMT+0，例如，用户8点投注，则记录到第三方数据库的时间是16点，东早西完，查询时间需要对应加3600*8，
        $r_start_time = $start_time * 1000;
        $r_end_time = $end_time * 1000;

        $timestamp = Utils::microtime_int();
        $param = http_build_query([
            's' => 6,
            'startTime' => $r_start_time,
            'endTime' => $r_end_time,
            'lang' => 'zh-CN'
        ]);

        $param = Utils::desEncode($this->deskey, $param);

        $param = http_build_query(['agent' => $this->agent, 'timestamp' => $timestamp, 'param' => $param, 'key' => md5($this->agent . $timestamp . $this->md5key)]);
        $res = $this->curl($this->api_url . "?" . $param);

        if (!is_array($res)) {
            return false;
        }

        $is_empty = false;
        switch ($res['d']['code']) {
            case 0:
                $is_empty = $res['d']['count'] == 0;
                //ok
                break;
            case 16://数据不存在
                $is_empty = true;
                break;
            default:
                iLog::write(['result' => $res, 'message' => $res['d']['code'], 'param' => $param], $this->db);
                return false;
        }

        if (!$is_empty) {
            //如果有时间跃进，则将开始时间重置为时间跃进时
            $notempty_start_time = iCache::get("notempty_start_time_of_" . $this->db, null);
            if ($notempty_start_time !== null) {//复查模式
                if ($notempty_start_time < $start_time) {//赶上来了，复查完成
                    iCache::delete("notempty_start_time_of_" . $this->db);
                }
            } else {//非复查模式
                //是否需要进行复查,如果start_time>empty_start_time
                $empty_start_time = iCache::get("empty_start_time_of_" . $this->db, null);
                if ($empty_start_time !== null) {//有空内容，需要复查
                    iCache::set("notempty_start_time_of_" . $this->db, $start_time); //这个地方有数据了哦，复查下，所有处于empty_start_time_of_xx到notemtpy_start_time_of_xx的需要进行一次复查
                    iCache::set("start_time_of_" . $this->db, $empty_start_time); //将开始时间跳板转到为empty_start_time
                    iCache::delete("empty_start_time_of_" . $this->db);
                    return true;
                }
            }

            $bets = [];
            foreach ($res['d']['list']['Accounts'] as $k => $v) {
                $s_start_time = strtotime($res['d']['list']['GameStartTime'][$k]);
                $s_end_time = strtotime($res['d']['list']['GameEndTime'][$k]);
                $bets[$k]['username'] = str_replace($this->agent . '_', '', $v);
                $bets[$k]['amount'] = $res['d']['list']['AllBet'][$k];
                $bets[$k]['valid_amount'] = $res['d']['list']['CellScore'][$k];
                $bets[$k]['win'] = $res['d']['list']['Profit'][$k];
                $bets[$k]['start_time'] = $s_start_time;
                $bets[$k]['end_time'] = $s_end_time;
                $bets[$k]['game_code'] = $res['d']['list']['KindID'][$k];
                $bets[$k]['order_id'] = $res['d']['list']['GameID'][$k];
                $bets[$k]['table_id'] = $res['d']['list']['ServerID'][$k];
            }

            //插入投注记录
            $r = $this->batch_insert_bet_list($this->db, $bets);
            if ($r) {
                $ret = iCache::set("start_time_of_" . $this->db, $end_time);
            }
        } else {
            //记录时间跃进
            iCache::set("start_time_of_" . $this->db, $end_time);
            $empty_start_time = iCache::get("empty_start_time_of_" . $this->db, null);
            if ($empty_start_time === null) {//如果没有为空开始时间，则设置当前开始时间为为空开始时间,非复查模式
                $notempty_start_time = iCache::get("notempty_start_time_of_" . $this->db, 0);
                if ($notempty_start_time < $start_time) {//复查模式：notempty_start_time>empty_start_time
                    iCache::set("empty_start_time_of_" . $this->db, $start_time);
                }
            }
        }

        return !DEBUG?TRUE:["url" => $this->api_url, "params" => $param, "res" => $res, "start_time" => date("Y-m-d H:i:s", $r_start_time / 1000), "end_time" => date("Y-m-d H:i:s", $r_end_time / 1000)];
    }

}


class KyUtils
{

    public static $game_code = [
        '0' => '大厅',
        '620' => '德州扑克',
        '720' => '二八杠',
        '830' => '抢庄牛牛',
        '220' => '炸金花',
        '860' => '三公',
        '900' => '押庄龙虎',
        '600' => '21 点',
        '870' => '通比牛牛',
        '880' => '欢乐红包',
        '230' => '极速炸金花',
        '730' => '抢庄牌九',
        '630' => '十三水',
        '380' => '幸运五张',
        '610' => '斗地主',
        '390' => '射龙门',
        '910' => '百家乐',
        '920' => '森林舞会',
        '930' => '百人牛牛',
        '1950' => '万人炸金花',
        '650' => '血流成河',
        '890' => '看牌抢庄牛牛',
        '740' => '二人麻将'
    ];

    public static $game_table = [
        '620' => [
            '3600' => '德州扑克新手房',
            '3601' => '德州扑克初级房',
            '3602' => '德州扑克中级房',
            '3603' => '德州扑克高级房',
            '3700' => '德州扑克财大气粗房',
            '3701' => '德州扑克腰缠万贯房',
            '3702' => '德州扑克挥金如土房',
            '3703' => '德州扑克富贵逼人房'
        ],
        '720' => [
            '7201' => '二八杠体验房',
            '7202' => '二八杠初级房',
            '7203' => '二八杠中级房',
            '7204' => '二八杠高级房',
            '7205' => '二八杠至尊房',
            '7206' => '二八杠王者房',
        ],
        '830' => [
            '8301' => '抢庄牛牛体验房',
            '8302' => '抢庄牛牛初级房',
            '8303' => '抢庄牛牛中级房',
            '8304' => '抢庄牛牛高级房',
            '8305' => '抢庄牛牛至尊房',
            '8306' => '抢庄牛牛王者房'
        ],
        '220' => [
            '2201' => '炸金花体验房',
            '2202' => '炸金花初级房',
            '2203' => '炸金花中级房',
            '2204' => '炸金花高级房'
        ],
        '860' => [
            '8601' => '三公体验房',
            '8602' => '三公初级房',
            '8603' => '三公中级房',
            '8604' => '三公高级房',
            '8605' => '三公至尊房',
            '8606' => '三公王者房',
        ],
        '900' => [
            '9001' => '龙虎体验房',
            '9002' => '龙虎初级房',
            '9003' => '龙虎中级房',
            '9004' => '龙虎高级房'
        ],
        '600' => [
            '6001' => '21 点体验房',
            '6002' => '21 点初级房',
            '6003' => '21 点中级房',
            '6004' => '21 点高级房',
        ],
        '870' => [
            '8701' => '通比牛牛体验房',
            '8702' => '通比牛牛初级房',
            '8703' => '通比牛牛中级房',
            '8704' => '通比牛牛高级房',
            '8705' => '通比牛牛至尊房',
            '8706' => '通比牛牛王者房',
        ],
        '880' => [
            '8801' => '欢乐红包体验房',
            '8802' => '欢乐红包初级房',
            '8803' => '欢乐红包中级房',
            '8804' => '欢乐红包高级房',
        ],
        '230' => [
            '2301' => '极速炸金花新手房',
            '2302' => '极速炸金花初级房',
            '2303' => '极速炸金花中级房',
            '2304' => '极速炸金花高级房',
        ],
        '730' => [
            '7301' => '抢庄牌九新手房',
            '7302' => '抢庄牌九初级房',
            '7303' => '抢庄牌九中级房',
            '7304' => '抢庄牌九高级房',
            '7305' => '抢庄牌九至尊房',
            '7306' => '抢庄牌九王者房',
        ],
        '610' => [
            '6101' => '斗地主体验房',
            '6102' => '斗地主初级房',
            '6103' => '斗地主中级房',
            '6104' => '斗地主高级房',
        ],
        '630' => [
            '6301' => '十三水常规场新手房',
            '6302' => '十三水常规场初级房',
            '6303' => '十三水常规场中级房',
            '6304' => '十三水常规场高级房',
            '6305' => '十三水极速场新手房',
            '6306' => '十三水极速场初级房',
            '6307' => '十三水极速场中级房',
            '6308' => '十三水极速场高级房',
        ],
        '380' => [
            '3801' => '幸运五张体验房',
            '3802' => '幸运五张初级房',
            '3803' => '幸运五张中级房',
            '3804' => '幸运五张高级房',
        ],
        '390' => [
            '3901' => '射龙门经典房',
            '3902' => '射龙门暴击房'
        ],
        '910' => [
            '9101' => '百家乐体验房',
            '9102' => '百家乐初级房',
            '9103' => '百家乐中级房',
            '9104' => '百家乐高级房'
        ],
        '920' => [
            '9201' => '森林舞会体验房',
            '9202' => '森林舞会初级房',
            '9203' => '森林舞会中级房',
            '9204' => '森林舞会高级房',
        ],
        '930' => [
            '9301' => '百人牛牛体验房',
            '9302' => '百人牛牛初级房',
            '9303' => '百人牛牛中级房',
            '9304' => '百人牛牛高级房',
        ],
        '1950' => [
            '19501' => '万人炸金花体验房',
            '19502' => '万人炸金花初级房',
            '19503' => '万人炸金花中级房',
            '19504' => '万人炸金花高级房',
        ],
        '650' => [
            '6501' => '血流成河体验房',
            '6502' => '血流成河初级房',
            '6503' => '血流成河中级房',
            '6504' => '血流成河高级房',
        ],
        '890' => [
            '8901' => '看牌抢庄牛牛体验房',
            '8902' => '看牌抢庄牛牛初级房',
            '8903' => '看牌抢庄牛牛中级房',
            '8904' => '看牌抢庄牛牛高级房',
            '8905' => '看牌抢庄牛牛至尊房',
            '8906' => '看牌抢庄牛牛王者房',
        ],
        '740' => [
            '7401' => '二人麻将体验房',
            '7402' => '二人麻将初级房',
            '7403' => '二人麻将中级房',
            '7404' => '二人麻将高级房',
        ]
    ];


    public static function desEncode($key, $str)
    {
        return self::openssl_desEncode($key, $str);
    }

    public static function openssl_desEncode($key, $str)
    {
        $str = self::pkcs5_pad(trim($str), 16);
        $encrypt_str = openssl_encrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
        return base64_encode($encrypt_str);
    }

    public static function pkcs5_pad($text, $blocksize)
    {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    public static function desDecode($key, $str)
    {

        return self::openssl_desDecode($key, $str);
    }

    public static function openssl_desDecode($key, $str)
    {
        $str = base64_decode($str);
        $decrypt_str = openssl_decrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
        return trim(self::pkcs5_unpad($decrypt_str));
    }

    public static function pkcs5_unpad($text)
    {
        $pad = ord($text{strlen($text) - 1});
        if ($pad > strlen($text)) return false;
        if (strspn($text, chr($pad), strlen($text) - $pad) != $pad) return false;
        return substr($text, 0, -1 * $pad);
    }

    public static function microtime_int()
    {
        return (int)(microtime(true) * 1000);
    }

}