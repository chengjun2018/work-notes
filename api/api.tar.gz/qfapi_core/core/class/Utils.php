<?php

class Utils {

    public static function desEncode($key, $str) {
        return self::openssl_desEncode($key, $str);
    }

    public static function openssl_desEncode($key, $str) {
        $str = self::pkcs5_pad(trim($str), 16);
        $encrypt_str = openssl_encrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
        return base64_encode($encrypt_str);
    }

    public static function pkcs5_pad($text, $blocksize) {
        $pad = $blocksize - (strlen($text) % $blocksize);
        return $text . str_repeat(chr($pad), $pad);
    }

    public static function desDecode($key, $str) {

        return self::openssl_desDecode($key, $str);
    }

    public static function openssl_desDecode($key, $str) {
        $str = base64_decode($str);
        $decrypt_str = openssl_decrypt($str, 'AES-128-ECB', $key, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING);
        return trim(self::pkcs5_unpad($decrypt_str));
    }

    public static function pkcs5_unpad($text) {
        $pad = ord($text{strlen($text) - 1});
        if ($pad > strlen($text))
            return false;
        if (strspn($text, chr($pad), strlen($text) - $pad) != $pad)
            return false;
        return substr($text, 0, -1 * $pad);
    }

    public static function microtime_int() {
        return (int) (microtime(true) * 1000);
    }

}
