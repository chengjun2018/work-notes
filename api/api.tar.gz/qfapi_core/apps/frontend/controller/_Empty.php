<?php

class _Empty extends frontendController {

    function actionIndex() {
        
    }

}
