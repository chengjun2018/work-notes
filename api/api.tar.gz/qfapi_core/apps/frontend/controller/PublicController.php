<?php

/**
 * @module_doc_start
 * @module_name:前台公共接口服务
 * @module_type:common
 * @module_descrition:
 * @module_doc_end
 */
class PublicController extends iController
{

    public $needCheckAccess = false;

    /**
     * @action_doc_start
     * @action_index:helpCenterTitle
     * @action_name:帮助中心标题
     * @action_description:
     * 帮助中心全部加载无需请求参数
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                  id://id
     *                  title://标题
     *              }
     *          ]
     *       }
     *   }
     *
     * @action_doc_end
     */
    public function actionHelpCenterTitle()
    {

        $helpModel = $this->model('help_center');
        $list = ['lists' => $helpModel->_lists(['status' => 1], 'sort desc,create_at desc', null, null, 'id, title')];
        return $this->success($list);
    }

    /**
     * @action_doc_start
     * @action_index:helpCenterDetail
     * @action_name:帮助中心详情
     * @action_description:
     * 帮助中心详情
     *
     * 请求示例:
     *     {
     *          id:2,
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                  id://id
     *                  title://标题
     *                  content://内容
     *              }
     *          ]
     *       }
     *   }
     * @action_doc_end
     */
    public function actionHelpCenterDetail()
    {
        $id = (int)$this->input('post.id');
        if ($id <= 0) return $this->error(3, '参数错误');

        $where = [
            'id' => $id,
            'status' => 1
        ];

        $helpModel = $this->model('help_center');
        $info = $helpModel->_detail($where);
        $ret['detail'] = [
            'id' => $info['id'],
            'title' => $info['title'],
            'content' => $info['content'],
        ];
        unset($info, $helpModel);
        return $this->success($ret);
    }


    /**
     * @action_doc_start
     * @action_index:getNotice
     * @action_name:获取公告列表
     * @action_description:
     * 获取公告列表
     * 无参数：
     *
     * 请求示例:
     *     {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                  id://id
     *                  title://标题
     *                  content://内容
     *                  create_at://创建时间
     *              }
     *          ]
     *       }
     *   }
     * @action_doc_end
     */
    public function actionGetNotice()
    {
//        $stime=microtime(true); #获取程序开始执行的时间
//
//        $es = new iElasticBuild();
//        $rs = $es->searchFrontendLogs('',164);
//        $rs = $es->search_doc('frontend_log','logs',1);
//        print_r($rs);
//        return;
//        $rs = $es->search_doc('frontend_log','logs',164);
//        print_r($rs);
//        $es = new iElasticsearch();
//        $rs = $es->searchFrontendLogs('',164);
//        return ;
//
//        #你写的php代码
//        $etime=microtime(true); #获取程序执行结束的时间
//        $total=$etime-$stime;   #计算差值
//        echo "<br />{$total} times";
//        return ;

//        $bank = new CheckBank();
//        $rs = $bank->validateBankNo('6221506020009066385');
//        return $this->success($rs);

//        $rs = iSession::redis('zAdd','frontend_app_list', time(), 1);
//        $rs = iSession::redis('zAdd','frontend_app_list', time(), 2);
//        $rs = iSession::redis('zAdd','frontend_app_list', time(), 3);
//        $rs = iSession::redis('zRem', APP_NAME . '_test_list', 1);
//        var_dump($rs);
//        return;

        $this->POST['where'] = ['status' => 1];
        $this->POST['order'] = 'sort desc,create_at desc';
        $this->POST['attr'] = 'id,title,content,create_at';
        $this->POST['page_size'] = 5;

        $this->moduleModel = 'Notice';
        return parent::actionLists();

    }


    /**
     * @action_doc_start
     * @action_index:getBanner
     * @action_name:获取所有banner
     * @action_description:
     * 获取所有banner
     * 无参数：
     *
     * 请求示例:
     *     {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                  sylb_banner: [//首页轮播banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                      }
     *                  ]
     *                  syzc_banner: [//首页左侧banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                      }
     *                  ]
     *                  syyc_banner: [//首页右侧banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                      }
     *                  ]
     *                  yxrk_banner: [//游戏入口轮播banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                          position//显示位置
     *                          type//跳转类型：1.第三方游戏大厅 2.平台游戏列表
     *                          game//游戏类型：1.真人娱乐 2.棋牌游戏 3.电子游艺 4.体育竞技 5.彩票游戏 6.捕鱼游戏
     *                          gamechild//如果跳转类型为1的话，展示游戏平台名称；为2就是跳转链接
     *                      }
     *                  ]
     *                  yhhd_banner: [//优惠活动banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                      }
     *                  ]
     *                  rmtj_banner: [//热门推荐轮播banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                      }
     *                  ]
     *                  hdxc_banner: [//活动宣传轮播banner
     *                      {
     *                          path//路径
     *                          href//链接
     *                          title//标题
     *                      }
     *                  ]
     *              }
     *          ]
     *       }
     *   }
     * @action_doc_end
     */
    public function actionGetBanner()
    {

        $device = iSession::get('device');
        $type = 2;
        if ($device == 'pc_client' || $device == 'pc_web')
            $type = 1;

        $banner = $this->model('banner');

        $ret_lists = $banner->_lists(['status' => 1, 'type' => $type], 'sort desc,create_at desc', 100, null, '*');

        $typeArr = [1 => 'sylb_banner', 2 => 'syzc_banner', 3 => 'syyc_banner', 4 => 'yxrk_banner', 5 => 'yhhd_banner', 6 => 'rmtj_banner', 7 => 'hdxc_banner'];
        $newData = [];
        $keys = 0;
        foreach ($ret_lists as $key => $val) {

            $newData[$typeArr[$val['position']]][$keys] = [
                'path' => $val['path'],
                'href' => $val['href'],
                'title' => $val['title'],
                'position' => '',
                'type' => '',
                'game' => '',
                'gamechild' => '',
            ];

            if ($val['position'] == 4) {
                $jsonData = json_decode($val['jsondata'], true);
                $newData[$typeArr[$val['position']]][$keys]['position'] = (string)$jsonData['position'];
                $newData[$typeArr[$val['position']]][$keys]['type'] = (string)$jsonData['type'];
                $newData[$typeArr[$val['position']]][$keys]['game'] = (string)$jsonData['game'];
                $newData[$typeArr[$val['position']]][$keys]['gamechild'] = (string)$jsonData['gamechild'];
            }

            $keys += 1;
        }

        foreach ($typeArr as $k => $v) {
            //如果H5，则过滤一些banner信息。
            if ($type == 2) {
                if (in_array($k, [2, 3, 6, 7])) continue;
            }

            if (!isset($newData[$v]))
                $newData[$v] = [];
            else
                $newData[$v] = array_values($newData[$v]);
        }

        unset($ret_lists, $banner, $typeArr);
        return $this->success(['lists' => $newData]);

    }


    /**
     * @action_doc_start
     * @action_index:getFooter
     * @action_name:获取页脚
     * @action_description:
     * 获取页脚
     * 无参数：
     *
     * 请求示例:
     *     {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                  id://id
     *                  title://标题
     *                  type://类型1.PC 2.H5
     *                  url://跳转地址
     *                  create_at://创建时间
     *              }
     *          ]
     *       }
     *   }
     * @action_doc_end
     */
    public function actionGetFooter()
    {
        $config = $this->model('web_config');
        $rs = $config->_detail(['key' => 'footer']);
        $new = [];
        if (!empty($rs)) {
            $val = json_decode($rs['value'], true);
            array_multisort(array_column($val, 'sort'), SORT_DESC, array_column($val, 'create_at'), SORT_DESC, $val);

            foreach ($val as $k => $v) {
                if ($v['type'] == 2) continue;

                if (count($new) > 5) break;

                $new[] = $v;
            }

//            $val = array_slice($val,0, 6, true);
        }
        unset($rs, $val);
        return $this->success(['lists' => $new]);
    }

    public function actionTest()
    {

        $game = new GameChessKy();
        $game->getList();

//        echo (int)(microtime(true)*1000);
//        return ;
//        $third = new iThirdGame();
//        $rs = $third->startThirdGame(2,1, 'morris');

//        $game = [
//            "live" => [
//                "label" => "真人娱乐",
//                "children" => [
//                    [
//                        "value" => "ag_fa",
//                        "label" => "AG急速厅"
//                    ],
//                    [
//                        "value" => "ag_in",
//                        "label" => "AG国际厅"
//                    ]
//                ]
//            ],
//            "electric" => [
//                "label" => "电子游戏",
//                "children" => [
//                    [
//                        "value" => "mg",
//                        "label" => "MG电子"
//                    ],
//                    [
//                        "value" => "pt",
//                        "label" => "PT电子"
//                    ]
//                ]
//            ],
//            "chess" => [
//                "label" => "棋牌游戏",
//                "children" => [
//                    [
//                        "value" => "ky",
//                        "label" => "KY棋牌"
//                    ]
//                ]
//            ]
//        ];
//        echo json_encode($game);


//        return $this->success($game);
    }


    /**
     * @action_doc_start
     * @action_index:agentPoster
     * @action_name:高级代理商宣传页
     * @action_description:
     * 帮助中心详情
     *
     * 请求示例:
     * {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           detail: {
     *                  title://标题
     *                  content://内容
     *              }
     *       }
     *   }
     * @action_doc_end
     */
    public function actionAgentPoster()
    {
        $helpModel = $this->model('AgentPoster');
        $info = $helpModel->_detail(['status' => 1]);
        $ret['detail'] = [];
        if ($info) {
            $ret['detail'] = [
                'title' => $info['title'],
                'content' => $info['content']
            ];
        }
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:getGameList
     * @action_name:获取游戏列表数据
     * @action_description:
     * 获取游戏列表数据
     * 使用场景：
     * 1.头部导航栏
     * 遍历一级数据，可以得到导航栏游戏分类：<a href="gamecenter/{{item.code}}">{{item.title}}</a>
     * 通过遍历一级数据对应下的children对象，获取游戏大厅：<a href="startgame(type_code,game_code)"><img src="/oss/game/menu/{{type_code}}/{{game_code}}.png" /></a>
     * *** type_code为游戏类型，由一级数据给出，如live:真人，fish:捕鱼
     * *** game_code为游戏，由二级数据给出，如ag_in:ag国际，ds:ds真人

     * 2.游戏大厅页
     * 同上，在游戏大厅页中，通过遍历一级数据对应下的children对象，获取游戏大厅：<a href="startgame(type_code,game_code)"><img src="/oss/game/list/{{type_code}}/{{game_code}}.png" /></a>
     * 对于电子游戏的图片地址有所不同，格式为：<a href="startgame(type_code,game_code,s_game_code)"><img src="/oss/game/list/{{type_code}}/{{game_code}}/{{s_game_code}}.png" /></a>
     * *** s_game_code为电子游戏中的小游戏，如SMG_108Heroes：108好汉
     * 
     * startgame方法：startgame(type,gamecode,s_gamecode),针对于非电子类游戏，没有s_gamecode
     * 前端需要编写一个startgame方法，该方法调用接口/api/thirdGame/startGame/{{type_code}}_{{game_code}}?game_code={{s_game_code}}
     * 接口将返回一个url,前端以新窗口的方式打开对应地址，即可进入游戏
     * 
     * 请求示例:
     * {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: {
     *                  'live': { //真人
     *                      id://游戏id
     *                      title://名称
     *                      code://游戏代码
     *                      tags://标签
     *                      is_sw://是否试玩 1试玩 0不是
     *                      is_wh://是否维护 1维护中 0正常
     *                      children: [
     *                          {
     *                              id://游戏id
     *                              title://名称
     *                              code://游戏代码
     *                              tags://标签
     *                              is_sw://是否试玩 1试玩 0不是
     *                              is_wh://是否维护 1维护中 0正常
     *                          },
     *                          {
     *                              id://游戏id
     *                              title://名称
     *                              code://游戏代码
     *                              tags://标签
     *                              is_sw://是否试玩 1试玩 0不是
     *                              is_wh://是否维护 1维护中 0正常
     *                          }
     *                      ]
     *                  },
     *                  'chess': { //棋牌
     *                      id://游戏id
     *                      title://名称
     *                      code://游戏代码
     *                      tags://标签
     *                      is_sw://是否试玩 1试玩 0不是
     *                      children: [
     *                          {
     *                              id://游戏id
     *                              title://名称
     *                              code://游戏代码
     *                              tags://标签
     *                              is_sw://是否试玩 1试玩 0不是
     *                              is_wh://是否维护 1维护中 0正常
     *                          }
     *                      ]
     *                  },
     *                  'electric': { //电子
     *                      id://游戏id
     *                      title://名称
     *                      code://游戏代码
     *                      tags://标签
     *                      is_sw://是否试玩 1试玩 0不是
     *                      children: [
     *                          {
     *                              id://游戏id
     *                              title://名称
     *                              code://游戏代码
     *                              tags://标签
     *                              is_sw://是否试玩 1试玩 0不是
     *                              is_wh://是否维护 1维护中 0正常
     *                              children: {
     *                                  '热门游戏': [
     *                                      {
     *                                          id://游戏id
     *                                          title://名称
     *                                          code://游戏代码
     *                                          tags://标签
     *                                          is_sw://是否试玩 1试玩 0不是
     *                                          is_wh://是否维护 1维护中 0正常
     *                                      }
     *                                  ]
     *                              }
     *                          }
     *                      ]
     *                  },
     *              }
     *       }
     *   }
     * @action_doc_end
     */
    public function actionGetGameList()
    {

        $list = $this->model('game')->_lists(['status' => 1], null, null, null, $field = "id,title,code,status,pid,tags,is_sw,is_wh");
        $list = $this->getTree($list);

        $gameOrder = [
            'mg' => ['热门游戏','最新游戏','老虎机','累计奖池','视频扑克','机台&卡牌'],
            'pt' => ['热门游戏','最新游戏','3-10线','15-20线','25+线','特色游戏','老虎机','累计奖池','刮刮乐']
        ];

        $newList = [];
        foreach ($list as $k => $v) {
            $newList[$k] = [
                'id' => $v['id'],
                'title' => $v['title'],
                'code' => $v['code'],
                'tags' => $v['tags'],
                'is_sw' => $v['is_sw'],
                'is_wh' => $v['is_wh'],
                'children' => []
            ];
            $keys = 0;
            foreach ($v['children'] as $kc => $vc) {
                $newList[$k]['children'][$keys] = [
                    'id' => $vc['id'],
                    'title' => $vc['title'],
                    'code' => $vc['code'],
                    'tags' => $vc['tags'],
                    'is_sw' => $vc['is_sw'],
                    'is_wh' => $vc['is_wh'],
                ];
                if (!empty($vc['children'])) {
                    foreach ($gameOrder[$vc['code']] as $kt=>$vt) {
                        foreach ($vc['children'] as $kcc=>$vcc) {
                            $tags = explode(',', $vcc['tags']);
                            if (in_array($vt, $tags)) {
                                $newList[$k]['children'][$keys]['children'][$kt]['title'] = $vt;
                                $newList[$k]['children'][$keys]['children'][$kt]['children'][] = [
                                    'id' => $vcc['id'],
                                    'title' => $vcc['title'],
                                    'code' => $vcc['code'],
                                    'tags' => $vcc['tags'],
                                    'is_sw' => $vcc['is_sw'],
                                    'is_wh' => $vcc['is_wh'],
                                ];
                            }
                        }
                    }
                } else {
                    $newList[$k]['children'][$keys]['children'] = (object) [];
                }
                ++$keys;
            }
        }
        unset($list, $gameOrder);
        return $this->success(['lists' => $newList]);
    }

    private function getTree(array $cate, $pid = 0)
    {
        $result = array();
        foreach ($cate as $k => $v) {
            if ($v['pid'] == $pid) {
                $v['children'] = self::getTree($cate, $v['id']);
                $result[$v['code']] = $v;
            }
        }
        return $result;
    }

}
