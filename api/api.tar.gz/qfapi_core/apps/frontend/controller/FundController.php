<?php

/**
 * @module_doc_start
 * @module_name:资金管理
 * @module_type:common
 * @module_descrition:
 * 该模块包含用户资金相关的1大接口：
 * 1.获得支付方式：payType
 * @module_doc_end
 */
class FundController extends iController
{
    // todo 当日额度
    private function getMaxAndMin($data)
    {
        $single_limit_min = $single_limit_max  = $day_limit_max = 0;
        if ($data) {
            $single_limit_min =  $data[0]['single_limit_min'];
            $single_limit_max = $data[0]['single_limit_max'];
            $day_limit_max = $data[0]['day_limit_max'];;
            foreach ($data as $val) {
                $single_limit_min = min($single_limit_min, $val['single_limit_min']);
                $single_limit_max = max($single_limit_max, $val['single_limit_max']);
                $day_limit_max = max($day_limit_max, $val['day_limit_max']);
            }
        }

        return ['sMin' => $single_limit_min, 'sMax' => $single_limit_max, 'dayMax' => $day_limit_max];
    }


    /**
     * @action_doc_start
     * @action_index:payType
     * @action_name:充值类型
     * @action_description:
     * 帮助中心详情
     *
     * 请求示例:
     * {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
                {
                    "pay_code": "bank",
                    "name": "银行卡转账",
                    "children": [ // 有可能为空
                        {
                            "id": "1",
                            "bank_name": "兴业银行", // 银行名称
                            "cardno": "6666 6666 6666 666", // 银行卡号
                            "bank": "CIB", // 银行简称
                            "realname": "姓名", // 姓名
                            "address": "兴业银行CIB", // 开户地址
                            "single_limit_max": "100.00", // 单笔最大限额
                            "single_limit_min": "10.00", // 单笔最小限额
                            "day_limit_max": "1000.55", // 单日限额
                            "user_tier": "1,2,3", // 用户分层
                            "pay_type": "bank" // 支付分类 bank 银行转账
                        },
                    ],
                    "limit": {
                        "sMin": "100.00",
                        "sMax": "100.00",
                        "dayMax": "1000.55"
                    }
                },
                {
                    "pay_code": "wechatpay",
                    "name": "微信",
                    "children": {
                        "third": null,
                        "qrcode": [ // 有可能为空
                              {
                                "id": "1",
                                "pay_code": "wechatpay",
                                "pay_name": "微信",
                                "qrcode_path": "二维码路径123",
                                "user_tier": "",
                                "single_limit_max": "0",
                                "single_limit_min": "0",
                                "day_limit_max": "0",
                                "remark": "描述123",
                                "pay_type": "qrcode" // 支付分类 qrcode 二维码扫码
                              },
                        ]
                    },
                    "limit": {
                        "sMin": "100.00",
                        "sMax": "100.00",
                        "dayMax": "1000.55"
                    }
                },
                {
                    "pay_code": "unionpay_kj",
                    "name": "网银快捷",
                    "children": {
                        "third": [
                            {
                                "channle_code": "bmw",
                                "pay_code": "unionpay_kj",
                                "single_limit_max": "100",
                                "single_limit_min": "10",
                                "day_limit_max": "1001",
                                "user_tier": "1,2,3",
                                "pay_type": "third" // 支付分类 third 第三方支付跳转
                            }
                        ],
                        "qrcode": null
                    },
                    "limit": {
                        "sMin": "10",
                        "sMax": "100",
                        "dayMax": "1001"
                    }
                }
            ]
     *   }
     * @action_doc_end
     */
    public function actionPayType()
    {
        $client = self::getAppNameByDevice();
        $clientData = ['pc' => 1,'h5' => 2];
        if (!isset($clientData[$client])) {
            return $this->error(3, '未知请求');
        }
        $client = $clientData[$client];

        $payType = Pay::$payType;

        $bank = $this->model('PayCompanyBank')->_lists(['status' => 1], null, null, null, 'id, bank_name, cardno, bank, realname, address, single_limit_max, single_limit_min, day_limit_max, user_tier');
        $third = $this->model('PayOnlineConfig')->_lists(['status' => 1], null, null, null, 'id, channle_code, pay_code, client_type, single_limit_max, single_limit_min, day_limit_max, user_tier');
        $qrcode = $this->model('PayQrcode')->_lists(['status' => 1], null, null, null, 'id, pay_code, pay_name, qrcode_path, user_tier, single_limit_max, single_limit_min, day_limit_max, remark');

        $temp1 =  $temp2 = [];
        foreach ($third as $value) {
            $value['pay_type'] = 'third';
            // 处理PC H5
            if ($value['client_type']) {
                $temp = explode(',', $value['client_type']);
                unset($value['client_type']);
                if ($client == 1 && in_array(1, $temp)) {
                    $temp1[$value['pay_code']][] = $value;
                }
                if ($client == 2 && in_array(2, $temp)) {
                    $temp1[$value['pay_code']][] = $value;
                }
            }
        }
        foreach ($qrcode as $value) {
            $value['pay_type'] = 'qrcode';
            $temp2[$value['pay_code']][] = $value;
        }
        foreach ($bank as $key => $val) {
            $bank[$key]['pay_type'] = 'bank';
        }

        foreach ($payType as $key => $value) {
            if ($value['pay_code'] == 'bank') {
                $payType[$key]['children'] = $bank;
                $payType[$key]['limit'] = $this->getMaxAndMin($bank);
            } else {
                $temp = [];
                if ($temp1[$value['pay_code']]) {
                    $temp = array_merge($temp, $temp1[$value['pay_code']]);
                }
                if ($temp2[$value['pay_code']]) {
                    $temp = array_merge($temp, $temp2[$value['pay_code']]);
                }
                $payType[$key]['children']['third'] = $temp1[$value['pay_code']];
                $payType[$key]['children']['qrcode'] = $temp2[$value['pay_code']];
                $payType[$key]['limit'] = $this->getMaxAndMin($temp);
            }
        }
        return $this->success($payType);
    }

    /**
     * @action_doc_start
     * @action_index:userFund
     * @action_name:用户资金信息
     * @action_description:
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{
     *              ablebalance:1,//可用余额
     *              frozenbalance:1,//冻结金额
     *              balance:1,//余额
     *              score:1,//积分
     *              handsel:1,//彩金
     *              dml:1,//打码量
     *           }
     *     }
     * @action_doc_end
     */
    function actionUserFund() {
        $UserFund = $this->model("UserFund")->_detail(["userid" => $this->member["id"]], 1,"ablebalance,frozenbalance,balance,score,handsel,dml");
        if($UserFund){
            return $this->success($UserFund);
        }else{
            return $this->error("获取用户资金信息失败");
        }
    }
    
     /**
     * @action_doc_start
     * @action_index:payOrder
     * @action_name:充值生成订单
     * @action_description:
     * 帮助中心详情
     *
     * 请求示例:
     * {
     *      data: {
     *           'pay_type': 'third', // 目前只能传递 third 或 qrcode
     *           'id': '',
     *           'money': '',
     *           'remark': '', // 会员填写的订单号或备注信息
     *      }
     * }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *          status: true
     *          href: "http://www.baidu.com", // 跳转第三方支付 暂未确定
     *          qrcode: "https://ss1.baidu.com/6ONXsjip0QIZ8tyhnq/it/u=1750833952,2529388352&fm=58&bpow=380&bpoh=380", // 第三方的扫码支付 暂未确定
     *      }
     *   }
     * @action_doc_end
     */
    public function actionPayOrder()
    {
        $client = parent::getAppNameByDevice();
        $clientData = ['pc' => 1,'h5' => 2];
        if (!isset($clientData[$client])) {
            return $this->error(3, '未知请求');
        }
        $client = $clientData[$client];

        $data = $this->input('post.data');
        if (empty($data)) {
            return $this->error(3, '参数错误');
        }
        if (empty($data['money']) || empty($data['pay_type']) || ($data['pay_type'] != 'third' && $data['pay_type'] != 'qrcode')) {
            return $this->error(3, '参数错误');
        }

        // 目前需要生产订单的只有第三方支付 和 扫码支付
        $this->moduleModel = $data['pay_type'] == 'third' ? 'PayOnlineConfig' : 'PayQrcode';
        $payData = $this->model($this->moduleModel)->_detail(['id' => $data['id']]);

        if (empty($payData) || ($data['pay_type'] == 'third' && !in_array($client, explode(',', $payData['client_type'])))) {
            return $this->error(3, '支付方式不存在');
        }

        $href = $qrcode = '';
        if ($data['pay_type'] == 'third') {
            // TODO 跳转链接进行支付
            $href = 'http://www.baidu.com';
            unset($payData['buession_key']);
        } else {
            $qrcode = $data['pay_type'];
        }

        $this->getLock('add_order', 5);
        $orderData = [
            'userid' => $this->member['id'],
            'username' => $this->member['username'],
            'money' => $data['money'],
            'pay_model' => $this->moduleModel,
            'pay_type' => $data['pay_type'],
            'pay_code' => $payData['pay_code'],
            'channle_code' => $payData['channle_code'],
            'order_no' => (new Order())->createOrderNo('CK', 'UserRecharge'),
            'order_pay_id' =>  $data['id'],
            'order_pay_data' => json_encode($payData),
            'create_day' => date('Ymd'),
            'user_remark' => $data['remark']
        ];

        if ($this->model('UserRecharge')->_insert($orderData)) {
            $resultData = $this->success(['status' => true, 'href' => $href, 'qrcode' => $qrcode]);
        } else {
            $resultData = $this->error(1000, '网络错误，请稍后再试');
        }

        $this->unLock('add_order');
        return $resultData;
    }
}
