<?php

/**
 * 定时任务处理类
 */
class CrontabController extends iController
{

    public static $abc = 1;

    public function actionTest() {

        if (!empty($this->checkLock('frontend_user_transfer'))) return 1;
        $this->getLock('frontend_user_transfer', 300);
        iLog::write(self::$abc, 'test');

    }


    /**
     * 处理平台转账
     *
     * 1、余额转入第三方平台（首先将余额钱扣除，然后去第三方上分，如果上分失败则回滚事务，插入异常队列中，等待其他任务处理完成后在重新执行扣款操作流程）
     *
     * 2、第三方转入余额（先将第三方平台的钱扣除，然后在余额内加钱；流程同上。）
     *
     * 3、第三方转入第三方平台
     *      说明：1）先将转入方第三方平台钱下分，如果下分异常则回滚事务，插入异常队列中，等待其他任务处理完成后在重新执行扣款操作流程；
     *            2）如果第一步操作成功，则直接将转入方的金额增加，如果转入失败，则增加用户资金，并将记录标为转账异常
     *
     * 4、闪入（以第三方平台为参照物，是将余额里的钱转入到第三方）
     *
     * 5、闪出（以第三方平台为参照物，是将第三方的钱转入到余额）
     *
     */
    public function actionTransfer()
    {

//        if (!empty($this->checkLock('frontend_user_transfer'))) return 1;
//        $this->getLock('frontend_user_transfer', 300);

        $data = iCache::redis('get', 'frontend_user_transfer_error_data');
        $data = $data ? json_decode($data) : '';

        //获取10条未转账的记录
        $utMod = $this->model('user_transfer');
        $where['status'] = 1;
        if ($data)
            $where['id'] = ['not in', $data];

        $list = $utMod->_lists($where, null, 10, null, 'id,userid,third_order_id,order_id,platform_from,platform_to,amount,type');

        //如果没有最新需要处理的转账，则将之前积累有异常的数据在拿出来重新执行。
        if (empty($list) && !empty($data)) {
            $where['id'] = ['in', $data];
            $list = $utMod->_lists($where, null, null, null, 'id,userid,third_order_id,order_id,platform_from,platform_to,amount,type');
        }

        //获取游戏维护或者禁用的平台（转账时需要做检测）
        $game = $this->model('game')->_lists(['status' => 0, 'or', 'is_wh' => 1], null, null, null, 'id,code,pid,title,status,is_wh');
        $disable = [];
        if (!empty($game)) {
            foreach ($game as $k => $v) {
                $rs = $this->model('game')->_detail(['id' => $v['pid']], null, 'code');
                if (!$v['status'])
                    $disable[$rs['code'] . '_' . $v['code']] = '第三方平台已被禁用';
                if ($v['is_wh'] == 1)
                    $disable[$rs['code'] . '_' . $v['code']] = '第三方平台正在维护';
            }
        }

        if (!empty($list)) {

            $uIds = array_column($list, 'userid');
            $uIds = array_unique($uIds);
            $uList = $this->model('third_user')->_lists(['userid' => ['in', $uIds]], null, null, null, '*');
            $nuList = [];
            foreach ($uList as $k => $v) {
                $nuList[$v['userid']] = $v;
            }
            unset($uList);

            $uFnd = $this->model('user_fund');

            $errorArr = [];
            $successArr = [];
            foreach ($list as $k => $v) {
                iModel::_begin();

                //检测转入方是否被禁用
                if (isset($disable[$v['platform_from']])) {
                    $utMod->_update(['remark' => $disable[$v['platform_from']], 'status' => 0], ['id' => $v['id']]);
                    iModel::_end();
                    continue;
                }
                //检测转出方是否被禁用
                if (isset($disable[$v['platform_to']])) {
                    $utMod->_update(['remark' => $disable[$v['platform_to']], 'status' => 0], ['id' => $v['id']]);
                    iModel::_end();
                    continue;
                }

                if ($v['type'] == 1) {
                    //闪入（将所有余额的钱转入到第三方）
                    $info = $uFnd->_detail(['userid' => $v['userid']], null, 'ablebalance');
                    $balance = floor($info['ablebalance']);
                    if ($balance < 1) {
                        $utMod->_update(['remark' => '账户余额不足', 'status' => 0], ['id' => $v['id']]);
                        iModel::_end();
                        continue;
                    }

                    //给用户下分
                    $uFnd->_update(['ablebalance' => '`ablebalance`-' . $balance], ['userid' => $v['userid']]);

                    //第三方上分
                    $gameCode = 'Game' . $this->toTuoFeng($v['platform_to']);
                    $objGame = new $gameCode;
                    $rs = $objGame->changeOut($nuList[$v['userid']], $balance);
                    if (false == $rs) {
                        $errorArr[] = $v['id'];
                        iModel::_back();
                        continue;
                    }
                } elseif ($v['type'] == 2) {
                    //闪出（将第三方所有的钱全部转回余额）
                    $gameCode = 'Game' . $this->toTuoFeng($v['platform_from']);
                    $objGame = new $gameCode;
                    $balance = $objGame->getBalance($nuList[$v['userid']]);
                    if ($balance == false) {
                        $errorArr[] = $v['id'];
                        iModel::_back();
                        continue;
                    }
                    $balance = floor($balance);
                    //如果余额小于1块，则转入失败。
                    if ($balance < 1) {
                        $utMod->_update(['remark' => '第三方账户余额不足', 'status' => 0], ['id' => $v['id']]);
                        iModel::_end();
                        continue;
                    }

                    //第三方下分
                    $rs = $objGame->changeIn($nuList[$v['userid']], $balance);
                    if (false == $rs) {
                        $errorArr[] = $v['id'];
                        iModel::_end();
                        continue;
                    }

                    //给用户上分
                    $uFnd->_update(['ablebalance' => '`ablebalance`+' . $balance], ['userid' => $v['userid']]);

                } else {

                    if ($v['platform_from'] == 'center') {
                        //将余额转入第三方
                        $fund = $uFnd->_detail(['userid' => $v['userid']], null, 'ablebalance');
                        //余额不足的情况
                        if ($v['amount'] > $fund['ablebalance'] || $fund['ablebalance'] <= 0) {
                            $rs = $utMod->_update(['remark' => '账户余额不足', 'status' => 0], ['id' => $v['id']]);
                            if (false == $rs) {
                                iModel::_back();
                            }
                            continue;
                        }

                        $gameCode = 'Game' . $this->toTuoFeng($v['platform_to']);
                        $objGame = new $gameCode;

                        $rs = $objGame->changeOut($nuList[$v['userid']], $v['amount']);
                        if (false == $rs) {
                            $errorArr[] = $v['id'];
                            iModel::_back();
                            continue;
                        }

                        $uFnd->_update(['ablebalance' => '`ablebalance`-' . $v['amount']], ['userid' => $v['userid']]);

                    } else {
                        //将第三方转入余额
                        if ($v['platform_from'] == 'center') {
                            $gameCode = 'Game' . $this->toTuoFeng($v['platform_to']);
                        } else {
                            $gameCode = 'Game' . $this->toTuoFeng($v['platform_from']);
                        }
                        $objGame = new $gameCode;
                        $balance = $objGame->getBalance($nuList[$v['userid']]);
                        if ($balance == false) {
                            $errorArr[] = $v['id'];
                            iModel::_back();
                            continue;
                        }

                        //如果转账金额大于余额
                        if ($v['amount'] > $balance ) {
                            $utMod->_update(['remark' => '第三方账户余额不足', 'status' => 0], ['id' => $v['id']]);
                            iModel::_end();
                            continue;
                        }
                        $rs = $objGame->changeIn($nuList[$v['userid']], $v['amount']);
                        if (false == $rs) {
                            $errorArr[] = $v['id'];
                            iModel::_back();
                            continue;
                        }

                        $uFnd->_update(['ablebalance' => '`ablebalance`+' . $v['amount']], ['userid' => $v['userid']]);
                    }

                }

                $utMod->_update(['status' => 2], ['id' => $v['id']]);

                //记录成功的数据
                $successArr[] = $v['id'];
                iModel::_end();
            }

            //成功处理完数据后，检测成功处理的数据是否在错误里面。如果存在则踢除。
            if (!empty($successArr) && $data) {
                //和之前的错误数据比较，求差集。
                $diff = array_diff($data, $successArr);
                if (empty($diff)) {
                    iCache::redis('set', 'frontend_user_transfer_error_data', '');
                } else {
                    iCache::redis('set', 'frontend_user_transfer_error_data', json_encode(array_values($diff)));
                }
            }

            //如果有错误数据，和以前的合并后在更新
            if (!empty($errorArr)) {
                if (empty($data)) $data = $errorArr;
                else $data = array_merge($data, $errorArr);
                iCache::redis('set', 'frontend_user_transfer_error_data', json_encode($data));
            }

        }

        unset($list, $errorArr, $successArr, $diff);

        $this->unLock('frontend_user_transfer');
        return 2;
    }

    protected function toTuoFeng($uncamelized_words, $separator = '_')
    {
        $uncamelized_words = $separator . str_replace($separator, " ", strtolower($uncamelized_words));
        return ucfirst(ltrim(str_replace(" ", "", ucwords($uncamelized_words)), $separator));
    }

}
