<?php

/**
 * @module_doc_start
 * @module_name:框架基础模块
 * @module_description:
 * 该模块包含包含系统基础的：图像验证码、自动化文档、自动化模型
 * 交互基础
 *
 * 1.前段请求方式：请使用post（全部！！）
 *
 * 2.请求的格式：
 *     {
 *          device:"brower",//每次请求必填参数。设备类型，有产品需求定义，不同设备，如ios/android/pc_client/pc_web/mobile_web,用于区分接口调用的不同来源
 *          accesss_token:"xxxx",//每次请求必填参数。保持会话必须，如果客户端无则值为空字符串，服务端将在当前请求的返回值中返回一个合法的access_token,客户端每次查验到服务端接口中有返回access_token需要保存最新access_token
 *          "其他参数1":"其他参数1的值",//可以是多层级对象,根据具体接口文档传参
 *     }
 *
 * 3.返回值：
 *     3.1：格式为json
 *     3.1: http状态码非200提示"网络不给力,请重试"
 *     3.2: http状态码为200根据返回json数据状态处理
 *     {
 *          code:0,//状态码，0:正常，成功数据交互，1：通用错误，将会在msg中返回可面向用户提示的消息，3：参数错误，同样会在msg中返回消息  401：请登录   404:接口不存在
 *          msg:""//错误消息
 *          data:{
 *              //当code为0时的返回数据，一定是对象，而非数组
 *          },
 *          spend_time_all:2,//debug模式下供调试使用，该值为后端接口处理总耗时，单位为ms
 *          _sql_commands: [],//debug模式下供调试使用，该值为后端接口数据库每个io耗时，单位为ms
 *          _session_commands: ["get|[\"accesstoken_brower##1553161232##675c61d31280e78f7fe67dfb6cee6e7ff21cc4f7\"][fd][spt:0.066041946411133]"],//debug模式下供调试使用，该值为后端接口会话的每个io耗时，单位为ms
 *          _cache_commands: []//debug模式下供调试使用，该值为后端接口数据缓存每个io耗时，单位为ms
 *          access_token:''//如果服务器检测到旧的token失效了，会生成新的token返回。客户端请收到该token后将会员信息清除。
 *     }
 *
 * @module_doc_end
 */
class BaseController extends iController
{

    public $needCheckAccess = false;

    private $imgCode = [
        1 => 'register',
        2 => 'find_password'
    ];

    private $mbCode = [
        1 => 'register',
        2 => 'find_password'
    ];

    private $emCode = [
        1 => 'bind_email'
    ];

    /**
     * @action_doc_start
     * @action_index:getImgCheckCode
     * @action_name:获取图形验证码
     * @action_description:
     * 获取图形验证码
     * 参数：
     * - type  int     not null   类型：1.注册; 2.找回密码
     *
     * 请求示例:
     *     {
     *          type:1
     *     }
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           image:"data:image/png;base64,xxxxxx"//图形验证码base64字符串
     *       }
     *   }
     * @action_doc_end
     */
    function actionGetImgCheckCode()
    {

        $type = (int)$this->input('post.type');
        if (!isset($this->imgCode[$type]))
            return $this->error(3, '类型无效');
//        $this->contentType = "image/png";
        $authnum = new iAuthnum();
        $authnum->ext_num_type = 3;
        $img = $authnum->create(true);
        iSession::set(array($this->imgCode[$type] . "_authnum" => $authnum->randnum));
        return $this->success(['image' => $img]);
    }


    /**
     * @action_doc_start
     * @action_index:getMobileCheckCode
     * @action_name:获取手机验证码
     * @action_description:
     * 获取手机验证码
     * 参数：
     * - type  int     not null   类型：1.注册;
     * - phone string  not null   手机号
     *
     * 请求示例:
     *     {
     *          type:1,
     *          phone:13111111111
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           sms_code:""//手机验证码，目前还未接入手机运营商暂且未测试模式，上线后会取消返回。
     *       }
     *   }
     * @action_doc_end
     */
    function actionGetMobileCheckCode()
    {

        $phone = (int)$this->input('post.phone');
        $type = (int)$this->input('post.type');
        if (!isset($this->mbCode[$type]))
            return $this->error(3, '类型无效');

        if (!$this->validate($this->preg['mobile'], 'post.phone', $phone))
            return $this->error(3, '手机号格式不正确');

        //检测发送验证码是否超时 间隔60s才能发送
        $time = iSession::get($this->mbCode[$type] . '_mobile_time');
        if ($time > 0 && (time() - $time) < 60) {
            return $this->error(1, '请勿重复发送验证码');
        } else {
            iSession::set([$this->mbCode[$type] . '_mobile_time' => 0]);
        }

        $ret = iSms::send($phone);
        if (false == $ret['status']) return $this->error($ret['msg']);

        $res = [
            $this->mbCode[$type] . "_mobile_code" => $ret['sms_code'],
            $this->mbCode[$type] . '_mobile_time' => time()
        ];
        //如果为注册，则将生成随机密码发送给客户
        if ($type == 1)
            $res[$this->mbCode[$type] . '_password'] = rand(100000, 999999);

        iSession::set($res);
        return $this->success(['sms_code' => $ret['sms_code']]);
    }


    /**
     * @action_doc_start
     * @action_index:getEmailCheckCode
     * @action_name:获取邮箱验证码
     * @action_description:
     * 获取邮箱验证码
     * 参数：
     * - type  int     not null   类型：1.绑定邮箱;
     * - email string  not null   邮箱
     *
     * 请求示例:
     *     {
     *          type:1,
     *          email:'morris@irainbow7.com'
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{}
     *   }
     * @action_doc_end
     */
    function actionGetEmailCheckCode()
    {

        $email = (string)$this->input('post.email');
        $type = (int)$this->input('post.type');
        if (!isset($this->emCode[$type]))
            return $this->error(3, '无效的类型');

        if (!$this->validate($this->preg['email'], 'post.email', $email))
            return $this->error(3, '邮箱格式不正确');

        //检测发送验证码是否超时 间隔60s才能发送
        $time = iSession::get($this->emCode[$type] . '_time');
        if ($time > 0 && (time() - $time) < 60) {
            return $this->error(1, '请勿重复发送验证码');
        } else {
            iSession::set([$this->emCode[$type] . '_time' => 0]);
        }

        $sms_code = rand(100000, 999999);
        $smtp = new iSmtp();

        switch ($type) {
            case '1' :
                $title = '太阳娱乐城绑定邮箱';
                $content = '亲爱的用户，欢迎您使用太阳娱乐城账号，您的邮箱验证码：' . $sms_code . '，请使用该验证码完成绑定邮箱操作，感谢您的支持！';
                break;
            default;

        }

        $smtp->send($email, $title, $content);
        iSession::set([$this->emCode[$type] . "_code" => $sms_code, $this->emCode[$type] . "_time" => time()]);

        return $this->success();
    }

    /**
     * @action_doc_start
     * @action_index:getBankName
     * @action_name:获取银行卡名称
     * @action_description:
     * 获取银行卡名称
     * 参数：
     * - bankNo string  not null   银行卡号
     *
     * 请求示例:
     *     {
     *          bankNo:'6221506020009066385'
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           bank_name:""//银行卡名称
     *       }
     *   }
     * @action_doc_end
     */
    function actionGetBankName()
    {

        $bankNo = (string) $this->input('post.bankNo');

        $checkBank = new CheckBank();
        $rs = $checkBank->checkBankCard($bankNo);
        if (false == $rs)
            return $this->error(3, '银行卡格式不正确');

        $validateBank = $checkBank->validateBankNo($bankNo);
        if (false == $validateBank)
            return $this->error(3, '银行卡格式不正确');

        if (!empty($validateBank) && false == $validateBank['validated'])
            return $this->error(3, '银行卡号错误');

        return $this->success(['bank_name' => $validateBank['bankName']]);
    }


    /**
     * @action_doc_start
     * @action_index:doc
     * @action_name:获取API文档
     * @action_description:
     * 将以网页的形式展示该服务下的接口文档
     * @action_doc_end
     */
    function actionDoc()
    {
        if (!DEBUG) {
            return "不允许的哟，小坏蛋";
        }
        //获取模型信息
        $model_dir = APP_DIR . "/bin/model";
        $files_model = scandir($model_dir);
        $model_info = array();
        $no_need_explane_files_arr = array(".", "..", "_Empty.php", '_FrontendController.php');
        foreach ($files_model as $file) {
            if (!in_array($file, $no_need_explane_files_arr)) {
                $model_content = file_get_contents($model_dir . "/" . $file);
                $model_index = ucfirst(substr($file, 0, -4));

                $pattern_model_name = "/模型名[:：] ([\S]+)/";
                $model_name = preg_match($pattern_model_name, $model_content, $matches_model_name) ? $matches_model_name[1] : $model_index;

                $pattern_model_description = "/模型解释 start：([\s\S]*)模型解释 end：/U";
                $model_description = preg_match($pattern_model_description, $model_content, $matches_model_description) ? $matches_model_description[1] : "";

                //模型信息
                $model_info[$model_index] = array(
                    "model_index" => $model_index,
                    "model_name" => $model_name,
                    "model_description" => trim(preg_replace("/[\r\n][ ]*\*/", "\r\n", $model_description))
                );
            }
        }

        $files_controller = scandir(__DIR__);
        $doc = array();
        foreach ($files_controller as $file) {
            if (!in_array($file, $no_need_explane_files_arr)) {
                $content = file_get_contents(__DIR__ . "/" . $file);
                $module_index = lcfirst(substr($file, 0, -14));
                $pattern_module_name = "/@module_name[:：]([\S]+)/";
                $module_name = preg_match($pattern_module_name, $content, $matches_module_name) ? $matches_module_name[1] : $module_index;

                $pattern_module_model = "/@module_model[:：]([\S]+)/";
                $module_model = preg_match($pattern_module_model, $content, $matches_module_model) ? $matches_module_model[1] : "";

                $pattern_module_description = "/@module_description[:：]([\s\S]+)@module_doc_end/U";
                $module_description = preg_match($pattern_module_description, $content, $matches_module_description) ? $matches_module_description[1] : "";

                $module_model_info = isset($model_info[$module_model]) ? $model_info[$module_model] : null;
                $doc[$module_index] = array(
                    "module_index" => $module_index,
                    "module_name" => $module_name,
                    "module_description" => trim(preg_replace("/[\r\n][ ]*\*/", "\r\n", $module_description)),
                    "module_model_info" => $module_model_info
                );

                $actions = array();

                $pattern_actions = "/@action_doc_start[\s\S]*?@action_doc_end/";
                if (preg_match_all($pattern_actions, $content, $matches_actions)) {
                    $matches_actions = $matches_actions[0];
                    foreach ($matches_actions as $actions_str) {
                        $action_index = lcfirst(preg_match("/@action_index[:：]([\S]+)/", $actions_str, $matches_action_index) ? $matches_action_index[1] : "");
                        $action_name = preg_match("/@action_name[:：]([\S]+)/", $actions_str, $matches_action_name) ? $matches_action_name[1] : $action_index;
                        $action_description = preg_match("/@action_description[:：]([\s\S]+)@action_doc_end/U", $actions_str, $matches_action_description) ? $matches_action_description[1] : "";
                        if (empty($action_index)) {
                            continue;
                        }

                        $actions[$action_index] = array(
                            "action_index" => $action_index,
                            "action_name" => $action_name,
                            "action_description" => preg_replace("/[\r\n][ ]*\*/", "\r\n", $action_description),
                        );
                    }
                }

                $doc[$module_index]["actions"] = $actions;
            }
        }

        $docbase = $doc["base"];
        unset($doc["base"]);
        $newdoc = array(
            "base" => $docbase
        );
        $newdoc = array_merge($newdoc, $doc);

        $data = array(
            "doc" => $newdoc
        );

        return $this->display(null, $data);
    }

}
