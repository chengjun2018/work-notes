<?php

/**
 * @module_doc_start
 * @module_name:第三方游戏接口
 * @module_type:common
 * @module_descrition:
 * 该模块包含第三方游戏的5大接口：
 * 1.进入游戏：startGame
 * 2.获取余额：gameBalance
 * 3.资金转入转出：change
 * 4.检查资金转入转出状态：checkTransferStatus
 * 5.获取游戏记录：getGameList
 * @module_doc_end
 */
class ThirdGameController extends _FrontendController {

    private $thirdUser = null;

    public function beforeAction() {
        $this->thirdUser = $this->model('thirdUser')->_detail(['userid' => $this->member["id"]], 1, '*');
        if (empty($user)) {
            $user = array();
            $user['userid'] = $this->member['id'];
            $user['username'] = $this->member['username'];
            $isok = $this->model('third_user')->_insert($user);
            if (false == $isok) {
                return $this->error("请求失败，请重试");
            }
            $this->thirdUser = $user;
        }

        if (in_array($this->action, ["CheckTransferStatus"])) {
            return true;
        }

        //验证游戏是否存在
        $gamecodes = $this->params; //live_ag_fa/center
        if (count($gamecodes) > 0) {
            foreach ($gamecodes as $gamecode) {
                if ($gamecode == "center") {
                    continue;
                }
                $codeArr = explode('_', $gamecode, 2);
                if (count($codeArr) < 2) {
                    return $this->error("游戏不存在");
                }
                //验证游戏类型
                $GameType = $this->model("Game")->_detail(["code" => $codeArr[0], "pid" => 0, "status" => [">=", 0]], 1); //整个站点1秒内只访问一次数据库，无论多少并发
                if (empty($GameType)) {
                    return $this->error("游戏不存在");
                }
                if ($game["status"] == "0") {
                    return $this->error("游戏已关闭");
                }
                if ($game["is_wh"] == "1") {
                    return $this->error("游戏维护中...");
                }
                //验证游戏
                $game = $this->model("Game")->_detail(["code" => $codeArr[1], "pid" => $GameType["id"], "status" => [">=", 0]], 1); //整个站点1秒内只访问一次数据库，无论多少并发
                if (empty($game)) {
                    return $this->error("游戏不存在");
                }
                if ($game["status"] == "0") {
                    return $this->error("游戏已关闭");
                }
                if ($game["is_wh"] == "1") {
                    return $this->error("游戏维护中...");
                }
            }
            return true;
        }
        return $this->error("游戏不存在");
    }

    /**
     * @action_doc_start
     * @action_index:startGame
     * @action_name:开始游戏
     * @action_description:
     * 路由地址：/thirdGame/startGame/[游戏平台：live_ag_in(ag真人国际厅)]
     * 
     * get参数：
     * game_code:游戏code---电子游戏类需要
     * model:模式---real/test，默认real,代表真实游戏，test表示试玩
     * 
     * 返回数据：
     * {
     *      code:0,//1
     *      msg:"",//游戏不存在|游戏已被禁止|游戏维护中|进入游戏失败
     *      data:{
     *          url:"xxxx"//游戏跳转地址，客户端拿到该地址后需要进行跳转以进入第三方游戏
     *      }
     * }
     * @action_doc_end
     */
    public function actionStartGame($type) {
        $gameCode = "Game" . $this->toTuoFeng($type);
        if (class_exists($gameCode)) {
            $game_code = $this->input("get.game_code", $this->input("post.game_code"));
            $model = $this->input("get.model", $this->input("post.model", "real"));
            $user = $this->thirdUser;
            $objGame = new $gameCode;
            $ret = $objGame->startGame($user, $game_code, $model);
            if ($ret == false) {
                return $this->error("进入游戏失败");
            } else {
                return $this->success(['url' => $ret]);
            }
        } else {
            iLog::write("游戏" . $gameCode . "通过验证，但对象不存在");
            return $this->error("游戏不存在");
        }
    }

    /**
     * @action_doc_start
     * @action_index:getBalance
     * @action_name:获取第三方余额
     * @action_description:
     * 路由地址：/thirdGame/getBalance/[游戏平台：live_ag_in(ag真人国际厅)]
     * 
     * 无参数：
     *
     * 返回数据：
     * {
     *      code:0,//1
     *      msg:"",//获取余额失败|游戏不存在!!
     *      data:{
     *          balance:"xxxx"//游戏余额
     *      }
     * }
     * @action_doc_end
     */
    public function actionGetBalance($type) {
        $gameCode = 'Game' . $this->toTuoFeng($type);
        if (class_exists($gameCode)) {
            $objGame = new $gameCode;
            $user = $this->thirdUser;
            $balance = $objGame->getBalance($user);
            if ($balance === false) {
                return $this->error("获取余额失败");
            } else {
                return $this->success(['balance' => number_format($balance, 2)]);
            }
        } else {
            iLog::write("游戏" . $gameCode . "通过验证，但对象不存在");
            return $this->error("游戏不存在!!");
        }
    }

    /**
     * @action_doc_start
     * @action_index:change
     * @action_name:提交转账
     * @action_description:
     * 路由地址：/thirdGame/change/[转出游戏平台：live_ag_in(ag真人国际厅)]/[转入游戏平台：live_ag_in(ag真人国际厅)]
     * 中心钱包code为center
     * eg:转入ag国际厅 /thirdGame/change/center/live_ag_in
     * eg:ag提现 /thirdGame/change/live_ag_in/center
     * 
     * post参数：
     * {
     *      type:0,//转账类型（0：普通转账，1：闪入，2：闪出，闪入闪出以第三方平台为基准，"一键转入"功能属于闪出）
     *      amount:1000,转账金额（当转账类型为普通转账时必填，格式必须是大于0的整数）
     * }
     * 
     * 返回数据：
     * {
     *      code:0,//1
     *      msg:"",//转入平台和转出平台不可一致|转账类型错误|转账金额不能包含小数|转账金额必须大于0|转账失败，请稍后重试
     *      data:{
     *          //转账记录订单号，通过该值使用接口：/thirdGame/changeStatus获取转账状态，该接口将返回三种状态：0：失败，1：处理中，2：完成。
     *          //当处理完成如果页面需要获取用户最新余额，则可以调用用户账户资金接口和刷新游戏厅余额，更新用户资金信息展示
     *          order_id: "ZZ201812120315123564"
     *      }
     * }
     * @action_doc_end
     */
    public function actionChange($from, $to) {
        if ($from == $to) {
            return $this->error("转入平台和转出平台不可一致");
        }
        $type = (int) $this->input("post.type", 0);
        if (!in_array($type, [0, 1, 2])) {
            return $this->error("转账类型错误");
        }
        if ($type == 0) {
            $amount = $this->input("post.amount", 0);
            if ($amount != (int) $amount) {
                return $this->error("转账金额不能包含小数");
            } elseif ($amount <= 0) {
                return $this->error("转账金额必须大于0");
            }
        } else {
            $amount = 0;
        }

        $transfer_arr = [];
        if ($from !== "center") {
            $transfer_arr[] = ["from" => $from, "to" => "center"];
        }
        if ($to !== "center") {
            $transfer_arr[] = ["from" => "center", "to" => $to];
        }

        $order_id = "ZZ" . self::getUnquireId();//todo 并发不唯一

        iModel::_begin();
        $ret = true;
        foreach ($transfer_arr as $transfer) {
            //添加转账订单
            $data = array(
                "order_id" => $order_id,
                "userid" => $this->member["id"],
                "username" => $this->member["username"],
                "platform_from" => $transfer["from"],
                "platform_to" => $transfer["to"],
                "amount" => $amount,
                "status" => 1,
                "type" => $type
            );
            $ret = $this->model("UserTransfer")->_insert($data);
            if ($ret === false) {
                break;
            }
        }
        iModel::_end();

        if ($ret === false) {
            return $this->error("转账失败，请稍后重试");
        } else {
            return $this->success(["order_id" => $order_id]);
        }
    }

    /**
     * @action_doc_start
     * @action_index:getGameList
     * @action_name:获取第三方投注记录
     * @action_description:
     * 
     * 路由地址：/thirdGame/getGameList/[游戏平台：live_ag_in(ag真人国际厅)]
     * 
     * post参数：
     * {
     *      where:{
     *          end_time:[
     *              "bettwen",
     *              [
     *                  "2018-12-11 23:34:56",//记录中结算的最早日期，包含时间点，格式：2018-12-11 23:34:56
     *                  "2018-12-11 23:34:56"//记录中结算的最晚日期，包含时间点，格式：2018-12-12 23:34:56
     *              ]
     *          ]
     *      },
     *      page:1 //分页
     *      page_size:20 //分页大小，默认20
     * }
     * 
     * 返回数据：
     * {
     *      code:0,//1
     *      msg:"",//获取余额失败
     *      data:{
     *          lists: [
     *              {
     *                   end_time: "",//结算时间
     *                   order_id: "20190112152634", //注单号
     *                   game_name: "百家乐", //游戏名称
     *                   amount: "9", //投注金额
     *                   valid_amount: "9", //有效投注额
     *                   win: "9" //输赢金额
     *                   table_name: "9" //
     *              }
     *          ],
     *          total_num:10,//总结记录数
     *          total_page:12,//总计分页数
     *      }
     * }
     * @action_doc_end
     */
    public function actionGetGameList($type) {
        $now = strtotime(date('Y-m-d 00:00:00'));
        $d_start_time = date("Y-m-d H:i:s", $now - 3600 * 24 * 30);
        $d_end_time = date("Y-m-d H:i:s", time());
        $where = (array) $this->input("post.where", []);
        $end_time_arr = $where['end_time'][1];
        if (!isset($end_time_arr[0])) {
            $end_time_arr[0] = $d_start_time;
        }
        if (!isset($end_time_arr[1])) {
            $end_time_arr[1] = $d_end_time;
        }
        if (strtotime($end_time_arr[0]) < $d_start_time) {
            return $this->error("无法查询早于30天前游戏记录");
        }
        if (strtotime($end_time_arr[1]) > time()) {
            $end_time_arr[1] = $d_end_time;
        }

        $page = (int) $this->input("post.page", 1);
        $page_size = (int) $this->input("post.page_size", 20);

        $gameCode = 'Game' . $this->toTuoFeng($type);
        if (class_exists($gameCode)) {
            $objGame = new $gameCode;
            $user = $this->thirdUser;
            $ret = $objGame->getGameList($user, $end_time_arr[0], $end_time_arr[1], $page, $page_size);
            return $this->success($ret);
        } else {
            iLog::write("游戏" . $gameCode . "通过验证，但对象不存在");
            return $this->error("游戏不存在!!");
        }
    }

    /**
     * @action_doc_start
     * @action_index:checkTransferStatus
     * @action_name:检查转账状态
     * @action_description:
     * post参数：
     * {
     *      where:{
     *          order_id:"ZR201901340548",//转账的id
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,//0|1
     *      msg:"",//转账不存在
     *      data:{
     *          status:0, //0：失败，1：处理中，2：完成
     *      }
     * }
     * @action_doc_end
     */
    public function actionCheckTransferStatus() {
        $order_id = $this->input("post.where.order_id");
        $ret = $this->model("UserTransfer")->_detail(["order_id" => $order_id], 1);
        $data = array(
            "status" => 6
        );
        if ($ret) {
            if ($ret["userid"] != $this->member["id"]) {
                return $this->error("转账不存在");
            }
            $data = array(
                "status" => $ret["status"]
            );
        }
        return $this->success($data);
    }

}
