<?php

/**
 * @module_doc_start
 * @module_name:前台用户接口服务
 * @module_type:common
 * @module_descrition:
 * @module_doc_end
 */
class UserController extends _FrontendController
{

    public $needCheckAccess = false;
    
    public $noNeedCheckAction = array("UserReg","UserLogin","FindPassword");

    /**
     * @action_doc_start
     * @action_index:userLogin
     * @action_name:用户登录
     * @action_description:
     * 用户登录操作
     * 参数：
     * - username string  not null
     * - password string  not null
     * - domain   string  not null
     *
     * 请求示例:
     *     {
     *          username:'morris',
     *          password:'123qwe',
     *          domain:'www.baidu.com'//（Android || IOS 不用传递此参数）其他设备需传
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           detail:{
     *              id,//id
     *              realname,//真实姓名
     *              username,//账号
     *              status,//状态
     *              tierid,//会员层级ID
     *              istrue,//是否真实用户
     *              phone,//手机号
     *              out_password,//取款密码
     *              remark,//备注
     *              mast_dml,//要求打码量
     *              rmd_code,//推荐码
     *              agent_id,//代理id
     *              qq ,//绑定qq
     *              wechat,//绑定微信
     *              email,//绑定email
     *              ablebalanc,//可用余额
     *              score,//积分
     *              handsel,//彩金
     *              dml,//打码量
     *              is_out_pwd,//是否绑定了取款密码，1已绑定 0未绑定
     *              is_bind_bank,//是否绑定银行卡 1已绑定 0未绑定
     *          }
     *       }
     *   }
     * @action_doc_end
     */
    function actionUserLogin()
    {

        $username = (string)$this->input('post.username');
        $password = (string)$this->input('post.password');
        $domain = (string)$this->input('post.domain');

        if (!$this->validate($this->preg['username'], 'post.username', $username))
            return $this->error(3, '用户名格式不正确');

        if (!$this->validate($this->preg['password'], 'post.password', $password))
            return $this->error(3, '密码格式不正确');

        if (false == self::isApp()) {
            if (!$this->validate($this->preg['domain'], 'post.domain', $domain))
                return $this->error(3, '域名格式不正确');
        } else {
            $domain = 'APP';
        }

        $user = $this->model('user');
        $detail = $user->_detail(['username' => $username]);

        if (empty($detail))
            return $this->error(1, '用户不存在');

        if ($detail['status'] == -1)
            return $this->error(1, '用户不存在');

        if ($detail['status'] == 2)
            return $this->error(1, '为了您的账号安全，当前账号已上锁，请联系客服解锁。');

        if ($detail['is_enable'] == 1)
            return $this->error(1, '当前账号存在异常，请联系在线客服');

        $fullPass = $this->password($password, $username);

        /**
         * 目前需求：用户输入当前账号的密码，如果在10分钟内输入3次错误，则将当前用户更改为锁定状态，用户可通过联系客服方式在管理后台解锁。
         */
        //检测用户输入当前用户的时间是否超过10分钟，如果超过10分钟则清0
        $fail_time = iSession::get($username . '_login_fail_time');
        if ($fail_time > 0 && (time() - 600) > $fail_time)
            iSession::set([$username . '_login_fail_cnt' => 0, $username . '_login_fail_time' => 0]);

        if ($fullPass !== $detail['password']) {
            $fail_cnt = (int)iSession::get($username . '_login_fail_cnt');
            if ($fail_cnt == 0) {
                //第一次错误则存入次数与时间
                iSession::set([$username . '_login_fail_cnt' => 1, $username . '_login_fail_time' => time()]);
            } else if ($fail_cnt == 1) {
                //次数累加
                iSession::set([$username . '_login_fail_cnt' => 2]);
            } else if ($fail_cnt == 2) {
                //如果错误3次则锁定账号
                $user->_update(['status' => 2], ['id' => $detail['id']]);
                iSession::set([$username . '_login_fail_cnt' => 0, $username . '_login_fail_time' => 0]);
                return $this->error(1, '为了您的账号安全，当前账号已上锁，请联系客服解锁。');
            }
            return $this->error(1, '账号名密码错误');
        }

        /**
         * 目前需求：只允许单个用户采用1个设备登录，采用其他设备登录会将原来的设备挤掉线。
         */
        //将已经登陆的用户强制退出
        iSession::logoutUser($detail['id'], 1, 1);

        //登陆成功，将用户登录会话缓存起来做登录记录。（将用户ID缓存到当前有序集合中，用来做在线用户列表。）
        $appName = self::getAppNameByDevice();
        iSession::redis("zAdd", APP_NAME . '_' . $appName . '_list', time(), $detail['id']);
        iSession::redis("set", APP_NAME . '_' . $detail['id'], iGlobal::get("access_token"));

        //记录最后登录IP&时间&登录平台域名&上次登录时间IP
        $upd['sc_login_ip'] = $detail['last_login_ip'];
        $upd['sc_login_time'] = $detail['last_login_time'];
        $upd['last_login_ip'] = $this->header("x-real-ip") ? $this->header("x-real-ip") : "";
        $upd['last_login_time'] = time();
        $upd['domain'] = $domain;
        $rs = $user->_update($upd, ['id' => $detail['id']]);
        if (false == $rs)
            return $this->error(1, '登录失败，请稍后重试。');

        //将用户登录行为插入ES
        $log['userid'] = $detail['id'];
        $log['username'] = $detail['username'];
        $log['desc'] = '用户登录';

        $fund = $this->model('user_fund')->_detail(['userid' => $detail['id']]);
        //输出指定数据
        $key = ['id', 'realname', 'username', 'istrue', 'phone', 'mast_dml', 'bank_id', 'qq', 'email', 'wechat'];
        $newData = [];
        foreach ($key as $k => $v) {
            if (isset($detail[$v]))
                $newData[$v] = $detail[$v];
        }
        //是否有取款密码
        $newData['is_out_pwd'] = 0;
        if ($detail['out_password']) $newData['is_out_pwd'] = 1;

        $newData['ablebalance'] = $fund['ablebalance'];
        $newData['score'] = $fund['score'];
        $newData['handsel'] = $fund['handsel'];
        $newData['dml'] = $fund['dml'];

        $detail['last_login_ip'] = $upd['last_login_ip'];
        $detail['last_login_time'] = $upd['last_login_time'];
        //用户活跃时间
        $detail['user_active_time'] = $upd['last_login_time'];
        $detail['domain'] = $upd['domain'];
        iSession::set($detail);

        //检测用户是否绑定银行卡
        $rs = $this->model('user_bank')->_detail(['userid'=>$detail['id']],null,'id');
        $newData['is_bind_bank'] = 0;
        if (!empty($rs))
            $newData['is_bind_bank'] = 1;

        unset($detail, $user, $key);
        return $this->success(['detail' => $newData], $log);
    }

    /**
     * @action_doc_start
     * @action_index:userReg
     * @action_name:用户注册
     * @action_description:
     * 用户注册操作
     * 参数：
     * - type     int     not null    注册类型【1|2】 1.快速注册 2.手机注册  默认为1；产品未出2这个需求，以后可能会用到。
     * - tj_code  int     null        推荐码
     * - phone    int     not null    手机号
     * - img_code int     null        图形验证码
     * - mb_code  int     null        手机验证码
     * - username string  null        用户名
     * - password string  null        密码
     * - domain   string  not null    前台域名地址
     * - wechat   string  not null    微信号
     *
     * 快速注册请求示例:
     *     {
     *          type:1,
     *          tj_code:'54gdfg3',
     *          img_code:4477,
     *          username:'test01',
     *          phone:13111111111,
     *          password:'123qwe',
     *          domain:'www.baidu.com',
     *          wechat:'abcdefg'
     *     }
     *
     * 手机注册请求示例:
     *     {
     *          type:2,
     *          tj_code:54gdfg3,
     *          mb_code:431677,
     *          phone:13111111111,
     *          domain:www.baidu.com
     *     }
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{}
     *     }
     * @action_doc_end
     */
    function actionUserReg()
    {

        $type = (int)$this->input('post.type', 1);
        $tj_code = (string)$this->input('post.tj_code');
        $phone = (int)$this->input('post.phone');
        $domain = (string)$this->input('post.domain');
        $wechat = (string)$this->input('post.wechat');

        if (!$this->validate($this->preg['mobile'], 'post.phone', $phone))
            return $this->error(3, '手机号格式不正确');

        if (false == self::isApp()) {
            if (!$this->validate($this->preg['domain'], 'post.domain', $domain))
                return $this->error(3, '域名格式不正确');
        } else {
            $domain = 'APP';
        }

        if (!$this->validate($this->preg['wechat'], 'post.wechat', $wechat))
            return $this->error(3, '微信号格式不正确');

        $reg = [];
        $user = $this->model('user');

        //快速注册
        if ($type == 1) {

            $username = (string)$this->input('post.username');
            $password = (string)$this->input('post.password');
            $img_code = (int)$this->input('post.img_code');

            if (!$this->validate($this->preg['username'], 'post.username', $username))
                return $this->error(3, '用户名格式不正确');

            if (!$this->validate($this->preg['password'], 'post.password', $password))
                return $this->error(3, '密码格式不正确');

            if (!$this->validate($this->preg['imgcode'], 'post.img_code', $img_code))
                return $this->error(3, '验证码格式不正确');

            $imgCode = iSession::get('register_authnum');
            if ($img_code != $imgCode)
                return $this->error(1, '验证码不正确');

            $uInfo = $user->_detail(['username' => $username, 'or', 'phone' => $phone, 'or', 'wechat' => $wechat]);
            if ($uInfo['username'] == $username)
                return $this->error(1, '用户名已被注册');

            if ($uInfo['phone'] == $phone)
                return $this->error(1, '手机号已被注册');

            if ($uInfo['wechat'] == $wechat)
                return $this->error(1, '微信号已存在');

            $reg = [
                'username' => $username,
                'password' => $this->password($password, $username),
                'phone' => $phone
            ];

            //手机号注册
        } elseif ($type == 2) {

            $mb_code = (string)$this->input('post.mb_code');
            $mbCode = iSession::get('register_mobile_code');
            if (!$this->validate($this->preg['smscode'], 'post.mb_code', $mb_code))
                return $this->error(3, '验证码格式不正确');

            if ($mbCode != $mb_code)
                return $this->error(1, '验证码不正确');

            $uInfo = $user->_detail(['username' => $phone]);
            if (!empty($uInfo))
                return $this->error(1, '账号已被注册');

            $reg['username'] = $phone;
            $reg['phone'] = $phone;
            $pass = iSession::get('register_password');
            if ($pass)
                $reg['password'] = $this->password($pass, $phone);
            else
                return $this->error(1, '短信验证码已失效');
        } else {
            return $this->error(3, '无效的注册类型');
        }

        //推荐码
        if ($this->validate($this->preg['tjcode'], 'post.tj_code', $tj_code)) {
            $agent = $this->model('agent');
            $info = $agent->_detail(['rmd_code' => $tj_code]);
            if (empty($info))
                return $this->error(1, '无效的推荐码');
            $reg['agent_id'] = $info['id'];
        }

        $tInfo = $this->model('UserTier')->_detail(['is_default' => 1], null, 'id');
        $reg['tierid'] = $tInfo['id'] ? $tInfo['id'] : 1;
        $reg['reg_ip'] = $this->header("x-real-ip") ? $this->header("x-real-ip") : "";
        $reg['reg_device'] = iGlobal::get('device');
        $reg['reg_source'] = $domain;
        $reg['wechat'] = $wechat;
        $reg['last_login_time'] = $reg['sc_login_time'] = time();
        $reg['last_login_ip'] = $reg['sc_login_ip'] = $reg['reg_ip'];
        $rs = $user->_insert($reg);
        if (false == $rs)
            return $this->error(1, '注册失败，请稍后重试。');

        //将注册用户行为插入ES
        $log['userid'] = $rs;
        $log['username'] = $reg['username'];
        $log['desc'] = '用户注册';
        unset($reg, $info, $user, $pInfo, $uInfo);
        return $this->success([], $log);
    }

    /**
     * @action_doc_start
     * @action_index:FindPassword
     * @action_name:用户找回密码
     * @action_description:
     * 用户找回密码操作
     * 参数：
     * - step     int     not null    步骤：1.验证用户名和验证码；2.输入手机号|邮箱，并发送验证码；3.校验手机|邮箱验证码；4.完成修改密码
     * - username string  null        用户名
     * - img_code int     null        图形验证码
     * - phone    int     not null    手机号
     * - email    int     not null    邮箱
     * - mb_code  int     null        手机验证码
     * - em_code  int     null        邮箱验证码
     * - password1 string  null       1次密码
     * - password2 string  null       2次密码
     *
     * 步骤1请求示例:
     *     {
     *          username:'morris',
     *          img_code:4575,
     *          step:1
     *     }
     *
     * 步骤2请求示例:
     *     {
     *          username:'morris',
     *          img_code:4575,
     *          email:'morris@irainbow7.com',
     *          //phone:13111111111,
     *          step:2
     *     }
     *
     * 步骤3请求示例:
     *     {
     *          username:'morris',
     *          img_code:4575,
     *          email:'morris@irainbow7.com',
     *          em_code:431677,
     *          //phone:13111111111,
     *          //mb_code:431677,
     *          step:3
     *     }
     *
     *  步骤4请求示例:
     *     {
     *          username:'morris',
     *          img_code:4575,
     *          email:'morris@irainbow7.com',
     *          em_code:431677,
     *          //phone:13111111111,
     *          //mb_code:431677,
     *          password1:'123qwes',
     *          password2:'123qwes',
     *          step:4
     *     }
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{}
     *     }
     * @action_doc_end
     */
    function actionFindPassword()
    {

        $step = (int)$this->input('post.step');
        $username = (string)$this->input('post.username');
        $img_code = (int)$this->input('post.img_code');
        $mb_code = (int)$this->input('post.mb_code');
        $em_code = (int)$this->input('post.em_code');
        $phone = (int)$this->input('post.phone');
        $email = (string)$this->input('post.email');
        $password1 = (string)$this->input('post.password1');
        $password2 = (string)$this->input('post.password2');

        if ($step <= 0 || $step > 4)
            return $this->error(3, '无效的操作');

        if (!$this->validate($this->preg['username'], 'post.username', $username))
            return $this->error(3, '用户名格式不正确');

        //验证码校验
        if (!$this->validate($this->preg['imgcode'], 'post.img_code', $img_code))
            return $this->error(3, '图片验证码不正确');

        $imgCode = iSession::get('find_password_authnum');
        if ($img_code != $imgCode)
            return $this->error(1, '图片验证码错误');

        $user = $this->model('user');
        $userInfo = $user->_detail(['username' => $username]);
        if (empty($userInfo))
            return $this->error(1, '用户不存在');

        if ($userInfo['status'] == -1)
            return $this->error(1, '用户不存在');

        if ($userInfo['status'] == 2)
            return $this->error(1, '当前账号已上锁，请联系客服解锁。');

        //第一步验证成功将手机号和邮箱返回
        if ($step == 1)
            return $this->success(['detail' => ['phone' => $userInfo['phone'], 'email' => $userInfo['email']]]);

        if ($this->validate($this->preg['notempty'], 'post.phone', $phone)) {

            if (!$this->validate($this->preg['mobile'], 'post.phone', $phone))
                return $this->error(3, '手机号格式不正确');

            if ($phone != $userInfo['phone'])
                return $this->error(1, '手机号不一致');

            //发送手机验证码
            if ($step == 2) {

                //检测发送验证码是否超时 间隔60s才能发送
                $time = iSession::get('find_password_mobile_time');
                if ($time > 0 && (time() - $time) < 60) {
                    return $this->error(1, '请勿重复发送验证码');
                } else {
                    iSession::set(['find_password_mobile_time' => 0]);
                }

                //运营商待定
                $ret = iSms::send('find_password', $phone);
                $ret = ['status' => true, 'sms_code' => rand(100000, 999999)];
                if (false == $ret['status'])
                    return $this->error($ret['msg']);

                iSession::set(array("find_password_mobile_code" => $ret['sms_code'], 'find_password_mobile_time' => time()));

                return $this->success($ret);
            }

            if (!$this->validate($this->preg['smscode'], 'post.mb_code', $mb_code))
                return $this->error(3, '手机验证码格式不正确');

            $mbCode = iSession::get('find_password_mobile_code');
            if ($mb_code != $mbCode)
                return $this->error(1, '手机验证码错误');
        }

        if ($this->validate($this->preg['notempty'], 'post.email', $email)) {

            if (!$userInfo['email'])
                return $this->error(3, '账户未绑定邮箱');

            if (!$this->validate($this->preg['email'], 'post.email', $email))
                return $this->error(3, '邮箱格式不正确');

            if ($email != $userInfo['email'])
                return $this->error(1, '邮箱不一致');

            //发送邮箱验证码
            if ($step == 2) {

                $sms_code = rand(100000, 999999);
                $smtp = new iSmtp();
                $smtp->send($email, '太阳娱乐城找回密码', '亲爱的用户，欢迎您使用太阳娱乐城账号，您的邮箱验证码：' . $sms_code . '，请使用该验证码完成找回密码操作，感谢您的支持！');
                iSession::set(array("find_password_email_code" => $sms_code));
                return $this->success();
            }

            if (!$this->validate($this->preg['smscode'], 'post.em_code', $em_code))
                return $this->error(3, '邮箱验证码格式不正确');

            $emCode = iSession::get('find_password_email_code');
            if ($em_code != $emCode)
                return $this->error(1, '邮箱验证码错误');
        }

        if (!trim($phone) && !trim($email))
            return $this->error(1, '请输入正确的手机号或者邮箱');

        //以上校验手机|邮箱验证码，成功并返回。
        if ($step == 3)
            return $this->success();

        if (!$this->validate($this->preg['password'], 'post.password1', $password1))
            return $this->error(3, '密码格式不正确');

        if ($password1 != $password2)
            return $this->error(1, '两次密码不一致');

        $password = $this->password($password1, $username);

        //验证输入的密码是否与原来的密码一致
        if ($userInfo['password'] == $password)
            return $this->error(1, '与原密码一致，请输入新的密码。');

        $rs = $user->_update(['password' => $password], ['id' => $userInfo['id']]);
        if (false == $rs)
            return $this->error(1, '找回密码失败，请稍后重试。');

        //如果用户登录，则将登陆的用户强制退出。
        $loginToken = iSession::redis('get', 'frontend_' . $userInfo['id']);
        if ($loginToken)
            iSession::redis("delete", "accesstoken_" . $loginToken);

        //将用户找回密码行为插入ES
        $log['userid'] = $userInfo['id'];
        $log['username'] = $userInfo['username'];
        $log['desc'] = '用户找回密码';
        return $this->success([], $log);
    }


    /**
     * @action_doc_start
     * @action_index:updPassword
     * @action_name:用户修改密码
     * @action_description:
     * 用户修改密码操作
     * 参数：
     * - password  string  not null   当前密码
     * - password1 string  not null   1次密码
     * - password2 string  not null   2次密码
     *
     *  请求示例:
     *     {
     *          password:'123qwe',
     *          password1:'123qwes',
     *          password2:'123qwes'
     *     }
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{}
     *     }
     * @action_doc_end
     */
    public function actionUpdPassword()
    {

        $password = (string)$this->input('post.password');
        $password1 = (string)$this->input('post.password1');
        $password2 = (string)$this->input('post.password2');

        if (!$this->validate($this->preg['password'], 'post.password', $password))
            return $this->error(3, '当前密码格式不正确');

        if (!$this->validate($this->preg['password'], 'post.password1', $password1))
            return $this->error(3, '新密码格式不正确');

        if (!$this->validate($this->preg['password'], 'post.password2', $password2))
            return $this->error(3, '新密码格式不正确');

        if ($password1 != $password2)
            return $this->error(3, '两次密码不一致');

        if ($password == $password1)
            return $this->error(3, '新密码与旧密码一致');

        $ori_password = iSession::get('password');

        if (!$ori_password)
            return $this->error(1, '请重新登录');

        $username = iSession::get('username');
        $id = iSession::get('id');

        $password = $this->password($password, $username);
        if ($password != $ori_password)
            return $this->error(1, '当前密码与原密码不一致');

        $user = $this->model('user');

        $password1 = $this->password($password1, $username);
        $rs = $user->_update(['password' => $password1], ['id' => $id]);
        if (false == $rs)
            return $this->error(1, '修改密码失败，请稍后重试。');

        //如果用户登录，则将登陆的用户强制退出。
//        $loginToken = iSession::redis('get', 'frontend_' . $id);
//        if ($loginToken)
//            iSession::redis("delete", "accesstoken_" . $loginToken);

        //将用户修改密码行为插入ES
        $log['userid'] = $id;
        $log['username'] = $username;
        $log['desc'] = '用户修改密码';
        return $this->success([], $log);

    }


    /**
     * @action_doc_start
     * @action_index:updFundPwd
     * @action_name:用户修改资金密码
     * @action_description:
     * 用户修改资金密码操作
     * 参数：
     * - fundpwd  string  null       当前资金密码
     * - fundpwd1 string  not null   1次密码
     * - fundpwd2 string  not null   2次密码
     *
     *  请求示例:
     *     {
     *          fundpwd:'123qwe',
     *          fundpwd1:'123qw',
     *          fundpwd2:'123qw'
     *     }
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{}
     *     }
     * @action_doc_end
     */
    public function actionUpdFundPwd()
    {

        $fundpwd = (string)$this->input('post.fundpwd');
        $fundpwd1 = (string)$this->input('post.fundpwd1');
        $fundpwd2 = (string)$this->input('post.fundpwd2');

        $username = iSession::get('username');
        $id = iSession::get('id');

        if (!$this->validate($this->preg['fundpwd'], 'post.fundpwd1', $fundpwd1))
            return $this->error(3, '新资金密码格式不正确');

        if (!$this->validate($this->preg['fundpwd'], 'post.fundpwd2', $fundpwd2))
            return $this->error(3, '新资金密码格式不正确');

        if ($fundpwd1 != $fundpwd2)
            return $this->error(3, '两次密码不一致');

        $ori_fundpwd = iSession::get('out_password');
        if (!$ori_fundpwd)
            return $this->error(1, '未设置资金密码，请先设置。');

        if ($fundpwd == $fundpwd1)
            return $this->error(3, '新密码与旧密码一致');

        $fundpwd = $this->password($fundpwd, $username);
        if ($fundpwd != $ori_fundpwd)
            return $this->error(1, '当前资金密码与原密码不一致');


        $user = $this->model('user');

        $fundpwd1 = $this->password($fundpwd1, $username);
        $rs = $user->_update(['out_password' => $fundpwd1], ['id' => $id]);
        if (false == $rs)
            return $this->error(1, '操作失败，请稍后重试。');

        iSession::set(['is_out_pwd' => 1, 'out_password' => $fundpwd1]);

        //将用户修改密码行为插入ES
        $log['userid'] = $id;
        $log['username'] = $username;
        $log['desc'] = '用户修改资金密码';
        return $this->success([], $log);

    }

    /**
     * @action_doc_start
     * @action_index:bindEmail
     * @action_name:用户绑定邮箱
     * @action_description:
     * 用户绑定邮箱码操作
     * 参数：
     * - email   string  not null   绑定邮箱
     * - em_code int     not null   邮箱验证码
     *
     *  请求示例:
     *     {
     *          email:'morris@irainbow7.com',
     *          em_code: 888888
     *     }
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{}
     *     }
     * @action_doc_end
     */
    function actionBindEmail()
    {

        $email = (string)$this->input('post.email');
        $em_code = (int)$this->input('post.em_code');

        if (!$this->validate($this->preg['email'], 'post.email', $email))
            return $this->error(3, '邮箱格式不正确');

        if (!$this->validate($this->preg['smscode'], 'post.em_code', $em_code))
            return $this->error(3, '邮箱验证码格式不正确');

        $username = iSession::get('username');
        $id = iSession::get('id');
        $ori_email = iSession::get('email');
        if ($ori_email) return $this->error(1, '您已绑定邮箱，请勿重复绑定。');

        $info = $this->model('user')->_detail(['email' => $email], null ,'id');
        if (!empty($info)) return $this->error(1, '电子邮箱已存在');

        $emCode = iSession::get('bind_email_code');
        if ($em_code != $emCode)
            return $this->error(1, '邮箱验证码错误');

        $user = $this->model('user');
        $rs = $user->_update(['email' => $email], ['id' => $id]);
        if (false == $rs)
            return $this->error(1, '绑定失败，请稍后重试。');

        iSession::set(['email' => $email]);

        //将用户修改密码行为插入ES
        $log['userid'] = $id;
        $log['username'] = $username;
        $log['desc'] = '用户绑定邮箱';
        return $this->success([], $log);
    }

    /**
     * @action_doc_start
     * @action_index:UserLoginOut
     * @action_name:用户退出登录
     * @action_description:
     * 用户退出登录操作
     * 必带参数；
     *
     * 返回数据：
     *     {
     *           code:0,
     *           msg:"",
     *           data:{}
     *     }
     * @action_doc_end
     */
    function actionUserLoginOut()
    {
        //将用户退出行为插入ES
        $log['userid'] = iSession::get('id');
        $log['username'] = iSession::get('username');
        $log['desc'] = '用户退出登录';

        iSession::logoutUser($log['userid'], 0, 1);

        return $this->success([], $log);
    }

}
