<?php

/**
 * 总控制器
 */
class _FrontendController extends iController {

    function __construct($init = true) {
        parent::__construct();
    }

    /**
     * 检测用户登录
     * @return boolean
     */
    function checkAccess() {
        if (in_array($this->action, $this->noNeedCheckAction)) {
            return true;
        }

        $id = iSession::get('id');
        if (!$id)
            return false;

        return true;
    }

    /**
     * 记录前台行为日志
     * @param array $log 日志信息：array("username"=>"liming","desc"=>"用户登录","userid"=>"123")
     */
    protected function logAction($log) {
        $log['action'] = $this->route;
        $log['post'] = $this->POST;
        $log['ip'] = $this->header("x-real-ip")? : "";
        $log['time'] = time();
        $log['device'] = iGlobal::get('device');

        iServer::taskfn(function() use($log) {
            $esb = (new UserActionLog())->getBuild();
            if ($esb) {
                $esb->insFrontendLogs($log);
            } else {
                iLog::write("创建esb失败", "es");
            }
        });
        unset($log);
    }

    /**
     * 成功返回数据结果
     * @param array $data
     * @param array $log
     * @return array
     */
    protected function success($data = array(), $log = []) {
        if (!empty($log))
            $this->logAction($log);
        return $this->display(0, $data);
    }

}
