<?php

/**
 * @module_doc_start
 * @module_name:前台个人中心接口服务
 * @module_type:common
 * @module_descrition:
 * @module_doc_end
 */
class PersonalController extends _FrontendController
{

    public $needCheckAccess = false;

    /**
     * @action_doc_start
     * @action_index:getUnreadCnt
     * @action_name:获取站内信未读信息数量
     * @action_description:
     * 获取站内信未读信息数量
     * 无参数：
     *
     * 请求示例:
     *     {}
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           detail:
     *              {
     *                   cnt: "9", //未读数量
     *              }
     *       }
     *   }
     * @action_doc_end
     */
    public function actionGetUnreadCnt()
    {
        $uid = iSession::get('id');
        $tierid = iSession::get('tierid');

        $receive = $this->model('letter_receive');
        $readMod = $this->model('letter_receive_read');

        $allLet = $allUsrLet = $allTieLet = [];

        //1.先根据注册时间来筛选发给全员的信件
        $ctime = iSession::get('create_at');
        $where = ['type' => 1, 'status' => 1, 'create_at' => [">", $ctime]];
        $allLet = $receive->_lists($where, null, null, 3, 'letterid');

        //2.然后根据指定会员在筛选信件
        $where = ['type' => 2, 'status' => 1, 'to_user' => $uid];
        $allUsrLet = $receive->_lists($where, null, null, 3, 'letterid');

        //3.在根据会员分层筛选信件
        if ($tierid) {
            $where = ['type' => 3, 'status' => 1, 'to_user' => $tierid, 'create_at' => [">", $ctime]];
            $allTieLet = $receive->_lists($where, null, null, 3, 'letterid');
        }

        $rList = $readMod->_lists(['user_id' => $uid], null, null, 3, 'letterid,status');

        $letIds = [];
        foreach ($allLet as $k => $v) {
            $letIds[] = $v['letterid'];
        }
        foreach ($allUsrLet as $k => $v) {
            $letIds[] = $v['letterid'];
        }
        foreach ($allTieLet as $k => $v) {
            $letIds[] = $v['letterid'];
        }

        $rLetIds = [];
        $rmLetIds = [];
        foreach ($rList as $k => $v) {
            if ($v['status'] == -1) {
                $rmLetIds[] = $v['letterid'];
            } else {
                $rLetIds[] = $v['letterid'];
            }
        }

        $letIds = array_diff($letIds, $rmLetIds);
        $cnt = array_diff($letIds, $rLetIds);

        unset($rLetIds, $rList, $letIds, $allLet, $allUsrLet, $allTieLet);

        return $this->success(['detail' => ['cnt' => count($cnt)]]);
    }

    /**
     * @action_doc_start
     * @action_index:getLetter
     * @action_name:获取站内信列表
     * @action_description:
     * 获取站内信列表
     * 参数：
     * - page     int  null  当前页 默认1
     * - pagesize int  null  总页数 默认10
     *
     * 请求示例:
     *     {
     *          page:1,
     *          pagesize:10
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                   id: "9", //站内信ID
     *                   title: //站内信标题
     *                   content: //站内信内容
     *                   type: //1.系统消息（保留字段，后续可能会增加消息类型。）
     *                   create_at: //站内信发送时间
     *                   is_read: //阅读状态 0未读 1已读
     *                   read_time: //阅读时间
     *              }
     *          ],
     *          total_num:10,//总结记录数
     *          total_page:12,//总计分页数
     *       }
     *   }
     * @action_doc_end
     */
    function actionGetLetter()
    {

        $page = (int)$this->input('post.page', 1);
        $pagesize = (int)$this->input('post.pagesize', 10);

        $receive = $this->model('letter_receive');

        $uid = iSession::get('id');
        $tierid = iSession::get('tierid');

        $allLet = $allUsrLet = $allTieLet = [];

        //1.先根据注册时间来筛选发给全员的信件
        $ctime = iSession::get('create_at');
        $where = ['type' => 1, 'create_at' => [">", $ctime]];
        $allLet = $receive->_lists($where, 'id desc', null, 3, 'letterid');

        //2.然后根据指定会员在筛选信件
        $where = ['type' => 2, 'to_user' => $uid];
        $allUsrLet = $receive->_lists($where, 'id desc', null, 3, 'letterid');

        //3.在根据会员分层筛选信件
        if ($tierid) {
            $where = ['type' => 3, 'to_user' => $tierid, 'create_at' => [">", $ctime]];
            $allTieLet = $receive->_lists($where, 'id desc', null, 3, 'letterid');
        }

        //合并所有信件id
        $letIds = [];
        foreach ($allLet as $k => $v) {
            $letIds[] = $v['letterid'];
        }
        foreach ($allUsrLet as $k => $v) {
            $letIds[] = $v['letterid'];
        }
        foreach ($allTieLet as $k => $v) {
            $letIds[] = $v['letterid'];
        }

        $letMod = $this->model('letter_send');
        $redMod = $this->model('letter_receive_read');
        //获取当前用户已读信件
        $where = ['letterid' => ['in', $letIds], 'user_id' => $uid];
        $redList = $redMod->_lists($where, null, null, 3, 'letterid,status,create_at');
        $newRed = [];
        $rmLetIds = [];
        foreach ($redList as $k => $v) {
            if ($v['status'] == -1) {
                $rmLetIds[] = $v['letterid'];
            } else {
                $newRed[$v['letterid']] = $v;
            }
        }
        //过滤删除信件
        $letIds = array_diff($letIds, $rmLetIds);

        //将信件ID倒序
        arsort($letIds);

        //分页处理
        $total_num = count($letIds);
        if ($total_num > 100) {
            $letIds = array_slice($letIds, 0, 100);
            $total_num = 100;
        }

        if (count($letIds) > $pagesize)
            $letIds = array_slice($letIds, (($page - 1) * $pagesize), $pagesize);

        //通过信件id获取列表
        $where = ['id' => ['in', $letIds]];
        $list = $letMod->_lists($where, 'id desc', 100, 3, 'id,title,content,type,create_at');

        foreach ($list as $k => $v) {
            $list[$k]['is_read'] = 0;
            $list[$k]['read_time'] = 0;
            if (isset($newRed[$v['id']])) {
                $list[$k]['is_read'] = 1;
                $list[$k]['read_time'] = $newRed[$v['id']]['create_at'];
            }
        }

        //根据字段create_at对数组$data进行降序排列
        $last_names = array_column($list, 'create_at');
        array_multisort($last_names, SORT_DESC, $list);

        $ret["total_num"] = $total_num;
        $ret["total_page"] = ceil($total_num / $pagesize);
        $ret['lists'] = $list;
        unset($rmLetIds, $redList, $where, $letIds, $allLet, $allUsrLet, $allTieLet, $newRed, $list);
        return $this->success($ret);

    }


    /**
     * @action_doc_start
     * @action_index:readLetter
     * @action_name:阅读站内信息
     * @action_description:
     * 阅读站内信息
     * 参数：
     * - id   int  not null  站内信ID
     *
     * 请求示例:
     *     {
     *          id:1
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{}
     *   }
     * @action_doc_end
     */
    public function actionReadLetter()
    {

        $id = (int)$this->input('post.id');
        if (!$id)
            return $this->error(3, '参数无效');

        $letMod = $this->model('letter_send');
        $redMod = $this->model('letter_receive_read');

        $detail = $letMod->_detail(['id' => $id]);
        if (empty($detail))
            return $this->error(1, '没有找到信件');

        $uid = iSession::get('id');
        $rInfo = $redMod->_detail(['letterid' => $id, 'user_id' => $uid]);
        if (!empty($rInfo))
            return $this->error(1, '您已阅读过了');

        $rs = $redMod->_insert(['letterid' => $id, 'user_id' => $uid, 'create_at' => time()]);
        if (false == $rs)
            return $this->error(1, '阅读信件失败！');

        return $this->success();

    }

    /**
     * @action_doc_start
     * @action_index:delLetter
     * @action_name:删除站内信息
     * @action_description:
     * 删除站内信息
     * 参数：
     * - id   int  not null  站内信ID
     *
     * 请求示例:
     *     {
     *          id:1
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{}
     *   }
     * @action_doc_end
     */
    public function actionDelLetter()
    {
        $id = (int)$this->input('post.id');
        if (!$id)
            return $this->error(3, '参数无效');

        $letMod = $this->model('letter_send');
        $redMod = $this->model('letter_receive_read');

        $detail = $letMod->_detail(['id' => $id]);
        if (empty($detail))
            return $this->error(1, '没有找到信件');

        $uid = iSession::get('id');
        $rInfo = $redMod->_detail(['letterid' => $id, 'user_id' => $uid]);
        if (!empty($rInfo)) {
            $rs = $redMod->_update(['status' => -1, 'update' => time()], ['letterid' => $id, 'user_id' => $uid]);
        } else {
            $rs = $redMod->_insert(['status' => -1, 'letterid' => $id, 'user_id' => $uid, 'create_at' => time()]);
        }
        if (false == $rs)
            return $this->error(1, '删除失败，请稍后重试。');

        return $this->success();
    }


    /**
     * @action_doc_start
     * @action_index:getBankInfo
     * @action_name:获取银行卡信息
     * @action_description:
     * 获取银行卡信息
     * 无参数
     *
     * 请求示例:
     *   {}
     *
     * 返回值：
     *   code:0,
     *       msg:'',
     *       data:{
     *          lists:[//绑定银行卡信息（目前需求：一个用户只允许绑定一张银行卡）
     *              {
     *                  bank_name: //银行卡名称
     *                  bankNo: //银行卡号
     *                  type: //银行卡类型：1储蓄卡 2信用卡
     *                  icon: //银行卡logo地址
     *              }
     *          ]
     *       }
     * @action_doc_end
     */
    public function actionGetBankInfo()
    {

        $uid = iSession::get('id');
        $uMod = $this->model('user_bank');

        //获取绑定银行卡信息
        $info = $uMod->_detail(['userid' => $uid], null, 'cardno,bank_name,type,bank');

        if (!empty($info)) {
            $info['icon'] = '/oss/bank_icon/' . strtoupper($info['bank']) . '.png';
            $checkBank = new CheckBank();
            $info['cardno'] = $checkBank->formatBankCardNo($info['cardno']);
            unset($info['bank']);
        }

        $ret['lists'] = [];
        if (!empty($info))
            $ret['lists'][] = $info;

        unset($info);
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:bindBank
     * @action_name:绑定银行卡
     * @action_description:
     * 绑定银行卡
     * 参数：
     * - name       string  not null  持卡人姓名
     * - bankNo     string  not null  银行卡号
     * - position   string  not null  地理位置
     * - branch     string  not null  开户银行
     * - fundpwd    string  not null  资金密码
     *
     * 请求示例:
     *     {
     *          name:'张三',
     *          bankNo:'6221506020009066385',
     *          position:'北京市/市辖区/朝阳区',
     *          branch:'北京山顶洞支行',
     *          fundpwd:'abc123',
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{}
     *   }
     * @action_doc_end
     */
    public function actionBindBank()
    {
        $name = (string)$this->input('post.name');
        $bankNo = (string)$this->input('post.bankNo');
        $position = (string)$this->input('post.position');
        $branch = (string)$this->input('post.branch');
        $fundpwd = (string)$this->input('post.fundpwd');

        $uid = iSession::get('id');
        $uMod = $this->model('user_bank');

        //验证是否绑定了银行卡
        $info = $uMod->_detail(['userid' => $uid], null, 'id');
        if (!empty($info))
            return $this->error(1, '您已绑银行卡，请勿重复绑定。');

        if (!$this->validate($this->preg['realname'], 'post.name', $name))
            return $this->error(3, '持卡人姓名格式不正确');

        $checkBank = new CheckBank();
        $validateBank = $checkBank->validateBankNo($bankNo);
        if (false == $validateBank)
            return $this->error(3, '银行卡格式不正确');

        if (!empty($validateBank) && false == $validateBank['validated'])
            return $this->error(3, '银行卡号错误');

        $position = array_filter(explode('/', $position));
        if (empty($position)) return $this->error(3, '银行所属地格式不正确');
        if (!empty($position) && count($position) != 3) $this->error(3, '银行所属地格式不正确');

        if (!$this->validate($this->preg['bank_branch'], 'post.branch', $branch))
            return $this->error(3, '开户支行名称格式不正确');

        $aInfo = $uMod->_detail(['cardno' => $bankNo], null, 'id');
        if (!empty($aInfo))
            return $this->error(3, '该银行卡号已被绑定，请重新输入。');

        if (!$this->validate($this->preg['fundpwd'], 'post.fundpwd', $fundpwd))
            return $this->error(3, '资金密码格式不正确');

        $insArr = [
            'userid' => $uid,
            'bank_name' => $validateBank['bankName'],
            'bank' => $validateBank['bank'],
            'cardno' => $bankNo,
            'province' => $position[0],
            'city' => $position[1],
            'county' => $position[2],
            'branch' => $branch,
            'type' => $validateBank['cardType'] == 'DC' ? 1 : 2
        ];

        iModel::_begin();
        $rs = $uMod->_insert($insArr);
        if (false == $rs) {
            iModel::_back();
            return $this->error(1, '绑定银行卡失败，请稍后重试。');
        }

        $userMod = $this->model('user');
        $username = iSession::get('username');
        $fundpwd = $this->password($fundpwd, $username);
        $rs = $userMod->_update(['realname' => $name, 'out_password' => $fundpwd], ['id' => $uid]);
        if (false == $rs) {
            //操作失败，回滚事务
            iModel::_back();
            return $this->error(1, "操作失败，请稍后重试。");
        } else {
            $rs = iModel::_end();
            if (false == $rs)
                return $this->error(1, "操作异常，请稍后重试。");
        }
        iSession::set(['realname' => $name, 'out_password' => $fundpwd]);

        return $this->success();

    }

    /**
     * @action_doc_start
     * @action_index:getCollectList
     * @action_name:获取用户收藏列表
     * @action_description:
     * 获取用户收藏列表
     * 参数：
     * - page     int  null  当前页 默认1
     * - pagesize int  null  总页数 默认10
     *
     * 请求示例:
     *     {
     *          page:1,
     *          pagesize:10
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                   id: "9", //收藏ID
     *                   title: //游戏名称
     *                   game_id: //游戏ID
     *                   code: //游戏code
     *                   create_at: //收藏时间
     *                   is_wh: //游戏是否维护 1.维护 0正常
     *                   tags: //游戏标签
     *              }
     *          ],
     *          total_num:10,//总结记录数
     *          total_page:12,//总计分页数
     *       }
     *   }
     * @action_doc_end
     */
    public function actionGetCollectList()
    {

        $mod = $this->model('user_collect');

        $list = $mod->_lists(['status' => 1, 'userid' => $this->member['id']], 'update_at desc', 20, null, 'id,game_id,create_at');

        if (!empty($list)) {
            $gameid = array_column($list, 'game_id');
            $gList = $this->model('game')->_lists(['id' => ['in', $gameid], 'status' => 1], null, null, 1, 'title,tags,id,pid,is_wh,code');
            $nGlist = [];
            foreach ($gList as $k => $v) {
                $nGlist[$v['id']] = $v;
            }

            foreach ($list as $k => $v) {
                $list[$k]['title'] = $nGlist[$v['game_id']]['title'];
                $list[$k]['tags'] = $nGlist[$v['game_id']]['tags'];
                $list[$k]['is_wh'] = $nGlist[$v['game_id']]['is_wh'];
                $list[$k]['code'] = $nGlist[$v['game_id']]['code'];
            }
        }

        unset($nGlist, $gList);
        return $this->success(['lists' => $list]);
    }

    /**
     * @action_doc_start
     * @action_index:addCollect
     * @action_name:用户收藏游戏
     * @action_description:
     * 用户收藏游戏
     * 参数：
     * - game_id     int  not null  游戏ID
     *
     * 请求示例:
     *     {
     *          game_id:500
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{}
     *   }
     * @action_doc_end
     */
    public function actionAddCollect()
    {

        $game_id = (int)$this->input('post.game_id', 0);
        if (!$game_id) return $this->error(3, '参数错误');

        $info = $this->model('game')->_detail(['id' => $game_id, 'status' => 1]);
        if (empty($info)) return $this->error(1, '未找到该游戏');

        $info = $this->model('user_collect')->_detail(['game_id' => $game_id, 'userid' => $this->member['id']]);
        if (!empty($info) && $info['status'] == 1) return $this->error(1, '您已经收藏过了，切勿重复收藏。');

        $count = $this->model('user_collect')->_count(['userid' => $this->member['id'], 'status' => 1]);
        if ($count >= 20) return $this->error(1, '抱歉，最多可收藏20个。');

        if (empty($info)) {
            $ins = [
                'game_id' => $game_id,
                'userid' => $this->member['id']
            ];
            $rs = $this->model('user_collect')->_insert($ins);
        } else {
            $ins = [
                'status' => 1,
                'create_at' => time(),
                'update_at' => time(),
            ];
            $rs = $this->model('user_collect')->_update($ins, ['id' => $info['id']]);
        }

        if (false == $rs) $this->error(1, '收藏失败，请稍后重试。');

        return $this->success();
    }

    /**
     * @action_doc_start
     * @action_index:cancelCollect
     * @action_name:用户取消收藏游戏
     * @action_description:
     * 用户收藏游戏
     * 参数：
     * - game_id     int  not null  游戏ID
     *
     * 请求示例:
     *     {
     *          game_id:500
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{}
     *   }
     * @action_doc_end
     */
    public function actionCancelCollect()
    {
        $game_id = (int)$this->input('post.game_id', 0);
        if (!$game_id) return $this->error(3, '参数错误');

        $info = $this->model('game')->_detail(['id' => $game_id, 'status' => 1]);
        if (empty($info)) return $this->error(1, '未找到该游戏');


        $info = $this->model('user_collect')->_detail(['game_id' => $game_id, 'userid' => $this->member['id']]);
        if (empty($info)) return $this->error(1, '您还未收藏游戏');

        if ($info['userid'] != $this->member['id']) return $this->error(1, '无效的参数');

        if (!empty($info) && $info['status'] == -1) return $this->error(1, '您还未收藏游戏');

        $rs = $this->model('user_collect')->_update(['status' => -1], ['id' => $info['id']]);
        if (false == $rs) $this->error(1, '取消收藏收藏，请稍后重试。');

        return $this->success();
    }

}
