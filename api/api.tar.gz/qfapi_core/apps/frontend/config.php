<?php

/**
 * 允许ip
 */
define("SERVER_HOST", "0.0.0.0");

/**
 * 数据库配置
 */
define("DB_HOST", "qfmysqlmaster.c23fxhyyvfzs.ap-northeast-1.rds.amazonaws.com");
define("DB_PORT", 3306);
define("DB_USER", "watson");
define("DB_PASSWORD", "qfdb1231qaz");
define("DB_NAME", "rainbow");

/**
 * session连接配置
 */
define("SESSION_HOST", "172.31.1.148");
define("SESSION_PORT", "6379");
define("SESSION_PASSWORD", "");

/**
 * cache连接配置
 */
define("CACHE_HOST", "172.31.10.126");
define("CACHE_PORT", "6379");
define("CACHE_PASSWORD", "");

/**
 * ElasticSearch game
 */
define("ES_GAME_HOST", "https://vpc-qf-pre-es-cahce-20190414-y6pqlcg7yb7dwf2tv5el6dovhe.ap-northeast-1.es.amazonaws.com");
define("ES_GAME_PORT", "443");

/**
 * ElasticSearch log
 */
define("ES_LOG_HOST", "https://vpc-qf-pre-es-session-20190414-3q4ypvdij3565n2cq6kx3t66cm.ap-northeast-1.es.amazonaws.com");
define("ES_LOG_PORT", "443");

/**
 * 跨域
 */
define("COOKIE_DOMAIN", "");
define("ALLOW_ORIGINS", "*"); //*或者多个域名，以逗号分隔，域名包含主机名，如www.aaa.com,expert.aaa.com

/**
 * 上传
 */
define("UPLOAD_PATH", '/home/projects/oss');

/**
 * 登录过期
 */
define("LOGIN_EXPIRE", 3600);

/**
 * 定时任务
 */
$cronTab = [
    [
        "time" => 500,
        "task" => [
            "path_info" => "crontab/transfer",
            "data" => []
        ]
    ],
];
