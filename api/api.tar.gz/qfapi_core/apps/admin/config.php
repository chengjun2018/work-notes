<?php

/**
 * 用户分组模式
 */
define("USER_GROUP_MODEL_NAME", "AdminGroup");

/**
 * 定时任务
 */
$IG_CRONTAB = array(
    array(
        "time" => 60000,
        "task" => array(
            "path_info" => "base/adminDongjie",
            "data" => array()
        )
    )
);
