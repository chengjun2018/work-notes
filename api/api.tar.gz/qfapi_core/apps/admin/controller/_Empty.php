<?php

class _Empty extends iController {

    function actionIndex() {
        return "404";
    }

}
