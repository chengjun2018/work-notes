<?php

/**
 * 后台基础控制器
 */
class _AdminController extends iController {

    /**
     * 权限校验
     * @return boolean
     */
    function checkAccess() {
        if ($this->needCheckAccess === false) {
            return true;
        }

        $all_group_routes = iGlobal::get("ALL_GROUP_ROUTES", null, 10, true); //权限10秒内生效
        if (!is_array($all_group_routes)) {
            $this->reflushAppGroupRoutes();
            $all_group_routes = iGlobal::get("ALL_GROUP_ROUTES", null);
            if (!is_array($all_group_routes)) {
                return false;
            }
        }

        //访问行为如果为免鉴权行为，则直接返回true
        if (in_array($this->action, $this->noNeedCheckAction)) {
            return true;
        }

        $group_ids = iSession::get("group_ids", "0");
        $this_access_route = iGlobal::get("ACCESS_ROUTE"); //iGlobal::set("ACCESS_ROUTE", APP_NAME . "/" . $this->controller . "/" . $this->action . ($this->action_params!==""?"/".$this->action_params:""));
        $group_arr = explode(",", trim($group_ids, ","));
        $access_router_no_appname = trim(ltrim($this_access_route, APP_NAME), "/");

        foreach ($group_arr as $group) {
            $this_group_routes = isset($all_group_routes[$group]) ? $all_group_routes[$group] : array();
            iLog::write([$access_router_no_appname, $this_group_routes, in_array($access_router_no_appname, $this_group_routes)], "access");
            if (in_array($access_router_no_appname, $this_group_routes)) {
                return true;
            }
        }

        $is_admin = (bool) iSession::get("is_admin", 0);
        if ($is_admin) {
            return true;
        }

        return false;
    }

    /**
     * 刷新权限分组
     * 用户角色对应用户权限应用行为路径集合$all_group_routes=array("teacher"=>array("teacherRest/student/lists","teacherRest/student/detail"))
     */
    function reflushAppGroupRoutes() {
        $all_group_routes = array();
        $user_group_model_name = defined("USER_GROUP_MODEL_NAME") ? USER_GROUP_MODEL_NAME : "UserGroup";
        $db_group_routes = (new iModel($user_group_model_name))->_lists(array("status" => 1), null, 500);
        if ($db_group_routes) {
            foreach ($db_group_routes as $routes) {
                $action_arr = explode(",", trim($routes["actions"], ","));
                $all_group_routes[$routes["id"]] = $action_arr;
            }
            iGlobal::set("ALL_GROUP_ROUTES", $all_group_routes);
        }
    }

    /**
     * 记录行为日志
     * @param type $log 日志信息：array("to_username"=>"liming","desc"=>"管理员xxx，添加了用户bbb")
     */
    protected function logAction($log) {
        $log['action'] = $this->route;
        $log['params'] = $this->POST;
        $log['ip'] = $this->header("x-real-ip")? : "";
        $log['from_username'] = iSession::get("name", "");
        $log['to_username'] = isset($log["to_username"]) ? $log["username"] : "";
        $log['desc'] = isset($log["desc"]) ? $log["desc"] : "";
        $log['time'] = time();
//        iServer::taskfn(function()use($log) {
//            (new UserActionLog())->getBuild()->insAdminLogs($log);
//        });
        unset($log);
    }

    /**
     * @action_doc_start
     * @action_index:ueditor
     * @action_name:上传图片针对百度富文本编辑器
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *           [], // 文件信息
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          "status": true,
     *          "img_path": [
     *              "http://oss.rainbow.com/help_center/20190404104514f47f1.71437606.PNG"
     *          ],
     *          "error": [
     *              null
     *           ]
     *      }
     * }
     * @action_doc_end
     */
    protected function actionUeditor($maxSize = 1, $allowImg = ['.jpg', '.jpeg', '.png', '.gif'], $maxWidth = '', $maxHight = '') {
        $ueditorPath = APP_DIR . '/libs_third/Ueditor/';

        $CONFIG = json_decode(preg_replace("/\/\*[\s\S]+?\*\//", "", file_get_contents($ueditorPath . "config.json")), true);
        $action = $this->input('get.action');
        $callback = $this->input('get.callback', '');
        $result = json_encode($CONFIG);
        $result = json_decode($result, true);
        $result['imageMaxSize'] = 1024 * 1024 * $maxSize;
        $result['imageAllowFiles'] = $allowImg;

        switch ($action) {
            case 'config':
                $result = json_encode($result);
                break;

            /* 上传图片 */
            case 'uploadimage':
            /* 上传涂鸦 */
            case 'uploadscrawl':
            /* 上传视频 */
            case 'uploadvideo':
            /* 上传文件 */
            case 'uploadfile':
                $config = array(
                    "pathFormat" => $this->uploadPath . '{yyyy}{mm}{dd}/{time}{rand:6}', //$result['imagePathFormat'],
                    "maxSize" => $result['imageMaxSize'],
                    "allowFiles" => $result['imageAllowFiles'],
                    "maxWidth" => $maxWidth,
                    "maxHight" => $maxHight
                );
                $fieldName = $result['imageFieldName'];
                include_once $ueditorPath . 'Uploader.class.php';
                /* 生成上传实例对象并完成上传 */

                $up = new Uploader($this->request->files, $config, 'upload', 'upfile');
                $result = $up->getFileInfo();
                $result['url'] = str_replace(UPLOAD_PATH, '/oss', $result['url']);
                $result = json_encode($result);
                break;

            /* 列出图片 */
            case 'listimage':
            /* 列出文件 */
            case 'listfile':
            /* 抓取远程文件 */
            case 'catchimage':
            default:
                $result = json_encode(array(
                    'state' => '请求地址出错'
                ));
                break;
        }

        /* 输出结果 */
        if ($callback) {
            if (preg_match("/^[\w_]+$/", $callback)) {
                echo htmlspecialchars($callback) . '(' . $result . ')';
            } else {
                echo json_encode(array(
                    'state' => 'callback参数不合法'
                ));
            }
        } else {
            return $result;
        }
    }

}
