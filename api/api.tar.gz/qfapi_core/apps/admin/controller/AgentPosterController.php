<?php

/**
 * @module_doc_start
 * @module_name:代理商宣传页
 * @module_model:AgentPoster
 * @module_description:
 * @module_doc_end
 */
class AgentPosterController extends  _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'AgentPoster';
    protected $uploadPath = UPLOAD_PATH . '/agent_poster/';

    // 先拿到要删除的图片 再对比，过滤不用删除的，最后删除图片
    private function setTodoImg()
    {
        $detail = $this->actionDetail();
        $detail = $detail['data']['detail'];

        $todoImg = [];
        $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
        preg_match_all($preg, $detail['content'], $todoImg);
        if (!empty($todoImg) && isset($todoImg[1])) {
            $todoImg = $todoImg[1];
        }
        $this->toDelImg= $todoImg;
        return $detail;
    }

    private function filterTodoImg($filterImgs)
    {
        if (empty($this->toDelImg)) {
            return true;
        }
        if (is_string($filterImgs)) { // 内容提取图片地址
            $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
            preg_match_all($preg, $filterImgs, $filterImgs);
            if (!empty($filterImgs) && isset($filterImgs[1])) {
                $filterImgs = $filterImgs[1];
            }
        }
        if (empty($filterImgs)) {
            return true;
        }
        foreach ($filterImgs as $val) {
            $pos = array_search(strtolower($val), $this->toDelImg);
            if ($pos !== false) {
                unset($this->toDelImg[$pos]);
            }
        }
    }

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          title:"如何注册123",
     *          content:"就是这样注册",
     *          remark: "备注"
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入文章的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = $this->input("post.data");
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['title']) || mb_strlen($data['title']) > 13)
            return $this->error(3, '标题请输入 1~13 位文字');

        if (!isset($data['content']) || empty($data['content']))
            return $this->error(3, '请输入内容详情');

        if (!isset($data['remark']) && mb_strlen($data['remark']) > 50)
            return $this->error(3, '备注最多输入 50 位字符');

        $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
        $imgs = [];
        preg_match_all($preg, $data['content'], $imgs);
        if (isset($imgs[1]) && count($imgs[1]) > 20) {
            return $this->error(3, '最多可以添加20张图片');
        }

        if($this->model($this->moduleModel)->_count()){
            $data['status'] = 0;
        } else {
            $data['status'] = 1;
        }


        $this->POST['data'] = $data;


        return parent::actionInsert();
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data: {
     *          title:"如何注册",
     *          content:"就是这样注册",
     *          remark: "备注"
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除文章的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误，查询条件不正确');

        $data = $this->input("post.data");
        if (empty($data))
            return $this->error(3, '参数错误');

        if (isset($data['title'])) {
            $this->POST['data']['title'] = $data['title'];
        }
        if (isset($data['content'])) {
            $this->POST['data']['content'] = $data['content'];
        }
        if (isset($data['remark'])) {
            $this->POST['data']['remark'] = $data['remark'];
        }

        if (empty($this->POST['data']['remark'])) {
            $this->success(["status" => TRUE, "affected_rows" => 0]);
        }

        $this->setTodoImg();

        $result = parent::actionUpdate();

        if (isset($result['data']['affected_rows']) && $result['data']['affected_rows']) {

            $this->filterTodoImg($data['content']);

            $this->delImg();
        }

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:列表
     * @action_description:
     * 请求参数:
     * { // 以下参数非必须
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          list:[
     *              {
     *                  id: 7,
     *                  title: "文章标题",
     *                  remark: "abc", // 标识
     *                  status: "1", //状态 1正常 0禁用 -1删除
     *                  create_at: "添加时间",
     *                  update_at: "修改时间",
     *              }
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $this->POST['attr'] = 'id, title, remark, status, create_at, update_at';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 1, //ID ，必须
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
            "detail": {
                "id": "2",
                "title": "不能为空",
                "content": "内容不能为空",
                "remark": "备注",
                "status": "1",
                "create_at": "1553858781",
                "update_at": "1553863685"
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');
        return parent::actionDetail();
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除文章的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');

        $this->setTodoImg();

        $detail = $this->model($this->moduleModel)->_detail($where);

        if (empty($detail)) {
            return $this->success(["status" => TRUE,  "affected_rows" => 0]);
        }

        if ($detail['status'] == 1) {
            return $this->error('不能删除启用的宣传页');
        }

        $result =  parent::actionDelete();

        if ($result['data']['affected_rows']) {
            $this->delImg();
        }


        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:启用（没有禁用）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {

        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '信息修改，必须提供准确的id');

        $this->POST['data'] = ['status' => 1];

        $result = parent::actionUpdate();

        if (isset($result['data']['affected_rows']) && $result['data']['affected_rows']) {

            $model = $this->model($this->moduleModel);
            $model->_update(['status' => 0], ['status' => 1, 'id' => ['<>', $where['id']]]);
        }

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:UplodImg
     * @action_name:上传图片
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *          FILE文件1,
     *          FILE文件1,
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          img_path: [ // 上传成功的文件路径 一个上传失败，同时上传的其他图片全部删除
                            "/help_center/图片1.PNG",
                            "/help_center/图片2.PNG"
                            ],
     *      }
     * }
     * @action_doc_end
     */
    public function actionUplodImg()
    {
        return $this->uplodImg(2, 'insertImg', $this->request->files);
    }


    /**
     * @action_doc_start
     * @action_index:ueditor
     * @action_name:上传图片针对百度富文本编辑器
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *           [], // 文件信息
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "status": true,
                "img_path": [
                        "http://oss.rainbow.com/help_center/20190404104514f47f1.71437606.PNG"
                    ],
                "error": [
                        null
                    ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionUeditor()
    {
        return parent::actionUeditor(2, ['.jpg', '.jpeg', '.png', '.tiff', '.raw', '.bmp'], 960);
    }

}
