<?php

/**
 * @module_doc_start
 * @module_name:代理商管理
 * @module_type:Agent
 * @module_description:
 * @module_doc_end
 */
class AgentController extends _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'Agent';

    private function getAgentTierList($isGetAll = true)
    {
        $model = $this->model('AgentTier');
        $returnData = [];

        if ($isGetAll) {
            $list = $model->_lists(['status' => 1], 'is_default desc', null, null, 'id,name,is_default');
            foreach ($list as $value) {
                $returnData[$value['id']] = $value;
            }
        } else {
            $detail = $model->_detail(['is_default' => 1]);
            $returnData = $detail ? $detail : [];
        }

        return $returnData;
    }

    private function setData($isAdd = true)
    {
        $data = (array) $this->input("post.data");
//        $data = array_map('trim', $data);
        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        $preg = $this->preg;

        if ($isAdd) {
            if (!isset($data['username']) || !preg_match($preg['username'], $data['username']))
                return $this->error(3, '请输入 5~11 位字母、数字或字母+数字组合');

            if (!isset($data['password']) || !preg_match($preg['password'], $data['password']))
                return $this->error(3, '请输入 6~12 位密码');
        }

        // 设置分层
        if (isset($data['tierid'])) {
            $list = $this->getAgentTierList();
            $ids = array_column($list, 'id');
            if (!in_array($data['tierid'], $ids)) {
                return $this->error(3, '分层不存在');
            }
        } else {
            $default = $this->getAgentTierList(false);
            $data['tierid'] = $default['id'];
        }

        if (isset($data['status'])) {
            if ($data['status'] != 1 && $data['status'] != 2) {
                return $this->error(3, '请选择状态');
            }
        } else {
            $data['status'] = 1;
        }

        if ($isAdd) {
            $data['rmd_code'] = $this->createRmdCode($this->moduleModel);
        }

        $this->POST['data'] = $data;
        return true;
    }

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          realname:"真实姓名",
     *          username:"abc123", // 代理账号
     *          password: 'abc123456',  // 密码
     *          phone:"13200000012", // 选填 手机号
     *          status: 1,  // 选填 状态 1正常 2停用 默认1
     *          bank_name: 'abc123456',  // 选填 开户行
     *          cardno: '12345678901234567',  // 选填 银行卡号
     *          qq: '123456789',  // 选填
     *          email: '123456789@qq.com',  // 选填
     *          tierid: 1,  //  选填 分层ID
     *          remark: '备注',  // 选填
     *          domain: '',  // 选填 域名
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入文章的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = $this->setData();

        if ($data !== true) {
            return $data;
        }

        $data = $this->input('post.data');

        $data['password'] = $this->password($data['password'], $data['username']);

        $model = $this->model($this->moduleModel);

        if ($model->_detail(['username' => $data['username']]))
            return $this->error(1, '代理账号已存在');

        $ret_insert = $model->_insert($data);

        $ret = [
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "insert_id" => (int) $ret_insert
        ];

        return $ret_insert === false ? $this->error('添加失败，请重试！') : $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          realname:"真实姓名",
     *          phone:"13200000012", // 选填 手机号
     *          status: 1,  // 选填 状态 1正常 2停用 默认1
     *          bank_name: 'abc123456',  // 选填 开户行
     *          cardno: '12345678901234567',  // 选填 银行卡号
     *          qq: '123456789',  // 选填
     *          email: '123456789@qq.com',  // 选填
     *          tierid: 1,  //  选填 分层ID
     *          remark: '备注',  // 选填
     *          domain: '',  // 选填 域名
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:2,//修改的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate() {
        $where = (array) $this->input('post.where');
        if (intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $data = $this->setData(false);

        if ($data !== true) {
            return $data;
        }

        $data = $this->input('post.data');

        if (isset($data['password']))
            unset($data['password']);

        if (isset($data['username']))
            unset($data['username']);

        $model = $this->model($this->moduleModel);
        $ret_insert = $model->_update($data, ['id' => intval($where['id'])]);

        $ret = [
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "affected_rows" => (int) $ret_insert
        ];

        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:setAttr/repwd
     * @action_name:重置密码
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          password1:"", // 新密码
     *          password2:"", // 确认密码
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//修改的个数
     *      }
     * }
     * @action_doc_end
     */

    /**
     * @action_doc_start
     * @action_index:setAttr/changeTier
     * @action_name:调整分层
     * @action_description:
     * setAttr/changeTier 调整分层
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          tierid: 1, // 分层ID
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//修改的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionSetAttr($type)
    {
        $type = strtolower($type);
        if (!in_array($type, ['repwd', 'changetier'])) {
            return $this->error(3, '接口有误');
        }
        $where = (array) $this->input("post.where");
        $data = (array) $this->input("post.data");
        if (empty($data) || empty($where) || !isset($where['id']) || $where['id'] <= 0)
            return $this->error(3, '参数错误');

        $_data = [];
        if (!in_array(strtolower($type), ['repwd', 'changetier'])) {
            return $this->error(3, '无效的接口');
        }

        $model = $this->model($this->moduleModel);
        if ($type == 'repwd') {
            if (!isset($data['password1']) || !isset($data['password2'])
                || empty($data['password1']) || empty($data['password2'])
                || !preg_match($this->preg['password'], $data['password2'])
            )
                return $this->error(3, '请输入 6~12 位密码');

            if ($data['password1'] != $data['password2'])
                return $this->error(3, '两次输入不一致');

            $detail = $model->_detail($where, null, 'username');
            if (empty($detail))
                return $this->error(3, '代理商不存在');

            $_data['password'] = $this->password($data['password1'], $detail['username']);
        } else if (strtolower($type) == 'changetier') {
            // 设置分层
            if (!isset($data['tierid'])) {
                return $this->error(3, '请选择分层');
            }
            $_data['tierid'] = intval($data['tierid']);
            if ($_data['tierid'] <= 0) {
                return $this->error(3, '请选择分层');
            }
            $list = $this->getAgentTierList();
            
            $ids = array_column($list, 'id');

            if (!in_array($data['tierid'], $ids)) {
                return $this->error(3, '分层不存在');
            }
        }

        $ret_insert = $model->_update($_data, ['id' => intval($where['id'])]);
        $ret = [
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "affected_rows" => (int) $ret_insert
        ];

        return $ret_insert ? $this->success($ret) : $this->error('重置失败，请稍后再试！');
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          status: 0, //  状态 0全选 1正常 2锁定 -1删除 默认0
     *          // 以下参数都不是必须参数 最多只能有一个参数 与 status组合查询
     *          username: ['like', '%meak%'],//  用户名 模糊查询
     *          rmd_code: 'meak1', // 推广码
     *          realname: ['like', '%meak%'], //  姓名
     *          tiername: '层级名称', //  层级名称
     *          domain: '域名', //  域名
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      order: 'id desc', // 排序 默认id desc ID倒序
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
              "lists": [
                    {
                    "id": "3",
                    "rmd_code": "A6sIoA",
                    "username": "abc12345",
                    "realname": "真实姓名",
                    "tierid": "1",
                    "domain": "",
                    "pid": "0",
                    "create_at": "1555162798",
                    "status": "1",
                    "tiername": "123", // 分层名称
                    "pname": "" //上级代理
                    }
              ],
              "total_num": 3,//总结记录数，如果请求参数中need_total=true将返回该值
              "total_page": 1,//总计分页数，如果请求参数中need_total=true将返回该值
              "tier": [ // 代理分层数据
                    {
                    "id": "1", // 层级ID
                    "name": "层级名称",
                    "is_default": "1" // 是否默认 1默认 0否
                    },
              ],
            }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $where = (array) $this->input('post.where');

        $_where = [];
        if (isset($where['rmd_code']) && !empty($where['rmd_code'])) {
            $_where['rmd_code'] = $where['rmd_code'];
        } else if (isset($where['tiername']) && !empty($where['tiername'])) {
            $ids = $this->model('AgentTier')->_lists(['name' => $where['tiername']], null, null, null, 'id');
            if ($ids) {
                $_where['tierid'] = ['in', array_column($ids, 'id')];
            } else {
                $returnData = ["lists" => []];
                if ($this->input("post.need_total", 0)) {
                    $returnData["total_num"] = 0;
                    $returnData["total_page"] = 0;
                }
                return $this->success($returnData);
            }
        } else if (isset($where['username']) && !empty($where['username'])) {
            $_where['username'] = $where['username'];
        } else if (isset($where['realname']) && !empty($where['realname'])) {
            $_where['realname'] = $where['realname'];
        } else if (isset($where['domain']) && !empty($where['domain'])) {
            $_where['domain'] = $where['domain'];
        }

        if (isset($where['status']) && in_array($where['status'], array(-1, 1, 2))) {
            $_where['status'] = $where['status'];
        }

        $fields =  'id, rmd_code, username, realname, tierid, domain, pid, create_at, status';

        $model = $this->Model($this->moduleModel);

        // 要处理账号=查询 存在站一条条记录 分页处理
        $page_size = (int) $this->input("post.page_size", 10);
        $page = (int) $this->input("post.page", 1);
        $need_total = (int) $this->input("post.need_total", 0);
        $_where = (array) array_filter($_where);


        // 处理分页
        $page_size = $page_size < 10 ? 10 : $page_size;
        $page = $page < 1 ? 1 : $page;
        $offset = ($page - 1) * $page_size;

        $list = $temp_list = [];
        $total_num = 0;
        if (isset($_where['username']) && count($_where['username']) == 2 && isset($_where['username'][1]) && !empty($_where['username'][1])) {
            $tempWhere = $_where;
            $tempWhere['username'] = trim($_where['username'][1], '%');
            $temp_list = $model->_lists($tempWhere, null, 1, 0, $fields);
        }

        if (!empty($temp_list)) {// 精准匹配上的话就会占用一条记录，sql就少差一条记录
            $_where['id'] = ['<>' ,$temp_list[0]['id']];
            $total_num = $total_num + 1;

            $limit = $page == 1
                        ? ($offset . ',' . ($page_size - 1))
                        : (($offset - 1) . ',' . $page_size);
        } else {
            $limit = $offset . ',' . $page_size;
        }

        $list = array_merge($temp_list, $model->_lists($_where, ' id desc', $limit, null, $fields));

        $tierList = [];
        foreach ($this->getAgentTierList() as $value)  {
            $tierList[$value['id']] = $value;
        }

        $pid = $pName = [];
        foreach ($list as $key => $value) {
            $list[$key]['tiername'] = isset($tierList[$value['tierid']]) ? $tierList[$value['tierid']]['name'] : '';
            if ($value['pid'])
                $pid[] = $value['pid'];
        }
        if ($pid) {
            $pName = $model->_lists(['id' => ['in', '(' . implode(',', $pid) . ')']], null, null, null, 'id, username');
            $pName = array_column($pName, 'name', 'pid');
        }
        foreach ($list as $key => $value) {
            $list[$key]['pname'] = isset($pName[$value['pid']]) ? $pName[$value['pid']] : '';
        }
        $returnData = ["lists" => $list];
        if ($need_total) {
            $total_num = $total_num + $model->_count($_where, null);
            $returnData["total_num"] = (int) $total_num;
            $returnData["total_page"] = ceil($total_num / $page_size);
        }

        $returnData['tier'] = array_values($tierList);

        return $this->success($returnData);
    }

    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:1,
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          detail:{
     *             "id": "1",
                    "username": "abc123",
                    "password": "46573b9d033b5893d9a7a51217c45fba",
                    "realname": "真名",
                    "rmd_code": "AKfDMT",
                    "tierid": "1",
                    "domain": "123",
                    "pid": "0",
                    "phone": "",
                    "email": "123456789@qq.com",
                    "qq": "123456789",
                    "cardno": "12345678901234567",
                    "bank_name": "abc123456",
                    "remark": "备注",
                    "status": "1",
                    "create_at": "1555159294",
                    "update_at": "1555163430",
                    "tiername": "123", // 分层名称
                    "pname": "" //上级代理
     *          }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');

        $model = $this->Model($this->moduleModel);
        $_detail = $model->_detail(['id' => intval($where['id'])]);

        if (empty($_detail)) {
            return $this->success(["detail" => null]);
        }

        $tierList = [];
        foreach ($this->getAgentTierList() as $value)  {
            $tierList[$value['id']] = $value;
        }
        $_detail['tiername'] = isset($tierList[$_detail['tierid']]) ? $tierList[$_detail['tierid']]['name'] : '';

        $_detail['pname'] = '';
        if ($_detail['pid']) {
            $pName = $model->_detail(['id' => $_detail['pid']], null, null, null, 'username');
            $_detail['pname'] = isset($pName['username']) ? $pName['username'] : '';
        }


        return $this->success(["detail" => $_detail]);
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      },
     *      data:{
     *          status: 1, // 状态 1启用 2停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus() {
        $status = (int) $this->input('post.data.status');
        if ($status != 1 && $status != 2)
            return $this->error(3, '参数有误');
        return parent::actionChangeStatus();
    }

}
