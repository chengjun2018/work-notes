<?php

/**
 * @module_doc_start
 * @module_name:广告模块（banner图片管理，游戏入口多一个配置参数json格式（json格式至少包含：配置区域、跳转类型、游戏类型、游戏平台具体参看产品原型））
 * @module_model:Ad
 * @module_description:
 * @module_doc_end
 */
class AdController extends  _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'banner';

    protected $uploadPath = UPLOAD_PATH . '/ad/';

    protected $toDelImg = '';

    private function setTodoImg()
    {
        // 如果是修改 并且有图片 就要考虑图片上传 及删除
        $adModel = $this->model($this->moduleModel);
        $detail = $adModel->_detail($this->POST['where'], null, 'path');
        $this->toDelImg = $detail['path'];
    }

    private function setData($num, $isAdd = true)
    {
        $data = $this->input("post.data");
        if (empty($data)) {
            return $this->error(3, '参数错误');
        }
        $data = array_map('trim', $data);

        if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
            return $this->error(3, '请输入标题');

        if ($num == 4) {
            if (!isset($data['jsondata']) || empty($data['jsondata'])) {
                return $this->error(3, '游戏入口配置错误');
            }

            $data['jsondata'] = json_decode($data['jsondata'], true);
            if (empty($data['jsondata']['type']) || ($data['jsondata']['type'] != 1 && $data['jsondata']['type'] != 2)) {
                return $this->error(3, '请选择跳转类型');
            }
            if (empty($data['jsondata']['position'])) {
                return $this->error(3,'请选择配置区域');
            }
        } else {
            if (!isset($data['type']) || ($data['type'] != 1 && $data['type'] != 2))
                return $this->error(3, '请选择类型');

            $data['jsondata'] = '';
        }

        // 左右弹窗 不用上传图片
        if ($num == 2 || $num == 3) {
            $data['path'] = '';
        } else {
            $data['img_path'] = strtolower($data['image_file']);
//            if (!preg_match($this->preg['img_path'], $data['img_path'])) {
//                return $this->error(3, '图片路径格式有误');
//            }
            if (!$isAdd) {
                $this->setTodoImg();
            }
            $data['path'] = $data['img_path'];

        }

        if (!isset($data['sort']) || !preg_match($this->preg['int'], $data['sort']))
            return $this->error(3, '排序仅支持数字');

        if (!isset($data['sort']))
            $data['sort'] = 0;

        $data['status'] = 1;

        // 游戏入口要判断json
        if ($num == 4) {
            if ($data['jsondata']['type'] == 1 && (empty($data['jsondata']['game']) || empty($data['jsondata']['gamechild']))) {
                return $this->error(3,'请选择游戏类型和平台');
            }
            if ($data['jsondata']['type'] == 2 && empty($data['jsondata']['game'])) {
                return $this->error(3,'请选择游戏列表');
            }
            if ($data['jsondata']['type'] == 2 && empty($data['jsondata']['game'])) {
                return $this->error(3,'请选择游戏列表或游戏类型');
            }
            if ($data['jsondata']['type'] == 1 && empty($data['jsondata']['gamechild'])) {
                return $this->error(3,'请选择游戏平台');
            }
            if ($data['jsondata']['type'] == 2 && empty($data['jsondata']['gamechild'])) {
                // return $this->error(3,'请填写游戏链接');
            }
            if ($data['jsondata']['type'] == 2 && !empty($data['jsondata']['gamechild']) && preg_match($this->preg['url'], $data['jsondata']['gamechild'])) {
                return $this->error(3,'请填写游戏链接');
            }
            // 判断位置是否已存在
            if ($isAdd) {
                $model = $this->model($this->moduleModel);
                $list = $model->_lists(['position' => 4], null, null, 0, 'type, jsondata');
                $h5_pos = $pc_pos = [];
                if ($list) {
                    foreach ($list as $value) {
                        $temp = json_decode($value['jsondata'], true);
                        // PC
                        if ($value['type'] == 1) {
                            $pc_pos[] = $temp['position'];
                        }
                        // H5
                        if ($value['type'] == 2) {
                            $h5_pos[] = $temp['position'];
                        }
                    }
                }
                if ($data['type'] == 1 && in_array($data['jsondata']['position'], $pc_pos)) {
                    return $this->error(1000,'配置区域已配置');
                }
                if ($data['type'] == 2 && in_array($data['jsondata']['position'], $h5_pos)) {
                    return $this->error(1000,'配置区域已配置');
                }
            }
            $data['jsondata'] = json_encode($data['jsondata']);
        }
        if (isset($data['href']) && !empty($data['href'])) {
            if (!preg_match($this->preg['url'], strtolower($data['href'])))
                return $this->error(3, '链接地址格式有误');
        } else {
            $data['href'] = '';
        }

        $data['position'] = $num;

        $this->POST['data'] = $data;
    }

    /**
     * @action_doc_start
     * @action_index:insert/1
     * @action_name:添加（insert/n(n为1-7的数字，1首页轮播图,2首页左侧弹窗,3首页右侧弹窗,4游戏入口图片,5优惠活动图片,6热门推荐,7活动宣传图片)）
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          title:"如何注册",
     *          type: 1, // 类型 1 PC 2 H5
     *          sort: 0,  // 排序
     *          image_file: 'http://xxx.com/xxx.png',// 图片路径
     *          href: 1,  // 排序
     *          jsondata: '{"position":1,"type":1,"game":"","gamechild":""}',  // json字符串
     *              // position 配置区域
     *              // type 跳转类型：1.第三方游戏大厅 2.平台游戏列表
     *              // game 游戏类型：1.真人娱乐 2.棋牌游戏 3.电子游艺 4.体育竞技 5.彩票游戏 6.捕鱼游戏
     *              // gamechild 如果跳转类型为1的话，展示游戏平台名称；为2就是跳转链接
     *      },
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert($num)
    {
        if ($num < 1 || $num > 7)
            return $this->error(3, '无效的请求');

        $lockName = 'insert_banner_4_' . mt_rand(10000, 99999);

        $this->getLock($lockName, 3);
        $data = $this->setData($num, true);

        if ($data['code'] != 0) {
            $this->unLock($lockName);
            return $data;
        }

        $result = parent::actionInsert();
        $this->unLock($lockName);

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:update/1
     * @action_name:修改（insert/n(n为1-7的数字，1首页轮播图,2首页左侧弹窗,3首页右侧弹窗,4游戏入口图片,5优惠活动图片,6热门推荐,7活动宣传图片)）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          title:"如何注册",
     *          type: 1, // 类型 1 PC 2 H5
     *          sort: 0,  // 排序
     *          image_file: FILE 文件 或者 字符串 "http://oss.irainbow7.com/ad/2019040833839.54915371.PNG",
                        // 如果没有进行修改图片就不用上传，只不过image_file的值为原图片的URL，FILE文件跟随表单一起提交 （2首页左侧弹窗 3首页右侧弹窗 不用上传）
     *          href: 1,  // 排序
     *          jsondata: '{"position":1,"type":1,"game":"","gamechild":""}',  // 只有4游戏入口图片添加有此字段 position 配置区域 type 1第三方游戏大厅 2平台游戏列表 3游戏 4游戏子选项（游戏平台 OR 跳转链接）
     *      },
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate($num)
    {
        if ($num < 1 || $num > 7)
            return $this->error(3, '无效的请求');

        $where = $this->input("post.where");
        $this->POST['where'] = ['id' => $where['id'], 'position' => $num];

        $data = $this->setData($num, false);

        if ($data['code'] != 0) {
            return $data;
        }

        $result = parent::actionUpdate();

        if ($result['data']['affected_rows']) {
            $this->delImg();
        }

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:lists/1
     * @action_name:列表（insert/n(n为1-7的数字，1首页轮播图,2首页左侧弹窗,3首页右侧弹窗,4游戏入口图片,5优惠活动图片,6热门推荐,7活动宣传图片)）
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 没有搜索功能
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          list:[
                    {
                        "id": "12",
                        "path": "http://oss.irainbow7.com/ad/20190408b1768.07324896.PNG",
                        "title": "游戏入口图片",
                        "status": "1",
                        "sort": "0",
                        "type": "1",
                        "position": "1",
                        "href": "",
                        "jsondata": "{\"position\":1,\"type\":2,\"game\":\"1\",\"gamechild\":\"2\"}",
                        "create_at": "1554739007",
                        "update_at": "1554739761"
                    },
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     * }
     * @action_doc_end
     */
    public function actionLists($num)
    {
        if ($num < 1 || $num > 7)
            return $this->error(3, '无效的请求');

        $this->POST['where'] = 'position = ' . $num;
        $this->POST['order'] = 'sort desc,id desc';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:detail/1
     * @action_name:详情（insert/n(n为1-7的数字，1首页轮播图,2首页左侧弹窗,3首页右侧弹窗,4游戏入口图片,5优惠活动图片,6热门推荐,7活动宣传图片)）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 1, //ID ，必须
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "detail":  {
                    "id": "11",
                    "path": "",
                    "title": "like",
                    "status": "1",
                    "sort": "0",
                    "type": "1",
                    "position": "1",
                    "href": "",
                    "jsondata": "",
                    "create_at": "1554737835",
                    "update_at": "1554737835"
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail($num)
    {
        if ($num < 1 || $num > 7)
            return $this->error(3, '无效的请求');

        $where = $this->input("post.where");

        $this->POST['where'] = ['id' => $where['id'], 'position' => $num];

        return parent::actionDetail();
    }

    /**
     * @action_doc_start
     * @action_index:delete/1
     * @action_name:删除（insert/n(n为1-7的数字，1首页轮播图,2首页左侧弹窗,3首页右侧弹窗,4游戏入口图片,5优惠活动图片,6热门推荐,7活动宣传图片)）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete($num)
    {
        if ($num < 1 || $num > 7)
            return $this->error(3, '无效的请求');

        $where = $this->input("post.where");
        $this->POST['where'] = ['id' => $where['id'], 'position' => $num];

        $this->setTodoImg();

        $result =  parent::actionDelete();

        if ($result['data']['affected_rows']) {
            $this->delImg();
        }

        return $result;
    }


    /**
     * @action_doc_start
     * @action_index:changeStatus/1
     * @action_name:禁用/启用（insert/n(n为1-7的数字，1首页轮播图,2首页左侧弹窗,3首页右侧弹窗,4游戏入口图片,5优惠活动图片,6热门推荐,7活动宣传图片)）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          status: 0, // 状态 1正常 0禁用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus($num)
    {
        $where = $this->input("post.where");
        $status = (int) $this->input("post.data.status");
        if ($status < -1 || $status > 1)
            return $this->error(3, '参数有误');

        if ($num < 1 || $num > 7)
            return $this->error(3, '无效的请求');


        $this->POST['where'] = ['id' => $where['id'], 'position' => $num];
        $this->POST['data'] = ['status' => $status];

        return parent::actionChangeStatus();
    }

    /**
     * @action_doc_start
     * @action_index:UplodImg
     * @action_name:上传图片
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *          FILE文件1,
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          img_path: [ // 上传成功的文件路径 一个上传失败，同时上传的其他图片全部删除
                    "/help_center/图片1.PNG",
                ],
     *      }
     * }
     * @action_doc_end
     */
    public function actionUplodImg()
    {
        return $this->uplodImg(1, 'insertImg', $this->request->files);
    }

    /**
     * @action_doc_start
     * @action_index:gameList
     * @action_name:游戏列表及位置占用情况
     * @action_description:
     * 请求参数: 无
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *      "list": [
                {
                    "value": "live",
                    "label": "真人娱乐",
                    "children": [
                        {
                            "value": "ag",
                            "label": "AG视讯"
                        },
                        {
                            "value": "bbin",
                            "label": "BBIN视讯"
                        },
                        {
                            "value": "og",
                            "label": "OG"
                        },
                        {
                            "value": "ds",
                            "label": "DS厅"
                        },
                        {
                            "value": "bg",
                            "label": "BG厅"
                        }
                    ]
                },
              ],
            "existence": {
                "pc": [
                    "2",
                    "2",
                    "1",
                    "1",
                    "1"
                    ],
                "h5": [
                    "7",
                    "7",
                    "2",
                    "1",
                    "1"
                    ]
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionGameList()
    {
        $data = [
            'list' => (new Game())->getTypeData(),
            'existence' => [
                'pc' => [],
                'h5' => []
            ]
        ];

        $model = $this->model($this->moduleModel);
        $list = $model->_lists(['position' => 4]);
        if ($list) {
            foreach ($list as $value) {
                $temp = json_decode($value['jsondata'], true);
                // PC
                if ($value['type'] == 1) {
                    $data['existence']['pc'][] = $temp['position'];
                }
                // H5
                if ($value['type'] == 2) {
                    $data['existence']['h5'][] = $temp['position'];
                }
            }
        }

        return $this->success($data);
    }


}
