<?php

/**
 * @module_doc_start
 * @module_name:代理（分层）返水返佣
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class AgentReturnController extends _AdminController
{

    public $needCheckAccess = true;
    protected $moduleModel = 'AgentTier';


    /**
     * @action_doc_start
     * @action_index:gameList
     * @action_name:游戏列表
     * @action_description:
     * 请求参数: 无
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "list": [
                    {
                        "value": "live_ag",
                        "label": "AG视讯"
                    },
                 ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionGameList()
    {
        $list =  (new Game())->getTypeData('list');

        return $this->success(['list' => $list]);
    }

    private function checkRadioData($radioData)
    {
        $codeList = array_column($radioData, 'value');
        $temp1 = count($codeList);
        $temp3 = count(array_column($radioData, 'radio'));

        if ($temp1 == 0 || $temp1 != $temp3) {
            return $this->error(3, '参数错误');
        }

        $gameList = $list =  (new Game())->getTypeData('list');
        $gameCodeList = array_column($gameList, 'label','value');

        foreach ($radioData as $key => $value) {
            if (!isset($gameCodeList[$value['value']])) {
                return $this->error(3, $value['radio'] . '未知或已被禁用');
            }
            $radioData[$key]['radio'] = floatval(number_format($value['radio'], 2,".",""));
            if ($value['radio'] != $radioData[$key]['radio']) {
                return $this->error(3, $value['label'] . '比例输入有误');
            }
            if ($value['radio'] > 100 || $value['radio'] < 0) {
                return $this->error(3, '仅支持输入 0~100 之间的正数，支持 2 位小数');
            }
        }

        // 新添加平台的话就需要添加对应的比例
        foreach ($gameList as $value) {
            if (!in_array($value['value'], $codeList)) {
                $radioData[] = [
                    'value' => $value['value'],
                    'radio' => 0
                ];
            }
        }

        // 防止乱码
        $returnData = [];
        foreach ($radioData as $value) {
            $returnData[] = [
                'value' => $value['value'],
                'radio' => $value['radio']
            ];
        }

        return $returnData;
    }

    private function setRaidoData($redioData)
    {
        $gameList =  (new Game())->getTypeData('list');
        if (empty($redioData)) {
            $redioData = [];
            foreach ($gameList as $value) {
                $redioData[] = [
                    'value' => $value['value'],
                    'label' => $value['label'],
                    'radio' => 0
                ];
            }
            return $redioData;
        }

        $tempGameList = json_decode($redioData, true);

        $codeList = array_column($tempGameList, 'value');
        foreach ($gameList as $value) {
            // 新添加平台的话就需要添加对应的比例
            if (!in_array($value['value'], $codeList)) {
                $tempGameList[] = [
                    'value' => $value['value'],
                    'radio' => 0
                ];
            }
        }
        $codeList = array_column($gameList, 'label', 'value');
        foreach ($tempGameList as $key => $value) {
            if (isset($codeList[$value['value']])) {
                $tempGameList[$key]['label'] = $codeList[$value['value']];
            }
        }

        return $tempGameList;
    }

    /**
     * @action_doc_start
     * @action_index:set/bet
     * @action_name:返佣设置-》退水保存
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          tierid: 2, // 代理商分层ID
     *      },
     *      data:{
     *          'amount': 100,
     *          'radio_data':[
     *              {
     *                   'value': 'live_ag', // 编码
     *                   'label': 'AG视讯', // 游戏名称
     *                   'radio': '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    /**
     * @action_doc_start
     * @action_index:set/win
     * @action_name:返佣设置-》退佣保存
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          tierid: 2, // 代理商分层ID
     *      },
     *      data:{
     *          'amount': 100,
     *          'radio_data':[
     *              {
     *                   'value': 'live_ag', // 编码
     *                   'label': 'AG视讯', // 游戏名称
     *                   'radio': '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionSet($type)
    {
        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '接口错误');
        }
        $data = $this->input('post.data');
        $where = $this->input('post.where');

        if (empty($where) || $where['tierid'] <= 1 || empty($data) || empty($data['radio_data']) || !is_array($data['radio_data'])) {
            return $this->error(3, '参数错误');
        }

        $data['amount'] = intval($data['amount']);
        if ($data['amount'] < 0) {
            return $this->error(3, '仅支持输入大于等于0的正整数');
        }

        $checkRs = $this->checkRadioData($data['radio_data']);
        if (isset($checkRs['code'])) {
            return $checkRs;
        }

        $model = $this->model('AgentReturn' . ucfirst($type));

        $_data = [
            'agent_tierid' => $where['tierid'],
            'money' => $data['amount'],
            'radio_json' => json_encode($checkRs)
        ];

        $ret_insert = $model->_insert($_data);
        $ret = array(
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "insert_id" => (int) $ret_insert
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:detail/bet
     * @action_name:返佣设置-》退水数据
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          tierid: 2, // 代理商分层ID
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "amount": "100.00",
                "radio_data": [
                    {
                        "value": "live_ag",
                        "label": "AG视讯",
                        "radio": 0.01
                    },
                ]
     *      }
     * }
     * @action_doc_end
     */
    /**
     * @action_doc_start
     * @action_index:detail/win
     * @action_name:返佣设置-》退佣数据
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          tierid: 2, // 代理商分层ID
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "amount": "100.00",
                "radio_data": [
                    {
                        "value": "live_ag",
                        "label": "AG视讯",
                        "radio": 0.01
                    },
                ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail($type)
    {
        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '参数错误');
        }
        $where = $this->input('post.where');

        if (empty($where) || $where['tierid'] <= 1) {
            return $this->error(3, '参数错误');
        }

        $model = $this->model('AgentReturn' . ucfirst($type));

        $data = $model->_lists(['agent_tierid' => $where['tierid']], 'id desc', 1, 0, 'money, radio_json');

        if (empty($data)) {
            $returnData = [
                'amount' => 0,
                'radio_data' => $this->setRaidoData('')
            ];
        } else {
            $returnData = [
                'amount' => $data[0]['money'],
                'radio_data' => $this->setRaidoData($data[0]['radio_json'])
            ];
        }

        return $this->success($returnData);
    }

    /**
     * @action_doc_start
     * @action_index:insert/bet
     * @action_name:（默认分层）返水设置-》添加
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          'amount': 100,
     *          'radio_data':[
     *              {
     *                   'value' : 'live_ag', // 编码
     *                   'label' : 'AG视讯', // 游戏名称
     *                   'radio' : '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    /**
     * @action_doc_start
     * @action_index:insert/win
     * @action_name:（默认分层）返佣设置-》添加
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          'amount': 100,
     *          'radio_data':[
     *              {
     *                   'value': 'live_ag', // 编码
     *                   'label': 'AG视讯', // 游戏名称
     *                   'radio': '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert($type)
    {
        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '接口错误');
        }
        $title = $type == 'win' ? '输赢金额' : '有效投注';
        $data = $this->input('post.data');

        if (empty($data) || empty($data['radio_data']) || !is_array($data['radio_data'])) {
            return $this->error(3, '参数错误');
        }

        $data['amount'] = intval($data['amount']);
        if ($data['amount'] <= 0) {
            return $this->error(3, $title . '仅支持输入大于等于0的正整数');
        }
        $model = $this->model('AgentReturn' . ucfirst($type));

        if ($model->_count(['agent_tierid' => 1, 'status' => 1, 'money' => $data['amount']])) {
            return $this->error(1000, '已存在请核对');
        }

        $checkRs = $this->checkRadioData($data['radio_data']);
        if (isset($checkRs['code'])) {
            return $checkRs;
        }

        $_data = [
            'agent_tierid' => 1,
            'money' => $data['amount'],
            'radio_json' => json_encode($checkRs)
        ];

        $ret_insert = $model->_insert($_data);
        $ret = array(
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "insert_id" => (int) $ret_insert
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:update/bet
     * @action_name:（默认分层）返水设置-》编辑
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data:{
     *          'amount': 100,
     *          'radio_data':[
     *              {
     *                   'value': 'live_ag', // 编码
     *                   'label': 'AG视讯', // 游戏名称
     *                   'radio': '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除的个数
     *      }
     * }
     * @action_doc_end
     */
    /**
     * @action_doc_start
     * @action_index:update/win
     * @action_name:（默认分层）返佣设置-》编辑
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data:{
     *          'amount': 100,
     *          'radio_data':[
     *              {
     *                   'value': 'live_ag', // 编码
     *                   'label': 'AG视讯', // 游戏名称
     *                   'radio': '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//编辑成功，返回true，失败返回false
     *          affected_rows:2,//编辑的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate($type)
    {
        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '接口错误');
        }

        $where = (array) $this->input('post.where');
        if (empty($where) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $where = [
            'id' => $where['id'],
            'agent_tierid' => 1,
        ];

        $data = $this->input('post.data');

        if (empty($data) || empty($data['radio_data']) || !is_array($data['radio_data'])) {
            return $this->error(3, '参数错误');
        }

        $model = $this->model('AgentReturn' . ucfirst($type));
        $detail =  $model->_detail($where, 0, 'id,money');

        $data['amount'] = intval($data['amount']);

        if (!empty($detail)) { // 编辑
            if (($detail['money'] == 0 && $data['amount'] != 0) || ($detail['money'] != 0 && $data['amount'] == 0)) {
                return $this->error(3, '默认数据有效投注 0 不可编辑，比例可编辑，不可删除');
            }
            if ($data['amount'] < 0) {
                return $this->error(3, '仅支持输入大于 0 以上正数');
            }
            $checkRs = $this->checkRadioData($data['radio_data']);
            if (isset($checkRs['code'])) {
                return $checkRs;
            }
            $_data = [
                'agent_tierid' => 1,
                'money' => $data['amount'],
                'radio_json' => json_encode($checkRs)
            ];

            // 判断金额是否存在
            if ($data['amount'] > 0 && $model->_count(['agent_tierid' => 1, 'money' => $data['amount'], 'status' => 1, 'id' => ['<>', $where['id']]])) {
                return $this->error(1000, '已存在请核对');
            }

            // 修改新返水老数据就删掉 但是还要明天之前还要使用
            $ret_update =  $model->_insert($_data) === false ? false : 1;
            if ($ret_update) {
                $time = time();
                $model->_update(['status' => 0, 'update_at' => $time], ['id' => $detail['id']]); // 0 有效期一天
                $model->_update(['status' => -1, 'update_at' => $time], ['agent_tierid' => 1, 'money' => $detail['money'], 'id' => ['<', $where['id']],  'status' => ['<>', -1]]);
            }
        } else {
            // 添加有效投注0的
            $detail =  $model->_detail(['money' => 0], 0, 'money');
            if ($detail || $data['amount'] != 0) {
                return $this->error(3, '默认数据有效投注 0 不可编辑，比例可编辑，不可删除');
            }

            $checkRs = $this->checkRadioData($data['radio_data']);
            if (isset($checkRs['code'])) {
                return $checkRs;
            }

            $_data = [
                'agent_tierid' => 1,
                'money' => 0,
                'radio_json' => json_encode($checkRs)
            ];

            $ret_update = $model->_insert($_data) === false ? false : 1;
        }

        $ret = array(
            "status" => $ret_update === FALSE ? FALSE : TRUE,
            "affected_rows" => (int) $ret_update
        );
        return $ret_update === false ? $this->error('编辑失败，请重试！') : $this->success($ret);
    }


    /**
     * @action_doc_start
     * @action_index:delete/bet
     * @action_name:（默认分层）返水设置-》删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除个数
     *      }
     * }
     * @action_doc_end
     */
    /**
     * @action_doc_start
     * @action_index:delete/win
     * @action_name:（默认分层）返佣设置-》删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete($type)
    {
        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '接口错误');
        }

        $where = (array) $this->input('post.where');
        if (empty($where) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $modelName = 'AgentReturn' . ucfirst($type);
        $model = $this->model($modelName);
        $detail =  $model->_detail(['id' => $where['id'], 'agent_tierid' => 1], 0, 'money');

        if (empty($detail)) {
            return $this->success(["status" => true, "affected_rows" => 0]);
        }

        if ($detail['money'] == 0) {
            return $this->error(3, '默认数据有效投注 0 不可编辑，比例可编辑，不可删除');
        }

        $time = time();
        $result = $model->_update(['status' => 0, 'update_at' => $time], ['id' => $where['id'], 'agent_tierid' => 1]);
        if ($result !== false) {
            $model->_update(['status' => -1, 'update_at' => $time], ['agent_tierid' => 1, 'money' => $detail['money'], 'id' => ['<', $where['id']],  'status' => ['<>', -1]]);
            return $this->success(["status" => true, "affected_rows" => 1]);
        }

        return $this->error('删除失败，，请重试！');

    }

    /**
     * @action_doc_start
     * @action_index:lists/bet
     * @action_name:（默认分层）返水设置-》列表
     * @action_description:
     * 请求参数: // 没有分页 没有统计
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "lists": [
                    {
                        "id": "10",
                        "amount": "0.00",
                        "amount_data": "0~", // 有效投注 或  输赢 区间
                        "radio_data": [
                            {
                            "value": "live_ag",
                            "label": "AGनu89c6नu8baf",
                            "radio": 0.01
                            },
                        ],
                    },
                ]
            }
     * }
     * @action_doc_end
     */
    /**
     * @action_doc_start
     * @action_index:lists/win
     * @action_name:（默认分层）返佣设置-》列表
     * @action_description:
     * 请求参数: // 没有分页 没有统计
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "lists": [
                    {
                    "id": "10",
                    "amount": "0",
                    "amount_data": "0~", // 有效投注 或  输赢 区间
                    "radio_data": [
                            {
                                "value": "live_ag",
                                "label": "AGनu89c6नu8baf",
                                "radio": 0.01
                            },
                        ],
                    },
                ]
            }
     * }
     * @action_doc_end
     */
    public function actionLists($type)
    {
        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '接口错误');
        }

        $sql = "SELECT id, money, radio_json, agent_tierid FROM agent_return_{$type}  WHERE agent_tierid=1 AND status=1 ORDER BY id DESC" ;
        $model = $this->model('AgentReturn' . ucfirst($type));
        $list = $model->_query($sql, 0);

        $returnData = [];
        if (empty($list)) {
            $radioData = $this->setRaidoData('');
            $returnData[] = [
                'id' => 1,
                'amount' => 0,
                'amount_data' => '0~',
                'radio_data' => $radioData
            ];
            $_data = [
                'agent_tierid' => 1,
                'money' => 0,
                'radio_json' => json_encode($this->checkRadioData($radioData))
            ];
            $model->_insert($_data);

        } else {
            $moneryArray = [];
            foreach ($list as $key => $value) {
                if (!in_array($value['money'], $moneryArray)) {
                    $returnData[] = [
                        'id' => $value['id'],
                        'amount' => $value['money'],
                        'radio_data' => $this->setRaidoData($value['radio_json'])
                    ];
                    $moneryArray[] = $value['money'];
                }
            }
            array_multisort(array_column($returnData, 'amount'), SORT_ASC, $returnData);
            foreach ($returnData as $key => $val) {
                $returnData[$key]['amount_data'] = ($val['amount'] . '~' . (isset($returnData[$key + 1]) ? $returnData[$key + 1]['amount'] : ''));
            }
        }

        return $this->success(['list' => $returnData]);

    }

    protected function actionCurrentReturn($type)
    {
//        if ($type != 'win' && $type != 'bet') {
            return $this->error(3, '接口错误');
//        }

        $time2 = strtotime(date('Y-m-d') . ' 23:59:59');

        $sql = "SELECT id, money, radio_json, agent_tierid, `status`,update_at FROM agent_return_{$type}  WHERE agent_tierid=1 AND status!=-1 AND update_at < {$time2} ORDER BY id DESC" ;

        $list = $this->model('AgentReturn' . ucfirst($type))->_query($sql, 0);

        $returnData = [];
        if ($list) {
            // 设置有效数据
            $moneryArray = $tempArray = [];
            foreach ($list as $key => $value) {
                if (!in_array($value['money'], $moneryArray)) {
                    $tempArray[] = [
                        'id' => $value['id'],
                        'amount' => $value['money'],
                        'radio_data' => $this->setRaidoData($value['radio_json']),
                        'agent_tierid' => $value['agent_tierid'],
                        'status' => $value['status'],
                        'update_at' => $value['update_at']
                    ];
                    $moneryArray[] = $value['money'];
                }
            }
            array_multisort(array_column($tempArray, 'amount'), SORT_ASC, $tempArray);

            // 判断是否有效
            $time1 = strtotime(date('Y-m-d'));
            foreach ($tempArray as $value) {
                // 判断当前数据是否有效 1天的有效期
                if ($value['status'] == 1 || ($value['status'] == 0 && $time1 < $value['update_at'] && $time2 > $value['update_at'])) {
                    $value['radio_json'] = $this->setRaidoData($value['radio_json']);
                    $returnData[] = $value;
                }
            }
        }

        return $this->success($returnData);
    }

}
