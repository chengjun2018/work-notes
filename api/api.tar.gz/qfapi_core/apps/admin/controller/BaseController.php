<?php

/**
 * @module_doc_start
 * @module_name:框架基础模块
 * @module_description:
 * 该模块包含包含系统基础的：图像验证码、自动化文档、自动化模型
 * 交互基础
 * 
 * 1.前段请求方式：请使用post（全部！！）
 * 
 * 2.请求的格式：
 *     {
 *          device:"brower",//每次请求必填参数。设备类型，有产品需求定义，不同设备，如ios/android/pc_client/pc_web/mobile_web,用于区分接口调用的不同来源
 *          accesss_token:"xxxx",//每次请求必填参数。保持会话必须，如果客户端无则值为空字符串，服务端将在当前请求的返回值中返回一个合法的access_token,客户端每次查验到服务端接口中有返回access_token需要保存最新access_token
 *          "其他参数1":"其他参数1的值",//可以是多层级对象,根据具体接口文档传参
 *     }
 * 
 * 3.返回值：
 *     3.1：格式为json
 *     3.1: http状态码非200提示"网络不给力,请重试"
 *     3.2: http状态码为200根据返回json数据状态处理
 *     {
 *          code:0,//状态码，0:正常，成功数据交互，1：通用错误，将会在msg中返回可面向用户提示的消息；3：参数错误，同样会在msg中返回消息；401：请登录； 403：权限不足，你无法进行此操作；404:访问地址不存在；500：服务异常，稍后再试
 *          msg:""//错误消息
 *          data:{
 *              //当code为0时的返回数据，一定是对象，而非数组
 *          },
 *          spend_time_all:2,//debug模式下供调试使用，该值为后端接口处理总耗时，单位为ms
 *          _sql_commands: [],//debug模式下供调试使用，该值为后端接口数据库每个io耗时，单位为ms
 *          _session_commands: ["get|[\"accesstoken_brower##1553161232##675c61d31280e78f7fe67dfb6cee6e7ff21cc4f7\"][fd][spt:0.066041946411133]"],//debug模式下供调试使用，该值为后端接口会话的每个io耗时，单位为ms
 *          _cache_commands: []//debug模式下供调试使用，该值为后端接口数据缓存每个io耗时，单位为ms
 *     }
 * 
 * 4.通用接口请求及返回，例子
 *     例子：添加帮助中心文章
 *     请求地址：helpcontent/insert
 *     请求方式：post
 *     请求参数:
 *     {
 *          data:{
 *              title:"如何注册",
 *              content:"就是这样注册"
 *          }
 *     }
 *     
 *     返回数据：
 *     {
 *          code:0,
 *          msg:"",
 *          data:{
 *              status:true/false,//添加成功，返回true，失败返回false
 *              insert_id:12866,//插入文章的id
 *          }
 *     }
 *   -------------------------------------------------------------------
 *   
 *     例子：删除帮助中心文章
 *     请求地址：helpcontent/delete
 *     请求方式：post
 *     请求参数:
 *     {
 *          where:{
 *              id:12,
 *              //id:["in",[1,2,3]],
 *              //create_time:["between",['2019-12-12 12:12:12','2019-12-13 12:12:12']],
 *              //id:[">",100],
 *              //title:["like","%登陆%"],
 *              //_sname:[
 *                  name:["like","%ja%"],
 *                  "or",
 *                  nickname:["like","%ja%"],
 *              ],
 *          }
 *     }
 *     
 *     返回数据：
 *     {
 *          code:0,
 *          msg:"",
 *          data:{
 *              status:true/false,//删除成功，返回true，失败返回false
 *              affected_rows:2,//删除文章的个数
 *          }
 *     }
 *   
 *   ------------------------------------------------------
 *   
 *     例子：修改帮助中心文章
 *     请求地址：helpcontent/update
 *     请求方式：post
 *     请求参数:
 *     {
 *          where:{
 *              id:12,
 *              //id:["in",[1,2,3]],
 *              //create_time:["between",['2019-12-12 12:12:12','2019-12-13 12:12:12']],
 *              //id:[">",100],
 *              //title:["like","%登陆%"],
 *          },
 *          data:{
 *              title:"修改后的标题"
 *          }
 *     }
 *     
 *     返回数据：
 *     {
 *          code:0,
 *          msg:"",
 *          data:{
 *              status:true/false,//删除成功，返回true，失败返回false
 *              affected_rows:2,//删除文章的个数
 *          }
 *     }
 *   
 *   ------------------------------------------------------
 *   
 *     例子：获取帮助中心文章
 *     请求地址：helpcontent/lists
 *     请求方式：post
 *     请求参数:
 *     {
 *          where:{
 *              id:12,
 *              //id:["in",[1,2,3]],
 *              //create_time:["between",['2019-12-12 12:12:12','2019-12-13 12:12:12']],
 *              //id:[">",100],
 *              //title:["like","%登陆%"],
 *          },
 *          attr:"title,content",//需要显示的对象属性，可以为字符串，也可以是数组
 *          need_total:true/false,//是否需要统计总量
 *          offset:0,//偏移量
 *          page:1,//分页
 *          page_size:10,//分页大小：默认10
 *          order:"id desc",//排序，默认id 倒序，规则为：字段+空格+“desc/asc”
 *          
 *     }
 *     
 *     返回数据：
 *     {
 *          code:0,
 *          msg:"",
 *          data:{
 *              lists:[
 *                  {
 *                      title:"如何登陆",
 *                      content:"如何登陆。。。"
 *                  }
 *              ],
 *              total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
 *              total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
 *          }
 *     }
 * 
 *   ------------------------------------------------------
 *   
 *     例子：禁用/启用帮助中心文章
 *     请求地址：helpContent/changeStatus
 *     请求方式：post
 *     请求参数:
 *     {
 *          where:{
 *              id:12,
 *              //id:["in",[1,2,3]],
 *          },
 *          status: 0, // 状态 1正常 0禁用
 *     }
 *      
 *     返回数据：
 *     {
 *          code:0,
 *          msg:"",
 *          data:{
 *              status:true/false,//成功，返回true，失败返回false
 *              affected_rows:1,//
 *          }
 *     }
 * 
 * @module_doc_end
 */
class BaseController extends _AdminController {

    /**
     * @action_doc_start
     * @action_index:authnum
     * @action_name:获取图片验证码base64
     * @action_description:
     * 原则上同一会话只允许同一时间段1个图像验证码，因此不用区分是用于登陆还是注册的图形验证码
     * 返回值：
     * {
     *      code:0,
     *      msg:'',
     *      data:{
     *          image:"data:image/png;base64,xxxxxx"//图形验证码base64字符串
     *      }
     * }
     * @action_doc_end
     */
    public function actionAuthnum() {
        $authnum = new iAuthnum();
        $image = $authnum->create(true);
        iSession::set(array("authnum" => $authnum->randnum));
        return $this->success(array("image" => $image));
    }

    /**
     * @action_doc_start
     * @action_index:permissionLists
     * @action_name:获取当前管理员拥有的权限列表
     * @action_description:
     * 需登录,用于登陆后获取用户权限或权限修改后刷新权限
     * 返回值：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          permission_lists:[//数组或者*，*表示全部
     *              "admin/lists",
     *              "admin/update"
     *          ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionPermissionLists() {

        if (iSession::get("id") > 0) {
            if ((bool) iSession::get("is_admin", 0)) {
                $ret = array(
                    "user_permission_lists" => "*"
                );
            } else {
                $group_ids = iSession::get("group_ids", "");
                $group_ids = preg_replace("/[^,0-9]/", ",", $group_ids);
                $where = array(
                    "id" => array(
                        "in",
                        explode(",", trim($group_ids, ","))
                    ),
                    "status" => 1
                );

                $ret_groups = $this->model("adminGroup")->_lists($where, null, 100, 1, "client_actions");
                $user_permission_lists = [];
                foreach ($ret_groups as $group) {
                    $actions = explode(",", trim($group["client_actions"], ","));
                    $user_permission_lists = array_merge($user_permission_lists, $actions);
                }
                $user_permission_lists = array_filter(array_unique($user_permission_lists));

                $ret = array(
                    "user_permission_lists" => array_values($user_permission_lists)
                );
            }
        } else {
            $ret = array(
                "user_permission_lists" => []
            );
        }

        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:adminDongjie
     * @action_name:冻结用户
     * @action_description:
     * 冻结没有登录，创建时间在7天前的用户
     * @action_doc_end
     */
    public function actionAdminDongjie() {
        $expire_time = time() - 3600 * 24 * 7;
        $this->model("Admin")->_update(["status" => 3], ["last_login_time" => 0, "create_at" => ["<=", $expire_time]]);
        return $this->success("ok");
    }

    /**
     * @action_doc_start
     * @action_index:getBankName
     * @action_name:获取银行卡名称
     * @action_description:
     * 获取银行卡名称
     * 参数：
     * - bankNo string  not null   银行卡号
     *
     * 请求示例:
     *     {
     *          bankNo:'6221506020009066385'
     *     }
     *
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           bank_name:""//银行卡名称
     *       }
     *   }
     * @action_doc_end
     */
    function actionGetBankName() {

        $bankNo = (string) $this->input('post.bankNo');

        $checkBank = new CheckBank();
        $rs = $checkBank->checkBankCard($bankNo);
        if (false == $rs)
            return $this->error(3, '银行卡格式不正确');

        $validateBank = $checkBank->validateBankNo($bankNo);
        if (false == $validateBank)
            return $this->error(3, '银行卡格式不正确');

        if (!empty($validateBank) && false == $validateBank['validated'])
            return $this->error(3, '银行卡格式不正确');

        return $this->success(['bank_name' => $validateBank['bankName']]);
    }

    /**
     * 自动化生成数据模型
     * 显示：
     * "the base model of table {$table_name} created success.<br/>"
     * "the base model of table {$table_name} created success.<br/>"
     */
    public function actionAutoModel() {
        if (!DEBUG) {
            return "不允许的哟，小坏蛋";
        }
        $model = new iModel();
        $tables = $model->_query("show table status;");

        $ret = [];
        foreach ($tables as $v) {
            $table_name = $v["Name"];
            $object_name = ucfirst(preg_replace_callback('/(_[a-z]{1})/', function($matches) {
                        return strtoupper(ltrim($matches[0], "_"));
                    }, $v["Name"]));
            $base_model_file = APP_DIR . "/bin/model/" . $object_name . ".php";
            $data = array(
                "table_name" => $table_name,
                "object_name" => $object_name,
                "table_info" => $v,
                "fields_info" => $model->_query("show full fields from {$table_name}")
            );
            if (!is_file($base_model_file)) {//如果模型文件不存在，则
                $content = $this->display("auto_model_tpl", $data, false);
                file_put_contents($base_model_file, $content);
            } else {
                $note = $this->display("auto_model_note", $data, false);
                $content = file_get_contents($base_model_file);
                $replace_count = 0;
                $content2 = preg_replace("/\/\*\*[\s]*# 模型解释 start：[\S\s]*模型解释 end：[\s]*\*[\/]+/", $note, $content, 1, $replace_count);
                if ($replace_count === 0) {//如果模型文件中没有模型描述内容则插入
                    $content2 = preg_replace("/namespace Model;/", "namespace Model;\r\n" . $note, $content, 1);
                }
                file_put_contents($base_model_file, $content2);
            }
            $ret[] = "the base model of table {$table_name} created success.<br/>";
        }

        return $this->display("auto_model", $ret, false);
    }

    /**
     * 
     * 获取API文档
     * 将以网页的形式展示该服务下的接口文档
     */
    public function actionDoc() {
        if (!DEBUG) {
            return "不允许的哟，小坏蛋";
        }
        //获取模型信息
        $model_dir = APP_DIR . "/bin/model";
        $files_model = scandir($model_dir);
        $model_info = array();
        $no_need_explane_files_arr = array(".", "..", "_Empty.php");
        foreach ($files_model as $file) {
            if (!in_array($file, $no_need_explane_files_arr)) {
                $model_content = file_get_contents($model_dir . "/" . $file);
                $model_index = ucfirst(substr($file, 0, -4));

                $pattern_model_name = "/模型名[:：] ([\S]+)/";
                $model_name = preg_match($pattern_model_name, $model_content, $matches_model_name) ? $matches_model_name[1] : $model_index;

                $pattern_model_description = "/模型解释 start：([\s\S]*)模型解释 end：/U";
                $model_description = preg_match($pattern_model_description, $model_content, $matches_model_description) ? $matches_model_description[1] : "";

                //模型信息
                $model_info[$model_index] = array(
                    "model_index" => $model_index,
                    "model_name" => $model_name,
                    "model_description" => trim(preg_replace("/[\r\n][ ]*\*/", "\r\n", $model_description))
                );
            }
        }

        $files_controller = scandir(__DIR__);
        $doc = array();
        foreach ($files_controller as $file) {
            if (!in_array($file, $no_need_explane_files_arr)) {
                $content = file_get_contents(__DIR__ . "/" . $file);
                $module_index = lcfirst(substr($file, 0, -14));
                $pattern_module_name = "/@module_name[:：]([\S]+)/";
                $module_name = preg_match($pattern_module_name, $content, $matches_module_name) ? $matches_module_name[1] : $module_index;

                $pattern_module_model = "/@module_model[:：]([\S]+)/";
                $module_model = preg_match($pattern_module_model, $content, $matches_module_model) ? $matches_module_model[1] : "";

                $pattern_module_description = "/@module_description[:：]([\s\S]+)@module_doc_end/U";
                $module_description = preg_match($pattern_module_description, $content, $matches_module_description) ? $matches_module_description[1] : "";

                $module_model_info = isset($model_info[$module_model]) ? $model_info[$module_model] : null;
                $doc[$module_index] = array(
                    "module_index" => $module_index,
                    "module_name" => $module_name,
                    "module_description" => trim(preg_replace("/[\r\n][ ]*\*/", "\r\n", $module_description)),
                    "module_model_info" => $module_model_info
                );

                $actions = array();

                $pattern_actions = "/@action_doc_start[\s\S]*?@action_doc_end/";
                if (preg_match_all($pattern_actions, $content, $matches_actions)) {
                    $matches_actions = $matches_actions[0];
                    foreach ($matches_actions as $actions_str) {
                        $action_index = lcfirst(preg_match("/@action_index[:：]([\S]+)/", $actions_str, $matches_action_index) ? $matches_action_index[1] : "");
                        $action_name = preg_match("/@action_name[:：]([\S]+)/", $actions_str, $matches_action_name) ? $matches_action_name[1] : $action_index;
                        $action_description = preg_match("/@action_description[:：]([\s\S]+)@action_doc_end/U", $actions_str, $matches_action_description) ? $matches_action_description[1] : "";
                        if (empty($action_index)) {
                            continue;
                        }

                        $actions[$action_index] = array(
                            "action_index" => $action_index,
                            "action_name" => $action_name,
                            "action_description" => preg_replace("/[\r\n][ ]*\*/", "\r\n", $action_description),
                        );
                    }
                }

                $doc[$module_index]["actions"] = $actions;
            }
        }

        $docbase = $doc["base"];
        unset($doc["base"]);
        $newdoc = array(
            "base" => $docbase
        );
        $newdoc = array_merge($newdoc, $doc);

        $data = array(
            "doc" => $newdoc
        );

        return $this->display(null, $data);
    }

}
