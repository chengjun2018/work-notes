<?php

/**
 * @module_doc_start
 * @module_name:公告管理
 * @module_type:Notice
 * @module_description:
 * @module_doc_end
 */
class NoticeController extends _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'Notice';


    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加公告
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          title:"标题",
     *          content:"内容",
     *          sort: 1,  // 排序
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入公告的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = (array) $this->input("post.data");
//        $data = array_map('trim', $data);
//        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
            return $this->error(3, '请输入标题');

        if (isset($data['sort']) && !preg_match('/^\d+$/', $data['sort']))
            return $this->error(3, '排序仅支持数字');

        if (!isset($data['content']) || preg_match('/^\s*$/', $data['content']))
            return $this->error(3, '请输入公告内容');

        return parent::actionInsert();
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改公告
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          title:"标题",
     *          content:"内容",
     *          sort: 1,  // 排序
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除公告的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $where = (array) $this->input('post.where');
        $data = (array) $this->input('post.data');
        if (empty($data) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

//        $data = array_map('trim', $data);
//        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
            return $this->error(3, '请输入标题');

        if (isset($data['sort']) && !preg_match('/^\d+$/', $data['sort']))
            return $this->error(3, '排序仅支持数字');

        if (!isset($data['content']) || preg_match('/^\s*$/', $data['content']))
            return $this->error(3, '请输入公告内容');

        return parent::actionUpdate();
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:公告列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数都不是必须参数
     *          title: ['like', '%标题%'],//  标题模糊查询
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
              "lists": [
                {
                    "id": "4",
                    "title": "标题4",
                    "content": "内容4",
                    "status": "1", // 1启用 0禁用
                    "sort": "1",
                    "create_at": "1553751299",
                    "update_at": "1554471798"
                }
              ],
               total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
               total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
            }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $this->POST['order'] = 'sort desc,id desc';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');
        return parent::actionDelete();
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用（未启用）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      },
     *      data:{
     *          status: 1, // 状态 1启用 0停用
     *      }
     *
     *
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        return $this->error(1, '未启用');
        $status = (int) $this->input('post.data.status');
        if ($status < -1 || $status > 2)
            return $this->error(3, '参数有误');
        return parent::actionChangeStatus();
    }



    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 1, //ID ，必须
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "detail": {
                    "id": "1",
                    "title": "标题123",
                    "content": "内容123",
                    "status": "1",
                    "sort": "1",
                    "create_at": "1553751299",
                    "update_at": "1554471719"
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');
        return parent::actionDetail();
    }


}
