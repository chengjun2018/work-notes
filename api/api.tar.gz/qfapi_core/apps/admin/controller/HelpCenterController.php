<?php

/**
 * @module_doc_start
 * @module_name:帮助中心模块
 * @module_model:HelpCenter
 * @module_description:
 * @module_doc_end
 */
class HelpCenterController extends  _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'HelpCenter';
    protected $uploadPath = UPLOAD_PATH . '/help_center/';

    // 先拿到要删除的图片 再对比，过滤不用删除的，最后删除图片
    private function setTodoImg()
    {
        $detail = $this->actionDetail();
        $detail = $detail['data']['detail'];

        $todoImg = [];
        // H5
        if ($detail['type'] == 2) {
            $todoImg = explode(',', $detail['image_paths']);
        }
        // PC
        if ($detail['type'] == 1) {
            $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
            preg_match_all($preg, $detail['content'], $todoImg);
            if (!empty($todoImg) && isset($todoImg[1])) {
                $todoImg = $todoImg[1];
            }
        }
        if ($todoImg) {
            $todoImg = array_map('strtolower', $todoImg);
        }
        $this->toDelImg= $todoImg;
        return $detail;
    }

    private function filterTodoImg($filterImgs)
    {
        if (empty($this->toDelImg)) {
            return true;
        }
        if (is_string($filterImgs)) { // 内容提取图片地址
            $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
            preg_match_all($preg, $filterImgs, $filterImgs);
            if (!empty($filterImgs) && isset($filterImgs[1])) {
                $filterImgs = $filterImgs[1];
            }
        }
        if (empty($filterImgs)) {
            return true;
        }
        foreach ($filterImgs as $val) {
            $pos = array_search(strtolower($val), $this->toDelImg);
            if ($pos !== false) {
                unset($this->toDelImg[$pos]);
            }
        }
    }

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加帮助中心文章
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          title:"如何注册",
     *          content:"就是这样注册",
     *          image_paths:[ // 兼容移动端 上传的图片路径数组
     *                  "http://abc.com/help/xxx.JPG",
     *                  "http://abc.com/help/123.JPG",
     *          ],
     *          type: 1, // 类型 1 PC 2 H5
     *          mark: "1a", // 标识
     *          status: 1,  // 状态 1正常 0禁用 -1删除
     *          sort: 1  // 排序
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入文章的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = $this->input("post.data");
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
            return $this->error(3, '请输入标题');

        if (!isset($data['type']) || ($data['type'] != 1 && $data['type'] != 2))
            return $this->error(3, '请选择类型');

        if (!isset($data['mark']) || preg_match('/^\s*$/', $data['mark']))
            return $this->error(3, '请输入标识');

        if (!isset($data['mark']) || preg_match('/[^\d\w]/', $data['mark']))
            return $this->error(3, '标识仅支持字母和数字');

        if (!isset($data['sort']) || !preg_match($this->preg['int'], $data['sort']))
            return $this->error(3, '排序仅支持数字');

        if (!isset($data['content']) || preg_match('/^\s*$/', $data['content']))
            return $this->error(3, '请输入内容详情');

        if ($data['type'] == 2) {
            if (isset($data['image_paths']) && !empty($data['image_paths'])) {
                if (count($data['image_paths']) > 20) {
                    return $this->error(3, '最多可以添加20张图片');
                }
//                foreach ($data['image_paths'] as $path) {
//                    if (!preg_match($this->preg['img_path'], strtolower($path)))
//                        return $this->error(3, '图片路径格式有误');
//                }
                $data['image_paths'] = implode(',', $data['image_paths']);
            }
        } else {
            $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
            $imgs = [];
            preg_match_all($preg, $data['content'], $imgs);
            if (isset($imgs[1]) && count($imgs[1]) > 20) {
                return $this->error(3, '最多可以添加20张图片');
            }
            $data['image_paths'] = '';
        }

        // 判断是否已经添加超过10个
        $helpModel = $this->model($this->moduleModel);
        if ($helpModel->_count('id', 'status = 1') >= 10 ) {
            return $this->error(1, '信息列表数量已达上限，无法添加');
        }

        $this->POST['data'] = $data;

//        if (!isset($data['status']) || ($data['status'] != 0 && $data['status'] != 1))
//            return $this->error(3, '状态请设置启用或禁用');

        return parent::actionInsert();
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:帮助文章修改
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data: {
     *          title: '标题不能为空', // 帮助文章标题字段： 字符串 不能为空
     *          content: '内容不能为空',  // 帮助文章内容字段： 字符串 不能为空 富文本，图片传递url
     *          image_paths:[ // 兼容移动端 上传的图片路径数组
     *                  "http://abc.com/help/xxx.JPG",
     *                  "http://abc.com/help/123.JPG",
     *          ],
     *          sort: 1 // 排序
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除文章的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误，查询条件不正确');

        $data = $this->input("post.data");
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
            return $this->error(3, '请输入标题');

        if (!isset($data['sort']) || !preg_match($this->preg['int'], $data['sort']))
            return $this->error(3, '排序仅支持数字');

        if (!isset($data['content']) || preg_match('/^\s*$/', $data['content']))
            return $this->error(3, '请输入内容详情');

        if ($data['type'] == 2) {
            if (isset($data['image_paths']) && !empty($data['image_paths'])) {
                if (count($data['image_paths']) > 20) {
                    return $this->error(3, '最多可以添加20张图片');
                }
//                foreach ($data['image_paths'] as $path) {
//                    if (!preg_match($this->preg['img_path'], strtolower($path)))
//                        return $this->error(3, '图片路径格式有误');
//                }
                $data['image_paths'] = implode(',', $data['image_paths']);
            } else {
                $data['image_paths'] = '';
            }
        } else {
            $preg = '/<img.*?src="(.*?)[\'|\"].*?>/is';
            $imgs = [];
            preg_match_all($preg, $data['content'], $imgs);
            if (isset($imgs[1]) && count($imgs[1]) > 20) {
                return $this->error(3, '最多可以添加20张图片');
            }
            $data['image_paths'] = '';
        }

        $this->POST['data'] = [
            'title' => $data['title'],
            'sort' => $data['sort'],
            'content' => $data['content'],
            'image_paths' => $data['image_paths'],
        ];

        $this->setTodoImg();

        $result = parent::actionUpdate();

        if ($result['data']['affected_rows']) {
            // H5
            if ($data['type'] == 2 && $data['image_paths']) {
                $this->filterTodoImg($data['image_paths']);
            }
            // PC
            if ($data['type'] == 1) {
                $this->filterTodoImg($data['content']);
            }

            $this->delImg();
        }

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:帮助文章列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数非必须
     *          //id:["in",[1,2,3]],
     *          //create_at:["between",['2019-12-12 12:12:12','2019-12-13 12:12:12']],
     *          //id:[">",100],
     *          //title:["like","%登陆%"],
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          list:[
     *              {
     *                  id: 7,
     *                  title: "文章标题",
     *                  mark: "abc", // 标识
     *                  type: "1", //类型 1PC 2H5
     *                  status: "1", //状态 1正常 0禁用 -1删除
     *                  sort: 1, // 排序
     *                  create_at: "添加时间",
     *                  update_at: "修改时间",
     *              }
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $this->POST['attr'] = 'id, title, mark, type, status, sort, create_at, update_at';
        $this->POST['order'] = 'sort desc,id desc';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:帮助文章详情
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 1, //ID ，必须
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
            "detail": {
                "id": "2",
                "title": "不能为空",
                "content": "内容不能为空",
                "image_paths": "http://abc.com/help/xxx.JPG,http://abc.com/help/123.JPG", // 兼容移动端图片 以英文,分割
                "mark": "",
                "type": "0",
                "sort": "1",
                "status": "1",
                "create_at": "1553858781",
                "update_at": "1553863685"
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');
        return parent::actionDetail();
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:删除帮助文章
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除文章的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');

        $this->setTodoImg();

        $result =  parent::actionDelete();

        if ($result['data']['affected_rows']) {
            $this->delImg();
        }


        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用帮助文章
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      },
     *      data:{
     *          status: 0, // 状态 1正常 0禁用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        $status = (int) $this->input("post.data.status");
        if ($status < -1 || $status > 1)
            return $this->error(3, '参数有误');
        return parent::actionChangeStatus();
    }

    /**
     * @action_doc_start
     * @action_index:UplodImg
     * @action_name:上传图片 仅支持多文件上传参数
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *          FILE文件1,
     *          FILE文件1,
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          img_path: [ // 上传成功的文件路径 一个上传失败，同时上传的其他图片全部删除
                            "/help_center/图片1.PNG",
                            "/help_center/图片2.PNG"
                            ],
     *      }
     * }
     * @action_doc_end
     */
    public function actionUplodImg()
    {
        return $this->uplodImg(1, 'insertImg', $this->request->files);
    }


    /**
     * @action_doc_start
     * @action_index:ueditor
     * @action_name:上传图片针对百度富文本编辑器
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *           [], // 文件信息
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "status": true,
                "img_path": [
                        "http://oss.rainbow.com/help_center/20190404104514f47f1.71437606.PNG"
                    ],
                "error": [
                        null
                    ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionUeditor()
    {
        return parent::actionUeditor();
    }

}
