<?php

/**
 * @module_doc_start
 * @module_name:站内信管理
 * @module_type:Letter
 * @module_description:
 * @module_doc_end
 */
class LetterController extends _AdminController
{

    public $needCheckAccess = true;

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加站内信
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          title:"标题",
     *          content:"内容",
     *          type: 1,  // 发送类型：1全员发送 2指定会员 3指定分层
     *          inc_hmd: 1,  // 是否包含黑名单用户，1包含 2不包含
     *          to_user: '0 || morris,jaky || 1,2',  // 如果类型为1全员发送，则传0；类型为2：则拼接用户名；类型为3：则拼接分层id
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入公告的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = (array)$this->input("post.data");
        $data = array_map('trim', $data);
        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
            return $this->error(3, '请输入标题');

        if (isset($data['type']) && !preg_match('/^\d+$/', $data['type']))
            return $this->error(3, '类型仅支持数字');

        if (isset($data['inc_hmd']) && !preg_match('/^\d+$/', $data['inc_hmd']))
            return $this->error(3, '包含黑名单仅支持数字');

        if (!isset($data['content']) || preg_match('/^\s*$/', $data['content']))
            return $this->error(3, '请输入内容');

        if ($data['type'] > 3 || $data['type'] <= 0)
            return $this->error(3, '无效的类型');

        if (intval($data['inc_hmd']) > 2 || intval($data['inc_hmd']) <= 0)
            return $this->error(3, '无效的包含黑名单');

        $uList = [];

        if ($data['type'] == 2) {
            //给指定会员发送站内信
            $toArr = explode(',', $data['to_user']);
            $unArr = array_filter(array_unique($toArr));
            if (empty($unArr))
                return $this->error(3, '请指定接收的用户');
            
            $repArr = array_diff_assoc($toArr, $unArr);
            if (!empty($repArr))
                return $this->error(3, implode(',', $repArr) . " 用户重复");

            if (count($unArr) > 200)
                return $this->error(3, "发送对象人数已达上限");

            //检测指定用户是否存在
            $undUser = '';
            $uMod = $this->model('user', 2);
            foreach ($unArr as $v) {
                $info = $uMod->_detail(['username' => $v], null, 'id');
                if (empty($info)) {
                    $undUser = $v;
                    break;
                } else {
                    $uList[] = $info['id'];
                }
            }

            if ($undUser)
                return $this->error(1, "未找到{$undUser}账号");


        } elseif ($data['type'] == 3) {
            //给指定分层发送站内信
            $toArr = explode(',', $data['to_user']);
            $unArr = array_filter(array_unique($toArr));
            if (empty($unArr))
                return $this->error(3, '请指定分层的用户');

            $repArr = array_diff_assoc($toArr, $unArr);
            if (!empty($repArr))
                return $this->error(3, implode(',', $repArr) . " 分层用户重复");

//            if (count($unArr) > 200)
//                return $this->error(3, "超出指定分层限制");

            //检测指定分层是否存在
            $undUser = '';
            $uMod = $this->model('user_tier');
            foreach ($unArr as $v) {
                $info = $uMod->_detail(['id' => $v], null, 'id');
                if (empty($info)) {
                    $undUser = $v;
                    break;
                } else {
                    $uList[] = $info['id'];
                }
            }

            if ($undUser)
                return $this->error(1, "未找到{$undUser}分层");
        }

        $sendData = [
            'adminid' => iSession::get('id'),
            'adminname' => iSession::get('name'),
            'title' => $data['title'],
            'content' => $data['content'],
            'create_at' => time()
        ];

        $letSend = $this->model('letter_send');
        $letRec = $this->model('letter_receive');

        //开启事务操作
        iModel::_begin();
        $ret = $letSend->_insert($sendData);
        if (false == $ret) {
            iModel::_back();
            return $this->error(1, "站内信发送失败，请稍后重试。");
        }

        $bIns = [];

        if ($data['type'] == 1) {
            $bIns[] = [
                'type' => $data['type'],
                'to_user' => 0,
                'letterid' => $ret
            ];
        } else {
            foreach ($uList as $k => $v) {
                $bIns[] = [
                    'type' => $data['type'],
                    'to_user' => $data['type'] == 1 ? 0 : $v,
                    'letterid' => $ret
                ];
            }
        }


        $rs = $letRec->_batch_insert($bIns, false);
        if (false == $rs) {
            //操作失败，回滚事务
            iModel::_back();
            return $this->error(1, "操作失败，请稍后重试。");
        } else {
            $rs = iModel::_end();
            if ($rs == false)
                return $this->error(1, "操作异常，请稍后重试。");
        }

        return $this->success();
    }


    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:站内信列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数都不是必须参数
     *          username: '',//用户名精确查找
     *          create_at:["between",['2019-04-01 12:12:12','2019-04-13 12:12:12']],
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          lists:[
     *              {
     *                  id:'1',//ID
     *                  adminname:"morris",//发件管理员
     *                  title:"标题",//信件标题
     *                  content:"内容",//信件内容
     *                  create_at:"1542712345",//发送时间
     *                  receive:[
     *                      {
     *                          type: //类型：1全部会员 2指定会员 3指定分层
     *                          name: //会员|分层名称
     *                      }
     *                  ],
     *              }
     *          ],
     *          need_tier_lists:[//分层数据
     *              {
     *                  id:'1',//分层ID
     *                  name:"一级会员",//分层名称
     *              }
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $offset = (int)$this->input("post.offset", 0);
        $page_size = (int)$this->input("post.page_size", 10);
        $page = (int)$this->input("post.page", 1);
        $where = (array)$this->input("post.where", array());
        $need_total = (int)$this->input("post.need_total", 0);

        $order = "id desc";

        if ($page_size === 0) {
            $page_size = 10;
        }
        $page_size = max(array(1, $page_size));
        $page = max(array(1, $page));

        $offset += ($page - 1) * $page_size;
        $limit = "$offset,$page_size";

        $letSend = $this->model('LetterSend');
        $letRec = $this->model('letter_receive');
        $ret = array("lists" => [], "page" => $page, "page_size" => $page_size, "offset" => $offset);

        $uMod = $this->model('user', 2);
        //筛选用户名条件
        if ($where['username']) {

            //获取用户信息
            $uInfo = $uMod->_detail(['username' => $where['username']], null, 'id,create_at,tierid');
            if (empty($uInfo))
                return $this->success(['lists' => [], 'total_num' => 0, 'total_page' => 0]);

            //1.根据用户注册时间获取所有收到的信件
            $tWhere = ['type' => 1, 'create_at' => [">", $uInfo['create_at']]];
            $allLet = $letRec->_lists($tWhere, 'id desc', null, null, 'letterid');

            //2.然后根据指定会员在筛选信件
            $tWhere = ['type' => 2, 'to_user' => $uInfo['id']];
            $allUsrLet = $letRec->_lists($tWhere, 'id desc', null, null, 'letterid');

            //3.在根据会员分层筛选信件
            if ($uInfo['tierid']) {
                $tWhere = ['type' => 3, 'to_user' => $uInfo['tierid'], 'create_at' => [">", $uInfo['create_at']]];
                $allTieLet = $letRec->_lists($tWhere, 'id desc', null, null, 'letterid');
            }

            //合并所有信件id
            $letIds = [];
            foreach ($allLet as $k => $v) {
                $letIds[] = $v['letterid'];
            }
            foreach ($allUsrLet as $k => $v) {
                $letIds[] = $v['letterid'];
            }
            foreach ($allTieLet as $k => $v) {
                $letIds[] = $v['letterid'];
            }

            //如果信件为则返回
            if (empty($letIds))
                return $this->success(['lists' => [], 'total_num' => 0, 'total_page' => 0]);

            //分页处理
//            $total_num = count($letIds);
//            if ($total_num > $page_size)
//                $letIds = array_slice($letIds, (($page - 1) * $page_size), $page_size);

            unset($where['username']);
            $where['id'] = ['in', $letIds];

        }

        if (!empty($where['create_at'])) {
            if (count($where['create_at']) == 1)
                unset($where['create_at']);
        }
        //获取索引列表
        $list = $letSend->getLists($where, $order, $limit);
        if (!empty($where['create_at'])) {
            $where['create_at'][1][0] = strtotime($where['create_at'][1][0]);
            $where['create_at'][1][1] = strtotime($where['create_at'][1][1]);
        }
        //获取总记录数
        $total_num = $letSend->_count($where, null);

        //取出指定会员和指定分层的ID
        $user = [];
        $tier = [];
        foreach ($list as $k => $v) {
            foreach ($v['_letter_receive'] as $ks => $vs) {
                if ($vs['type'] == 2) $user[] = $vs['to_user'];
                elseif ($vs['type'] == 3) $tier[] = $vs['to_user'];
            }
        }

        $userList = [];
        $tierList = [];

        //根据指定会员ID取得对应的会员账号
        if (!empty($user)) {
            $user = array_unique($user);
            $where = ['id' => ['in', $user]];
            $uList = $uMod->_lists($where, null, null, null, 'username,id');

            foreach ($uList as $k => $v) {
                if (empty($userList[$v['id']]))
                    $userList[$v['id']] = $v['username'];
            }
        }

        //根据指定分层ID取得对应分层名称
        if (!empty($tier)) {
            $tMod = $this->model('user_tier');
            $tier = array_unique($tier);
            $where = ['id' => ['in', $tier]];
            $tList = $tMod->_lists($where, null, null, null, 'name,id');

            foreach ($tList as $k => $v) {
                if (empty($tierList[$v['id']]))
                    $tierList[$v['id']] = $v['name'];
            }
        }

        //最后在重组列表数据
        $ret_lists = [];
        foreach ($list as $k => $v) {
            $ret_lists[$k] = [
                'id' => $v['id'],
                'adminname' => $v['adminname'],
                'title' => $v['title'],
                'content' => $v['content'],
                'create_at' => $v['create_at']
            ];
            foreach ($v['_letter_receive'] as $ks => $vs) {
                $ret_lists[$k]['receive'][$ks]['type'] = $vs['type'];
                if ($vs['type'] == 1) {
                    $ret_lists[$k]['receive'][$ks]['name'] = '全部会员';
                } elseif ($vs['type'] == 2) {
                    $ret_lists[$k]['receive'][$ks]['name'] = $userList[$vs['to_user']];
                } elseif ($vs['type'] == 3) {
                    $ret_lists[$k]['receive'][$ks]['name'] = $tierList[$vs['to_user']];
                }
            }
        }

        $ret["lists"] = $ret_lists;
        $ret["need_tier_lists"] = $tierList;
        if ($need_total) {
            $ret["total_num"] = (int)$total_num;
            $ret["total_page"] = ceil($total_num / $page_size);
        }
        unset($userList, $tierList, $list, $ret_lists);
        return $this->success($ret);

    }
    
    public function actionGetTierLists(){
        $tierMod = $this->model('user_tier');
        $tierList = $tierMod->_lists(['status' => 1], null, null, 60, 'id,name');
        return $this->success(['lists'=>$tierList]);
    }


}
