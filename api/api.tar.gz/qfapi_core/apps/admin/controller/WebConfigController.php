<?php

/**
 * @module_doc_start
 * @module_name:网站管理
 * @module_type:WebConfig
 * @module_description:
 * @module_doc_end
 */
class WebConfigController extends _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'WebConfig';
    private $_Model = null;

    public function __construct()
    {
        parent::__construct();
        $this->_Model = $this->model($this->moduleModel);
    }

    private function getConfig($key)
    {
        return $this->_Model->_detail(['key' => $key], 0);
    }

    private function setConfig($key, $value, $isAdd)
    {
        $ret = ["status" =>  FALSE];
        if ($isAdd) { // 添加
            $rs = $this->_Model->_insert(['key' => $key, 'value' => $value]);
        } else { // 修改
            $rs = $this->_Model->_update(['value' => $value], ['key' => $key]);
        }

        $ret['status'] = $rs === false ? FALSE : TRUE;

        return $this->success($ret);
    }

    private function footerList()
    {
        $page_size = (int) $this->input("post.page_size", 10);
        $page = (int) $this->input("post.page", 1);
        $need_total = (int) $this->input("post.need_total", 0);
        $where = (array) $this->input("post.where", array());

        $valueData = $this->getConfig('footer');

        $value = json_decode($valueData['value'], true);
        $value = array_values($value);

        $list = $temp1 = [];
        if (!empty($where)
            && (isset($where['title']) && is_array($where['title']) && count($where['title']) == 2 &&  strtolower($where['title'][0]) == 'like' && !empty($where['title'][1]))) {
            $title = trim($where['title'][1], '%');
            foreach ($value as $v) {
                if ($title && strpos($v['title'], $title) !== false) {
                    $temp1[] = $v;
                }
            }
        } else {
            $temp1 = array_values($value);
        }
        unset($valueData, $value);

        if (!empty($where) && isset($where['type']) && ($where['type'] == 1 || $where['type'] == 2)) {
            foreach ($temp1 as $k => $v) {
                if ($v['type'] == $where['type']) {
                    $list[] = $v;
                }
            }
        } else {
            $list = array_values($temp1);
        }
        unset($temp1);
        $total = count($list);

        // 处理排序
        array_multisort(array_column($list,'sort'), SORT_DESC, array_column($list,'create_at'),SORT_DESC, $list);

        // 处理分页
        $page_size = $page_size < 10 ? 10 : $page_size;
        $page = $page < 1 ? 1 : $page;
        $offset = ($page - 1) * $page_size;
        $list = array_slice($list, $offset, $page_size);

        $ret = array("lists" => $list);

        if ($need_total) {
            $ret["total_num"] = $total;
            $ret["total_page"] = ceil($total  / $page_size);
        }

        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:insert/footer
     * @action_name:添加（insert/footer页脚信息）
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          title:"标题",
     *          type: 1, // 类型 1PC 2 H5
     *          sort: 1,  // 排序
     *          url: '', //跳转url 如果不填则前台不跳转
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入公告的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert($config)
    {
        $data = (array) $this->input("post.data");
        $data = array_map('trim', $data);
//        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        $valueData = $this->getConfig($config);

        $isAdd = $valueData ? false : true;

        switch ($config) {
            case 'footer':
                if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
                    return $this->error(3, '请输入标题');

                if (!isset($data['type']) || ($data['type'] != 1 && $data['type'] != 2))
                    return $this->error(3, '请选择类型');

                if (isset($data['sort']) && !preg_match('/^\d+$/', $data['sort']))
                    return $this->error(3, '排序仅支持数字');

                if (!isset($data['sort']))
                    $data['sort'] = 0;

                if (!isset($data['url']))
                    $data['url'] = '';
                elseif (!preg_match( $this->preg['url'], $data['url']))
                    return $this->error(3, '请输入正确的链接地址');


                $_data =  [
                    'title' => $data['title'],
                    'type' => $data['type'],
                    'sort' => $data['sort'],
                    'url' => $data['url'],
                    'create_at' => time(),
                    'id' => uniqid()
                ];

                $value = [];
                if (empty($valueData) || empty($valueData['value'])) {
                    $value[] = $_data;
                } else {
                    $value = json_decode($valueData['value'], true);
                    $value[] = $_data;
                }
                $value = json_encode($value);
            break;
        }

        return $this->setConfig($config, $value, $isAdd);
    }

    /**
     * @action_doc_start
     * @action_index:update/footer
     * @action_name:修改（update/footer页脚信息）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: '5ca96c8ba96f0',
     *      },
     *      data: {
     *          title:"标题",
     *          type: 1, // 类型 1PC 2 H5
     *          sort: 1,  // 排序
     *          url: '', //跳转url 如果不填则前台不跳转
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除公告的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate($config)
    {
        $where = (array) $this->input('post.where');
        $data = (array) $this->input('post.data');
        if (empty($where) || empty($data))
            return $this->error(3, '参数错误');

        $data = (array) $this->input("post.data");
        $data = array_map('trim', $data);
////        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        $valueData = $this->getConfig($config);

        if (empty($valueData)) {
            return $this->error(3, '数据不存在');
        }

        switch ($config) {
            case 'footer':
                if (empty($where['id']))
                    return $this->error(3, '参数错误');

                if (!isset($data['title']) || preg_match('/^\s*$/', $data['title']))
                    return $this->error(3, '请输入标题');

                if (!isset($data['type']) || ($data['type'] != 1 && $data['type'] != 2))
                    return $this->error(3, '请选择类型');

                if (isset($data['sort']) && !preg_match('/^\d+$/', $data['sort']))
                    return $this->error(3, '排序仅支持数字');

                if (!isset($data['sort']))
                    $data['sort'] = 0;

                if (!isset($data['url']))
                    $data['url'] = '';
                elseif (!preg_match( $this->preg['url'], $data['url']))
                    return $this->error(3, '请输入正确的链接地址');


                $value = json_decode($valueData['value'], true);

                foreach ($value as $k => $v) {
                    if ($v['id'] == $where['id']) {
                        $value[$k] = [
                            'title' => $data['title'],
                            'type' => $data['type'],
                            'sort' => $data['sort'],
                            'url' => $data['url'],
                            'create_at' => $v['create_at'],
                            'id' => $v['id']
                        ];
                        break;
                    }
                }
                $value = json_encode(array_values($value));

                break;
        }

        return $this->setConfig($config, $value, false);
    }

    /**
     * @action_doc_start
     * @action_index:lists/footer
     * @action_name:列表（lists/footer页脚信息）
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数都不是必须参数
     *          title: ['like', '%标题%'],//  标题模糊查询
     *          type:  1,//  1PC 2H5
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
              "lists": [
                {
                    "title": "标题",
                    "type": "1",
                    "sort": "1",
                    "url": "https://www.baidu.com",
                    "create_at": 1554622578,
                    "id": "5ca9a872bbd1f"
                },
              ],
               total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
               total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
            }
     * }
     * @action_doc_end
     */
    public function actionLists($config)
    {
        switch ($config) {
            case 'footer' :
                return $this->footerList();
            break;
        }
    }

    /**
     * @action_doc_start
     * @action_index:delete/footer
     * @action_name:删除（delete/footer页脚信息）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: '5ca970cc17e19', // 禁止批量删除
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//删除成功，返回true，失败返回false
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete($config)
    {
        $where = (array) $this->input('post.where');
        if (empty($where)) {
            return $this->error(3, '参数错误');
        }

        $valueData = $this->getConfig($config);

        switch ($config) {
            case 'footer':
                if (empty($where['id']))
                    return $this->error(3, '参数错误');
                $value = json_decode($valueData['value'], true);
                foreach ($value as $key => $val) {
                    if ($val['id'] == $where['id']) {
                        unset($value[$key]);
                        break;
                    }
                }
                $value = json_encode(array_values($value));
            break;
        }
        return $this->setConfig($config, $value, false);
    }


    /**
     * @action_doc_start
     * @action_index:detail/footer
     * @action_name:详情（detail/footer页脚信息）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: '5ca970cc17e19', //ID ，必须
     *      }
     * }
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "detail": {
                    "title": "标题",
                    "type": "1",
                    "sort": "1",
                    "url": "https://www.baidu.com",
                    "create_at": 1554622578,
                    "id": "5ca9a872bbd1f"
                    }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail($config)
    {
        $where = $this->input("post.where");
        if (!isset($where['id']))
            return $this->error(3, '参数有误');

        $valueData = $this->getConfig('footer');

        $value = json_decode($valueData['value']);

        $ret_detail = null;
        foreach ($value as $val) {
            if ($val->id == $where['id']) {
                $ret_detail = $val;
            }
        }

        $ret = [
            "detail" => empty($ret_detail) ? null : $ret_detail
        ];
        return $this->success($ret);
    }


    /**
     * @action_doc_start
     * @action_index:voiceGet
     * @action_name:当前平台声音设置
     * @action_description:
     * 请求参数:
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data: {
                "lists": [
                    {
                        "id": "2",
                        "key": "in_money",
                        "value": "",
                        "status": "1",
                        "create_at": "1556262261",
                        "update_at": "1556262261"
                    },
                    {
                    "id": "3",
                    "key": "out_money",
                    "value": "",
                    "status": "1",
                    "create_at": "1556262261",
                    "update_at": "1556262261"
                    }
                ],
                "voice": [
                    {
                    "value": "",
                    "label": "无提示音"
                    },
                    {
                    "value": "/oss/voice/male.mp3",
                    "label": "入款提示音-男"
                    },
                    {
                    "value": "/oss/voice/female.mp3",
                    "label": "入款提示音-女"
                    }
                ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionVoiceGet()
    {
        $voiceData = [
            [
                'value' => '',
                'label' => '无提示音',
            ],
            [
                'value' => '/oss/voice/male.mp3',
                'label' => '入款提示音-男',
            ],
            [
                'value' => '/oss/voice/female.mp3',
                'label' => '入款提示音-女',
            ]
        ];
        $model = $this->model($this->moduleModel);
        $lists = $model->_lists(['key' => ['in', 'in_money,out_money']]);
        if (empty($lists)) {
            $model->_insert([ 'key' => 'in_money', 'value' => '']);
            $model->_insert([ 'key' => 'out_money', 'value' => '']);
            return $this->actionVoiceGet();
        }
        return $this->success(['lists' => $lists, 'voice' => $voiceData]);
    }


    /**
     * @action_doc_start
     * @action_index:voiceSet
     * @action_name:平台声音设置
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 2,
     *          key: 'in_money', // 入款提示音
     *         //  key: 'out_money', // 出款提示音
     *      },
     *      data: {
     *          value: '/oss/voice/male.mp3'
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                status:true/false,//更新成功，返回true，失败返回false
                affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionVoiceSet()
    {
        return parent::actionUpdate();
    }



}
