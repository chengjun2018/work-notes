<?php

/**
 * @module_doc_start
 * @module_name:后台会员管理
 * @module_type:User
 * @module_description:
 * @module_doc_end
 */
class UserController extends _AdminController
{

    public $needCheckAccess = true;
    private $userModelName = 'User';
    private $bankModelName = 'User_bank';
    private $cycleModelName = 'UserReturnBetCycle';

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加用户
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          realname:"真实姓名",
     *          username:"abc123", // 用户登录名
     *          password: 'abc123456',  // 登陆密码
     *          phone:"13200000012", // 手机号
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入文章的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = (array)$this->input("post.data");
//        $data = array_map('trim', $data);
        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        $preg = $this->preg;

        if (!isset($data['username']) || !preg_match($preg['username'], $data['username']))
            return $this->error(3, '用户名格式不正确');

        if (!isset($data['password']) || !preg_match($preg['password'], $data['password']))
            return $this->error(3, '用户密码格式不正确');

        if (!isset($data['realname']) || !preg_match($preg['chinese'], $data['realname']))
            return $this->error(3, '用户真实姓名必须是中文');

        if (mb_strlen($data['realname']) >= 15 || mb_strlen($data['realname']) < 2)
            return $this->error(3, '用户真实姓名长度不正确');

        if (strlen($data['phone']) != 11 || !preg_match($preg['mobile'], $data['phone']))
            return $this->error(3, '手机号码格式不正确');

        if (isset($data['out_password'])) {
            unset($data['out_password']);
        }

        $data['password'] = $this->password($data['password'], $data['username']);
        $data['reg_ip'] = $this->header("x-real-ip") ?: "";
        $data['reg_source'] = '后台注册';
        $userModel = $this->model($this->userModelName, 1);

        if ($userModel->_detail(['phone' => $data['phone']]))
            return $this->error(1, '手机号已存在');

        if ($userModel->_detail(['username' => $data['username']]))
            return $this->error(1, '用户名已存在');

        if (isset($data['wechat']) && !empty($data['wechat']) && $userModel->_detail(['wechat' => $data['wechat']]))
            return $this->error(1, '微信号已存在');

        if (empty($data['last_login_time'])) {
            $data['last_login_time'] = $data['sc_login_time'] = time();
            $data['last_login_ip'] = $data['sc_login_ip'] = $data['reg_ip'];
        }
        if (empty($data['tierid'])) {
            $detail = $this->model('UserTier')->_detail(['is_default' => 1], null, 'id');
            $data['tierid'] = $detail['id'];
        }

        $ret = array(
            "status" => false,
            "insert_id" => 0
        );
        if ($userModel) {
            $ret_insert = $userModel->_insert($data);
            $ret = array(
                "status" => $ret_insert === FALSE ? FALSE : TRUE,
                "insert_id" => (int)$ret_insert
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('添加失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改用户
     * @action_description:
     *
     * 如果要修改银行卡号，则需要当光标移除银行卡号输入框后则触发 base/getBankName 接口获取银行卡名称
     *
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          phone: '13200005678', // 手机号
     *          email: 'morris@irainbow7.com', //邮箱
     *          wechat: 'abc123', //微信号
     *
     *          realname: '张三', //真实姓名
     *          bankNo: '6221506020009066392', //银行卡号
     *          branch: '山顶洞支行', //开户支行名称
     *          position: '北京市/市辖区/朝阳区', //地区
     *          mast_dml: 100, //要求打码量
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//修改状态
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $where = (array)$this->input('post.where');
        $data = (array)$this->input('post.data');
        if (empty($data) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $data = (array)$this->input("post.data");
        $data = array_map('trim', $data);
        
        if (empty($data))
            return $this->error(3, '参数错误');

        $userInfo = $this->model('user')->_detail(['id' => $where['id']], null, 'username');
        if (empty($userInfo))
            return $this->error(1, '不是有效参数');

        $preg = $this->preg;

        if (!preg_match($preg['mobile'], $data['phone']))
            return $this->error(3, '手机号格式不正确');

        if (!preg_match($preg['email'], $data['email']))
            return $this->error(3, '邮箱格式不正确');

        if (!preg_match($preg['wechat'], $data['wechat']))
            return $this->error(3, '微信号格式不正确');

        if (!preg_match($preg['realname'], $data['realname']))
            return $this->error(3, '真实姓名格式不正确');

        $checkBank = new CheckBank();
        $validateBank = $checkBank->validateBankNo($data['bankNo']);
        if (false == $validateBank)
            return $this->error(3, '银行卡格式不正确');

        if (!empty($validateBank) && false == $validateBank['validated'])
            return $this->error(3, '银行卡格式不正确');

        $data['bank_name'] = $validateBank['bankName'];

        if (!$this->validate($preg['bank_branch'], 'post.data.branch', $data['branch']))
            return $this->error(3, '开户支行格式不正确');

        $position = array_filter(explode('/', $data['position']));
        if (empty($position)) return $this->error(3, '银行所属地格式不正确');
        if (!empty($position) && count($position) != 3) return $this->error(3, '银行所属地格式不正确');

        if ($data['mast_dml'] < 0)
            return $this->error(3, '打码量格式不正确');

        $userModel = $this->model($this->userModelName, 1);

        $uInfo = $userModel->_detail(['email' => $data['email'], 'or', 'phone' => $data['phone'], 'or', 'wechat' => $data['wechat']]);
        if (!empty($uInfo)) {
            if ($uInfo['id'] != $where['id']) {
                if ($uInfo['email'] == $data['email'])
                    return $this->error(1, '邮箱已被注册');

                if ($uInfo['phone'] == $data['phone'])
                    return $this->error(1, '手机号已被注册');

                if ($uInfo['wechat'] == $data['wechat'])
                    return $this->error(1, '微信号已存在');
            }
        }


        $bInfo = $this->model('user_bank')->_detail(['cardno' => $data['bankNo']]);
        if (!empty($bInfo)) {
            if ($bInfo['userid'] != $where['id'])
                return $this->error(1, '银行卡号已被绑定');
        }

        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );
        if ($userModel) {

            $bank = [
                'cardno' => $data['bankNo'],
                'bank_name' => $data['bank_name'],
                'bank' => $validateBank['bank'],
                'branch' => $data['branch'],
                'province' => $position[0],
                'city' => $position[1],
                'county' => $position[2],
                'type' => 1,
            ];
            unset($data['bank'], $data['bankNo'], $data['bank_name'], $data['branch'], $data['position']);

            if (isset($data['out_password'])) {
                unset($data['out_password']);
            }

            iModel::_begin();
            $ret_update = $userModel->_update($data, $where);
            if (false == $ret_update) {
                iModel::_back();
                return $this->error(1, "操作失败，请稍后重试。");
            } else {
                $bankMod = $this->model('user_bank');
                $info = $bankMod->_detail(['userid' => $where['id']]);
                if (empty($info)) {
                    $bank['userid'] = $where['id'];
                    $rs = $bankMod->_insert($bank);
                } else {
                    $rs = $bankMod->_update($bank, ['userid' => $where['id']]);
                }
                if (false == $rs) {
                    iModel::_back();
                    return $this->error(1, "操作失败，请稍后重试。");
                }
                $rs = iModel::_end();
                if (false == $rs)
                    return $this->error(1, "操作异常，请稍后重试。");
            }

            $ret = array(
                "status" => true,
                "affected_rows" => (int)$ret_update
            );
        }
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:用户列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数都不是必须参数
     * // 大于> 大于等于>= 小于< 小于等于<= 等于直接写值 例：等于： dml: 100  大于等于： dml: ['>=', 100]
     *          username: 'meak1',//  用户名 相等查询
     *          username: ['like', '%meak%'],//  用户名 模糊查询
     *          realname: ['like', '%meak%'],//  会员姓名 模糊查询
     *          realname: '真名',//  会员姓名
     *          agent_name: 'abc123', // 代理商
     *          reg_ip: '192.168.1.11', // 注册IP
     *          ablebalance: ['>', 100], // 余额大于100
     *          dml: ['>', 100], // 打码量大于100 暂未启用
     *          win: ['>', 100], // 打码量大于100 暂未启用
     *          win: ['<', 100], // 打码量小于100 暂未启用
     *          score: ['>', 100], // 积分大于100 暂未启用
     *          score: ['<', 100], // 积分小于100 暂未启用
     *          tiername: '层级名称', //  会员层级
     *          phone: '13200000001',// 电话
     *          cardno: '6217211107001880725',// 银行卡号
     *          bank_name: '中国工商银行',// 银行名称
     *          status: 1, //  状态 1正常 2锁定 -1删除
     *          create_at:["between",['2019-01-12 12:12:12','2019-12-13 12:12:12']], // 注册时间查询
     *          last_login_time:["between",['2019-01-12 12:12:12','2019-12-13 12:12:12']], // 最后登陆时间查询
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      order: 'last_login_time desc, id desc', // 排序 默认last_login_time desc, id desc 
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          "lists": [
     *              {
     *                  "id": ,//ID
     *                  "username": ,//用户名
     *                  "realname": "",//真实姓名
     *                  "reg_ip": ,//注册IP
     *                  "status": "1",//是否冻结 2冻结 1正常
     *                  "create_at": ,//注册时间
     *                  "last_login_ip": ,//最后登录IP
     *                  "last_login_time": ,//最后登录时间
     *                  "remark": "",//备注
     *                  "tiername": "一级会员",//会员层级
     *                  "agent_name": ,//代理商
     *                  "is_enable": ,//是否禁用 1禁用 0启用
     *                  "phone": ,//手机号
     *                  "wechat": ,//微信号
     *                  "email": ,//邮箱
     *                  "mast_dml": ,//要求打码量
     *                  "tag": ,//用户类型：1真人 2电子 3棋牌 4体育 5彩票
     *                  "bank_info": [//银行卡信息
     *                      'bank_name'://银行卡名称
     *                      'cardno'://银行卡号
     *                      'province'://省
     *                      'city'://市
     *                      'county'://县
     *                      'branch'://支行名称
     *                  ]
     *                  "_fund": [
     *                      'ablebalance' : //可用余额
     *                      'frozenbalance' : //冻结余额
     *                      'balance' : //余额
     *                      'score' : //积分
     *                      'handsel' : //彩金
     *                      'dml' : //打码量
     *                  ]
     *              }，
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     *  }
     * @action_doc_end
     */
    public function actionLists()
    {
        $result = $this->_setWhere();
        if ($result !== true) {
            return $result;
        }

        $fields = 'id, username, realname, tierid, agent_id, tag, reg_device, reg_ip, phone, wechat, email, mast_dml, 
                            reg_source, status, create_at, last_login_ip, last_login_time, remark, is_enable';

        $page_size = (int)$this->input("post.page_size", 10);
        $page = (int)$this->input("post.page", 1);
        $order = (string)$this->input("post.order", "last_login_time desc, id desc");
        $need_total = (int)$this->input("post.need_total", 0);
        $where = $this->input('post.where');

        $page = $page < 1 ? 1 : $page;
        $page_size = $page_size < 10 ? 10 : $page_size;
        $limit = ($page - 1) * $page_size . ',' . $page_size;

        $userModel = $this->model($this->userModelName, 1);
        $list = $userModel->_lists($where, $order, $limit, null, $fields);

        $tier = $this->Model('user_tier');
        $tierList = $tier->_lists(['status' => 1], null, null, null, 'id, name');

        $tierData = [];
        foreach ($tierList as $val) {
            $tierData[$val['id']]['id'] = $val['id'];
            $tierData[$val['id']]['name'] = $val['name'];
        }

        if ($list) {
            $agent_ids = [];
            $uids = [];
            foreach ($list as $iK => $iV) {
                $agent_ids[] = $iV['agent_id'];
                $uids[] = $iV['id'];
                $list[$iK]['tiername'] = $tierData[$iV['tierid']]['name'];
            }
            $agent = $this->model('agent')->_lists(['id' => ['in', array_unique($agent_ids)]], null, null, null, 'id,username');
            $aTemp = [];
            foreach ($agent as $value) {
                $aTemp[$value['id']] = $value['username'];
            }

            $banks = $this->model('user_bank')->_lists(['userid' => ['in', array_unique($uids)]], null, null, null, 'userid,bank_name,cardno,bank,province,city,county,branch');
            $bTemp = [];
            foreach ($banks as $value) {
                $bTemp[$value['userid']] = $value;
            }
            foreach ($list as $iK => $iV) {
                $list[$iK]['agent_name'] = $aTemp[$iV['agent_id']];
                $list[$iK]['bank_info'] = !empty($bTemp[$iV['id']]) ? $bTemp[$iV['id']] : [];
            }
        }

        $ret = ["lists" => $list, 'tier' => array_values($tierData)];

        if ($need_total) {
            if (is_array($where) && isset($where['create_at']) && $where['create_at'][0] == 'between' && count($where['create_at'][1]) == 2) {
                $where['create_at'][1][0] = strtotime($where['create_at'][1][0]);
                $where['create_at'][1][1] = strtotime($where['create_at'][1][1]);
            }
            $total_num = $userModel->_count($where, null);
            $ret["total_num"] = (int)$total_num;
            $ret["total_page"] = ceil($total_num / $page_size);
        }

        unset($list, $aTemp, $bTemp, $banks, $agent, $tierList, $tierData);
        return $this->success($ret);
    }

    private function _setWhere($isExport = false)
    {
        $where = (array)$this->input('post.where');
        $where = array_filter($where);

        $_where = [];
        if ((isset($where['cardno']) && !empty($where['cardno'])) || (isset($where['bank_name']) && !empty($where['bank_name']))) {
            $_bankWhere = [];
            if ($where['cardno']) {
                $_bankWhere['cardno'] = $where['cardno'];
            }
            if ($where['bank_name']) {
                $_bankWhere['bank_name'] = $where['bank_name'];
            }
            $bankData = $this->model('UserBank')->_lists($_bankWhere);
            if ($bankData) {
                $ids = array_column($bankData, 'userid');
                $_where['id'] = count($ids) == 1 ? $ids[0] : ['in', $ids];
            } else {
                return $this->success(['lists' => [], "total_num" => 0, "total_page" => 0]);
            }
        }
        if (isset($where['agent_name']) && !empty($where['agent_name'])) {
            $agentModel = $this->model('agent');
            $agent = $agentModel->_lists(['username' => $where['agent_name']], null, null, null, 'id');
            if (empty($agent)) {
                return $this->success(['lists' => [], "total_num" => 0, "total_page" => 0]);
            }
            $_where['agent_id'] = ['in', array_column($agent, 'id')];
        }

        $fundWhere = [];
        if (isset($where['ablebalance']) && !empty($where['ablebalance'])) {
            $fundWhere['ablebalance'] = $where['ablebalance'];
        }
        if (isset($where['dml']) && !empty($where['dml'])) {
            $fundWhere['dml'] = $where['dml'];
        }
        if (isset($where['score']) && !empty($where['score'])) {
            $fundWhere['score'] = $where['score'];
        }
        if (!empty($fundWhere)) {
            $agentModel = $this->model('userFund');
            $agent = $agentModel->_lists($fundWhere);
            if (empty($agent)) {
                return $this->success(['lists' => [], "total_num" => 0, "total_page" => 0]);
            }
            $ids = array_column($agent, 'id');
            $_where['id'] = ['in', $ids];
        }

        // TODO 输赢大小筛选
        if (isset($where['win']) && count($where['win']) == 2) {

        }

        if (isset($where['phone']) && !empty($where['phone'])) {
            $_where['phone'] = $where['phone'];
        }
        if (isset($where['tiername']) && !empty($where['tiername'])) {
            $ids = $this->model('UserTier')->_lists(['name' => $where['tiername']], null, null, null, 'id');
            if (empty($ids)) {
                return $this->success(['lists' => [], "total_num" => 0, "total_page" => 0]);
            }
            $_where['tierid'] = count($ids) == 1 ? $ids[0]['id'] : ['in', array_column($ids, 'id')];
        }
        if (isset($where['username']) && !empty($where['username'])) {
            $_where['username'] = $where['username'];
        }
        if (isset($where['realname']) && !empty($where['realname'])) {
            $_where['realname'] = $where['realname'];
        }
        if (isset($where['reg_ip']) && !empty($where['reg_ip'])) {
            $_where['reg_ip'] = $where['reg_ip'];
        }
        if (isset($where['login_ip']) && !empty($where['login_ip'])) {
            $_where['last_login_ip'] = $_where['login_ip'];
        }
        if (isset($where['realname']) && !empty($where['realname'])) {
            $_where['realname'] = $where['realname'];
        }
        if (isset($where['balance']) && count($where['balance']) == 2 && count($where['balance'][1]) == 2 && $where['balance'][1][1] > 0) {
            $_where['balance'] = $where['balance'];
        }
        if (isset($where['create_at']) && !empty($where['create_at'])
            && count($where['create_at']) == 2 && $where['create_at'][0] = 'between' && count($where['create_at'][1]) == 2) {
            $_where['create_at'] = [
                'between',
                [
                    $where['create_at'][1][0],
                    $where['create_at'][1][1],
                ]
            ];
        }
        if (isset($where['last_login_time']) && !empty($where['last_login_time'])
            && count($where['last_login_time']) == 2 && $where['last_login_time'][0] = 'between' && count($where['last_login_time'][1]) == 2) {
            $_where['last_login_time'] = [
                'between',
                [
                    strtotime($where['last_login_time'][1][0]),
                    strtotime($where['last_login_time'][1][1]),
                ]
            ];
        }

        if ($isExport) { // TODO 导出时间限制

        }

        if ( isset($where['abled'])) { //启用
            $_where['is_enable'] = 0;
        } else if (isset($where['disabled'])) { //禁用
            $_where['is_enable'] = 1;
        }

        $this->POST['where'] = $_where;

        unset($_where, $where);
        return true;
    }

    /**
     * @action_doc_start
     * @action_index:updPassword
     * @action_name:修改用户密码
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 6, // 用户ID
     *      },
     *      data: {
     *          password1: '123qwe', //新密码
     *          password2: '123qwe', //确认密码
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//修改状态
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdPassword()
    {
        $where = (array)$this->input('post.where');
        $data = (array)$this->input('post.data');
        if (empty($data) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $data = (array)$this->input("post.data");
        $data = array_map('trim', $data);
        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        $userInfo = $this->model('user')->_detail(['id' => $where['id']], null, 'username,password');
        if (empty($userInfo))
            return $this->error(1, '不是有效参数');

        if (!$this->validate($this->preg['password'], 'post.data.password1', $data['password1']))
            return $this->error(3, '密码格式不正确');

        if (!$this->validate($this->preg['password'], 'post.data.password2', $data['password2']))
            return $this->error(3, '确认密码格式不正确');

        if ($data['password1'] != $data['password2'])
            return $this->error(3, '两次密码不一样');

        $password = $this->password($data['password1'], $userInfo['username']);

        if ($password == $userInfo['password']) {
            return $this->error(3, '不能和原密码一致');
        }

        $rs = $this->model('user')->_update(['password' => $password], ['id' => $where['id']]);
        if (false == $rs)
            return $this->error(1, '修改异常，请稍后重试。');

        return $this->success(['status' => true, 'affected_rows' => (int)$rs]);
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:冻结/解冻
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          status: 1, // 状态 2冻结 1正常
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        if (!$this->checkWhereIdInt($ids)) {
            return $this->error(3, "状态修改，必须提供准确的id");
        }
        $where = $this->input("post.where");
        $data['status'] = (int)$this->input('post.data.status');
        if ($data['status'] <= 0 || $data['status'] > 2)
            return $this->error(3, '参数错误');

        $Model = $this->model('user');
        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );

        if ($Model) {
            $ret_update = $Model->_update($data, $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int)$ret_update
            );
        }

        //如果冻结该用户，则将前台用户踢下线。
        if ($data[['status']] == 2)
            iSession::logoutUser($where['id'], 0, 1);
        return $ret['status'] ? $this->success($ret) : $this->error('操作失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:changeEnable
     * @action_name:禁用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          enable: 1, // 状态 1禁用 0启用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeEnable()
    {
        if (!$this->checkWhereIdInt($ids)) {
            return $this->error(3, "状态修改，必须提供准确的id");
        }
        $where = $this->input("post.where");
        $data['is_enable'] = (int)$this->input("post.data.enable");

        if ($data['is_enable'] < 0 || $data['is_enable'] > 1)
            return $this->error(3, '参数错误');

        $Model = $this->model('user');
        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );

        if ($Model) {
            $ret_update = $Model->_update($data, $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int)$ret_update
            );
        }

        //如果禁用该用户，则将前台用户踢下线。
        if ($data[['is_enable']] == 1)
            iSession::logoutUser($where['id'], 0, 1);
        return $ret['status'] ? $this->success($ret) : $this->error('操作失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:remark
     * @action_name:备注操作
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          tag:1,//用户类型：1真人 2电子 3棋牌 4体育 5彩票
     *          remark: '备注备注', // 状态 1禁用 0启用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionRemark()
    {
        $where = $this->input("post.where");
        $data = (array)$this->input('post.data');
        if (empty($data) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        if ($data['tag'] <= 0 || $data['tag'] > 5)
            return $this->error(3, '用户类型错误');

        if (!trim($data['remark']))
            return $this->error(3, '请填写备注信息');

        if (mb_strlen($data['remark'], 'utf8') > 200)
            return $this->error(3, '备注超出了字符限制');

        $Model = $this->model('user');
        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );

        if ($Model) {
            $ret_update = $Model->_update($data, $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int)$ret_update
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('备注失败，请重试！');
    }


    /**
     * @action_doc_start
     * @action_index:updUserTier
     * @action_name:修改会员层级
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12, // 单个修改
     *          id:['in', [1, 2, 3]] //批量修改
     *      },
     *      data:{
     *          tierid:1,//层级id
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdUserTier()
    {
        $where = $this->input("post.where");
        $data = (array)$this->input('post.data');
        if (empty($data) || empty($where['id']))
            return $this->error(3, '参数错误');

        if ($data['tierid'] <= 0)
            return $this->error(3, '层级id错误');

        $tInfo = $this->model('user_tier')->_detail(['id' => $data['tierid']], null, 'id,status');
        if (empty($tInfo) || $tInfo['status'] == -1)
            return $this->error(1, '未找到层级信息');

        if (!$tInfo['status'])
            return $this->error(1, '层级已被禁用');

        $Model = $this->model('user');
        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );

        if ($Model) {
            $ret_update = $Model->_update($data, $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int)$ret_update
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('修改失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:clearDml
     * @action_name:清空打码量
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          id:['in', [1, 2, 3]],
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionClearDml()
    {
        $where = $this->input("post.where");
        if (empty($where['id']))
            return $this->error(3, '参数错误');

        $Model = $this->model('User');
        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );

        if ($Model) {
            $ret_update = $Model->_update(['mast_dml' => 0], $where);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int)$ret_update
            );
        }
        return $ret['status'] ? $this->success($ret) : $this->error('清空失败，请重试！');
    }


    /**
     * @action_doc_start
     * @action_index:fundflow
     * @action_name:会员资金流水（需求待确认）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          userid: 6, // ID参数必须 ，  以下其他参数都不是必须参数
     *          create_at:["between",['2019-01-12 12:12:12','2019-12-13 12:12:12']],
     *          type: 1,//  账变类型 1 2 3 4 101 102 103... 默认0 全部
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      order: 'id desc', // 排序 默认id desc ID倒序
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     * "lists": [
     * {
     * "id": "19",
     * "userid": "6",
     * "type": "1",  // 账变类型 （需求待确认）
     * "before_ablebalance": "0.0000",     // 变动前可用余额
     * "before_frozenbalance": "0.0000",   // 变动前冻结余额
     * "before_balance": "0.0000",         // 变动前余额
     * "after_ablebalance": "100.0000",    // 剩余可用余额
     * "after_frozenbalance": "0.0000",    // 剩余冻结余额
     * "after_balance": "100.0000",        // 剩余余额
     * "money": "100.0000",            // 变动金额
     * "create_at": "1553680962",   // 变动时间
     * "update_at": "0"
     * },
     * ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionFundflow()
    {
        $where = $this->input("post.where");
        if (!isset($where['userid']) || intval($where['userid']) <= 0)
            return $this->error(3, '参数有误');

        $this->moduleModel = 'user_fundflow';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:xmflow
     * @action_name:会员洗码流水（需求待确认）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          userid: 6, // ID参数必须 ，  以下其他参数都不是必须参数
     *          create_at:["between",['2019-01-12 12:12:12','2019-12-13 12:12:12']],
     *          type: 1,//  账变类型 1 2 3 4 101 102 103... 默认0 全部
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      order: 'id desc', // 排序 默认id desc ID倒序
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     * "lists": [
     * {
     * "id": "20",
     * "userid": "6",
     * "type": "1", // 账变类型 （需求待确认）
     * "before_dml": "6.0000", // 变动前打码量
     * "after_dml": "7.0000", // 变动后打码量
     * "dml": "1.0000",        // 变动打码量
     * "create_at": "1553680962", // 变动时间戳
     * "update_at": "0"
     * },
     * ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionXmflow()
    {
        $where = $this->input("post.where");
        if (!isset($where['userid']) || intval($where['userid']) <= 0)
            return $this->error(3, '参数有误');

        $this->moduleModel = 'user_dmlflow';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:scoreflow
     * @action_name:会员积分流水（需求待确认）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          userid: 6, // ID参数必须 ，  以下其他参数都不是必须参数
     *          create_at:["between",['2019-01-12 12:12:12','2019-12-13 12:12:12']],
     *          type: 1,//  账变类型 1 2 3 4 101 102 103... 默认0 全部
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      order: 'id desc', // 排序 默认id desc ID倒序
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     * "lists": [
     * {
     * "id": "1",
     * "userid": "6",
     * "type": "1", // 积分类型 （需求待确认）
     * "before_score": "0", // 变动前积分
     * "after_score": "1", // 变动后积分
     * "score": "1",  // 变动积分
     * "create_at": "1553680962",
     * "update_at": "0"
     * }
     * ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionScoreflow()
    {
        $where = $this->input("post.where");
        if (!isset($where['userid']) || intval($where['userid']) <= 0)
            return $this->error(3, '参数有误');

        $this->moduleModel = 'user_scoreflow';
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:changeScore
     * @action_name:更改会员积分（需求待确认）
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          userid: 6, // ID参数必须
     *      },
     *      data: {
     *          score: 10 , // 变化的积分
     *          type: '+' , // 账变类型 + -
     *          remark: '待确认需求' , // 备注 待确认需求
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeScore()
    {
        $where = $this->input("post.where");
        if (!isset($where['userid']) || intval($where['userid']) <= 0)
            return $this->error(3, '参数有误1');

        $data = $this->input("post.data");
        $_data = [];

        if (empty($data)) {
            return $this->error(3, '参数有误2');
        }

        if (!isset($data['score']) || intval($data['score']) <= 0) {
            return $this->error(3, '参数有误， 请填写大于零的积分');
        }

        if (!isset($data['type']) || ($data['type'] != '+' && $data['type'] != '-')) {
            return $this->error(3, '参数有误， 请选择变动类型');
        }

        $fundModel = $this->model('user_fund');

        $this->getLock('add_user_score', 3);
        $score = $fundModel->_detail(['userid' => $where['userid']], 0, 'id, score');

        $_data['userid'] = $where['userid'];
        $_data['remark'] = $data['remark'];
        $_data['score'] = intval($data['score']);
        $_data['type'] = $data['type'] == '+' ? 1 : 2; // TODO 类型定义
        $_data['before_score'] = $score['score'];
        $_data['after_score'] = $data['type'] == '+' ? ($score['score'] + $_data['score']) : ($score['score'] - $_data['score']);

        $ret = array(
            "status" => false,
            "affected_rows" => 0
        );

        // 更新数据
        $scoreModel = $this->model('user_scoreflow');
        if ($scoreModel->_insert($_data)) {
            $_data = ['score' => '`score` ' . ($data['type'] == '+' ? '+' : '-') . $_data['score']];
            $ret_update = $fundModel->_update($_data, $score['id']);
            $ret = array(
                "status" => $ret_update === FALSE ? FALSE : TRUE,
                "affected_rows" => (int)$ret_update
            );
        }
        $this->unLock('add_user_score');

        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:export
     * @action_name:导出，60s内同一条件查询不再生成新数据（1先请求此接口生成导出文件返回path参数,2域名拼接path参数,3再次请求进行下载）
     * @action_description:
     * 请求参数:
     * {
     *      where:{  // 以下参数都不是必须参数
     *          create_at:["between",['2019-01-12 12:12:12','2019-12-13 12:12:12']],
     *          cardno: '123456789',//  银行卡号
     *          bankuser: '阿萨德',//  持卡人
     *          phone: '13200000001',//  电话
     *          username: 'meak1',//  用户名 相等查询
     *          username: ['like', '%meak%'],//  用户名 模糊查询
     *          reg_source: '后台注册', //  后台注册
     *          tierid: 1, //  会员层级
     *          agent_name: 'meak1', //  代理商
     *          status: 1, //  状态 1正常 2锁定 -1删除
     *          history: 1, //  是否历史用户  1是 2否 无效 需求待定
     *      },
     *      order: 'id desc', // 排序 默认id desc ID倒序
     * }
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          "path": "/temp/2019033120564056069.xlsx" // 生成的文件路径 需要重新请求下载
     *      }
     * }
     * @action_doc_end
     */
    public function actionExport()
    {
        $this->_setWhere(true);
        $redisKey = 'export_user_lists';
        $redisVal = json_encode($this->input('post.where'));

        $outputPath = APP_DIR . '/temp/';
        $outputFile = $outputPath . md5($redisVal) . '.xlsx';
        if (!is_dir($outputPath)) {
            mkdir($outputPath);
        }

        if (iCache::redis("get", $redisKey) == $redisVal) {
            return $this->success(['path' => str_replace(APP_DIR, '', $outputFile)]);
        }
        iCache::redis("set", $redisKey, $redisVal, 60);

        include_once APP_DIR . '/../../libs_third/PHPExcel/PHPExcel.php';
        include_once APP_DIR . '/../../libs_third/PHPExcel/PHPExcel/Writer/Excel2007.php';

        $fields = 'id, username, realname, agent_name, tierid, create_at, reg_ip, last_login_ip, last_login_time, remark';
        $user = $this->Model('user');
        $list = $user->_lists($this->input('post.where'), null, null, null, $fields);
        unset($user);

        if (empty($list)) {
            iCache::redis("del", $redisKey);
            return $this->error(1, '暂无数据');
        }

        $tier = $this->Model('user_tier');
        $tierList = $tier->_lists(['status' => 1], null, null, null, 'id, name');

        $tierData = [];
        foreach ($tierList as $val) {
            $tierData[$val['id']] = $val['name'];
        }

        $exportData = [];
        foreach ($list as $iK => $iV) {
            $temp = [
                'id' => $iV['id'],
                'username' => $iV['username'],
                'realname' => $iV['realname'],
                'agent_name' => $iV['agent_name'],
                'tiername' => isset($tierData[$iV['tierid']]) ? $tierData[$iV['tierid']] : '',
                'balance' => $iV['_fund']['balance'],
                'dml' => $iV['_fund']['dml'],
                'win' => '', //TODO
                'score' => $iV['_fund']['score'],
                'create_data' => date('Y-m-d H:i:s', $iV['create_at']) . "\n" . $iV['reg_ip'],
                'last_login' => $iV['last_login_time'] ? date('Y-m-d H:i:s', $iV['last_login_time']) : '',
                'remark' => $iV['remark'],
            ];
//            $exportData[] = array_values($temp);
            $exportData[] = $temp;
        }
        unset($list);

        //横向单元格标识
        $cellKey = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH', 'AI', 'AJ', 'AK', 'AL', 'AM', 'AN', 'AO', 'AP', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AV', 'AW', 'AX', 'AY', 'AZ'];
        // 表头占几行
        $topNumber = 1;
        $objPHPExcel = new PHPExcel(); //创建一个实例
        // 设置当前的sheet
//        $objPHPExcel->setActiveSheetIndex(0);
        // 设置sheet的标题
//        $objPHPExcel->getActiveSheet()->setTitle('会员列表');
//        // 设置字号
        $objPHPExcel->getActiveSheet()->getDefaultStyle()->getFont()->setSize(10);

        $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(30);//所有单元格（行）默认高度
        $objPHPExcel->getActiveSheet()->getDefaultColumnDimension()->setWidth(20);//所有单元格（列）默认宽度
        $objPHPExcel->getDefaultStyle()->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // 所有单元格水平居中
        $objPHPExcel->getDefaultStyle()->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER); // 所有单元格默认垂直居中

        $cellName = ['ID', '会员账号', '会员姓名', '代理商', '会员层级', '钱包余额', '打码量', '输赢', '积分', '注册时间/IP', '最后登录时间', '备注'];
        for ($i = 0; $i <= count($cellName); $i++) {
//        foreach ($cellName as $k => $v) {
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellKey[$i] . $topNumber, empty($cellName[$i]) ? '' : $cellName[$i]);//设置表头数据
            $objPHPExcel->getActiveSheet()->freezePane($cellKey[$i] . ($topNumber + 1)); //冻结窗口
            $objPHPExcel->getActiveSheet()->getStyle($cellKey[$i] . $topNumber)->getFont()->setBold(true);//设置是否加粗
            $objPHPExcel->getActiveSheet()->getStyle($cellKey[$i] . $topNumber)->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);//垂直居中
//            if(mb_strlen($v) > 20) { //大于0表示需要设置宽度
//                $objPHPExcel->getActiveSheet()->getColumnDimension($cellKey[$k])->setWidth(mb_strlen($v));//设置列宽度
//            }
        }

        //处理数据
        foreach ($exportData as $iK => $iV) {
//            foreach ($cellName as $jK => $jV) {
//                $objPHPExcel->getActiveSheet()->setCellValue($cellKey[$jK] . ( $iK + 1 + $topNumber), $iV[$jK]);
//            }
            $objPHPExcel->getActiveSheet()->setCellValue('A' . ($iK + 1 + $topNumber), $iV['id']);
            $objPHPExcel->getActiveSheet()->setCellValue('B' . ($iK + 1 + $topNumber), $iV['username']);
            $objPHPExcel->getActiveSheet()->setCellValue('C' . ($iK + 1 + $topNumber), $iV['realname']);
            $objPHPExcel->getActiveSheet()->setCellValue('D' . ($iK + 1 + $topNumber), $iV['agent_name']);
            $objPHPExcel->getActiveSheet()->setCellValue('E' . ($iK + 1 + $topNumber), $iV['tiername']);
            $objPHPExcel->getActiveSheet()->setCellValue('F' . ($iK + 1 + $topNumber), $iV['balance']);
            $objPHPExcel->getActiveSheet()->setCellValue('G' . ($iK + 1 + $topNumber), $iV['dml']);
            $objPHPExcel->getActiveSheet()->setCellValue('H' . ($iK + 1 + $topNumber), $iV['win']);
            $objPHPExcel->getActiveSheet()->setCellValue('I' . ($iK + 1 + $topNumber), $iV['score']);
            $objPHPExcel->getActiveSheet()->setCellValue('J' . ($iK + 1 + $topNumber), $iV['create_data']);
            $objPHPExcel->getActiveSheet()->getStyle('J' . ($iK + 1 + $topNumber))->getAlignment()->setWrapText(true);
            $objPHPExcel->getActiveSheet()->setCellValue('K' . ($iK + 1 + $topNumber), $iV['last_login']);
            $objPHPExcel->getActiveSheet()->setCellValue('L' . ($iK + 1 + $topNumber), $iV['remark']);
        }

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'excel2007');  //excel5为xls格式，excel2007为xlsx格式
        $objWriter->save($outputFile);

        return $this->success(['path' => str_replace(APP_DIR, '', $outputFile)]);
    }


    /**
     * @action_doc_start
     * @action_index:onlineUserList
     * @action_name:获取在线用户列表
     * @action_description:
     * 请求参数:
     * {
     *      type: 1, //在线会员类型：1.PC 2.APP 3.H5 4.CLIENT
     *      page: 1, //当前页
     *      page_size: 10, //记录数
     * }
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
     *                  id://id
     *                  realname://真实姓名
     *                  username://用户名
     *                  device://设备类型
     *                  reg_ip://注册ip
     *                  last_login_time://本次登录时间
     *                  last_login_ip://本次登录ip
     *                  user_active_time://最后活跃时间
     *                  domain://登录域名
     *                  sc_login_ip://上次登录ip
     *                  sc_login_time://上次登录时间
     *                  create_at://注册时间
     *                  onlinetime://在线时长
     *              }
     *          ],
     *          'total_num'://总记录数
     *          'total_page'://总页数
     *       }
     *   }
     * @action_doc_end
     */
    public function actionOnlineUserList()
    {

        //在线会员类型：1.PC 2.APP 3.H5 4.CLIENT
        $type = (int)$this->input('post.type', 1);
        $page = (int)$this->input('post.page', 1);
        $pagesize = (int)$this->input('post.page_size', 10);

        $tArr = [
            1 => 'pc',
            2 => 'app',
            3 => 'h5',
            4 => 'client',
        ];

        if (!in_array($type, [1, 2, 3, 4]))
            return $this->error(3, '类型不正确');

        $start = time();
        $end = strtotime("-1 hour");
        $count = iSession::redis('zCount', 'frontend_' . $tArr[$type] . '_list', $end, $start);

        $total_page = ceil($count / $pagesize);

        if ($page > $total_page)
            return $this->success(['lists' => [], 'total_num' => $count, 'total_page' => $total_page]);

        $idArr = iSession::redis("zRevRangeByScore", 'frontend_' . $tArr[$type] . '_list', $start, $end, ['limit' => [($page - 1) * $pagesize, $pagesize]]);
//        $idArr = iSession::redis("zRevRangeByScore", 'frontend_test_list', $start, $end, ['limit'=>[($page - 1)*$pagesize, $pagesize]]);
        $idArr = array_filter($idArr);
//        $count = count($idArr);
//        arsort($idArr);
//        if ($pagesize < $count)
//            $idArr = array_slice($idArr, (($page - 1) * $pagesize), $pagesize, true);
        $list = [];
//        $tokenArr = iSession::redis('mget',array_map(function($r) {
//            return 'frontend_'.$r;
//        },$idArr));

        $idList = [];
        $tokenArr = [];
        foreach ($idArr as $v) {
            $info = iSession::redis('get', 'frontend_' . $v);
            $tokenArr[] = $info;
            $idList[$v] = $info;
        }

        if (!empty($tokenArr)) {

            $tList = iSession::redis('mget', array_map(function ($r) {
                return 'accesstoken_' . $r;
            }, $tokenArr));

            if (!empty($tList)) {
                $key = ['id', 'realname', 'username', 'create_at', 'reg_ip', 'last_login_time', 'last_login_ip', 'user_active_time', 'domain', 'sc_login_ip', 'sc_login_time'];
                foreach ($tList as $k => $v) {
                    $v = json_decode($v, true);
                    if (empty($v)) continue;
                    foreach ($key as $vs) {
                        if (isset($v[$vs]))
                            $list[$k][$vs] = $v[$vs];
                    }
                    if (isset($idList[$v['id']])) {
                        $tArr = explode('||', $idList[$v['id']]);
                        $list[$k]['device'] = $tArr[0];
                    }
                    $list[$k]['onlinetime'] = $list[$k]['user_active_time'] - $list[$k]['last_login_time'];
                }
            }

        }

        return $this->success(['lists' => array_values($list), 'total_num' => $count, 'total_page' => $total_page]);

    }


    /**
     * @action_doc_start
     * @action_index:kickoutUser
     * @action_name:将在线用户踢下线
     * @action_description:
     * 请求参数:
     * {
     *      id: 1, //用户id
     * }
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *      }
     * }
     * @action_doc_end
     */
    public function actionKickoutUser()
    {
        $id = (int)$this->input('post.id', 0);
        if (!$id) return $this->error(3, '请指定用户');

        iSession::logoutUser($id, 0, 1);

        return $this->success();
    }

    private $cycleType = [
        ['cycle'=> 'cycle_1_h' , 'lable'=> '每一个小时自动返水一次，一天共24次'],
        ['cycle'=> 'cycle_2_h' , 'lable'=> '每2个小时自动返水一次，一天共12次'],
        ['cycle'=> 'cycle_3_h' , 'lable'=> '每3个小时自动返水一次，一天共8次'],
        ['cycle'=> 'cycle_4_h' , 'lable'=> '每4个小时自动返水一次，一天共6次'],
        ['cycle'=> 'cycle_6_h' , 'lable'=> '每6个小时自动返水一次，一天共4次'],
        ['cycle'=> 'cycle_8_h' , 'lable'=> '每8个小时自动返水一次，一天共3次'],
        ['cycle'=> 'cycle_12_h', 'lable' => '每12个小时自动返水一次，一天共2次'],
        ['cycle'=> 'once_0_30' , 'lable'=> '每天0点30分自动返水一次，一天共1次'],
        ['cycle'=> 'once_6_30' , 'lable'=> '每天6点30分自动返水一次，一天共1次'],
        ['cycle'=> 'once_12_30', 'lable' => '每天12点30分自动返水一次，一天共1次'],
        ['cycle'=> 'once_18_30', 'lable' => '每天18点30分自动返水一次，一天共1次'],
    ];

    /**
     * @action_doc_start
     * @action_index:setReturnCycle
     * @action_name:设置返水周期
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          'type': 1, // 返水类型 1周期 2手动
     *          'cycle': 'cycle_1_h', // 周期 type 为1时必须设置 为2时为空 ，具体数据getReturnCycle接口返回的cycle数据 下标
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//设置成功，返回true，失败返回false
     *          insert_id:12866,//新设置的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionSetReturnCycle()
    {
        $data = $this->input('post.data');

        if (empty($data) || ($data['type'] != 1 && $data['type'] != 2) || ($data['type'] == 1 && empty($data['cycle']))) {
            return $this->error(3, '参数错误');
        }

        $cycleData = array_column($this->cycleType, 'lable','cycle');
        if ($data['type'] == 1 && !isset($cycleData[$data['cycle']])) {
            return $this->error(3, '不存在的周期类型');
        }

        $this->moduleModel = $this->cycleModelName;
        return parent::actionInsert();
    }


    /**
     * @action_doc_start
     * @action_index:getReturnCycle
     * @action_name:获取返水周期
     * @action_description:
     * 请求参数:
     * {}
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
 *              "cycle": [
                    {
                    "cycle": "cycle_1_h",
                    "lable": "每一个小时自动返水一次，一天共24次"
                    }
                ],
                "current_set": { // 当前返水设置
                    "type": "1", // 1周期 2手动
                    "cycle": "cycle_1_h" // type为1时 ，请参考cycle
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionGetReturnCycle()
    {

        $model = $this->model($this->cycleModelName);

        $data = $model->_lists('', 'id desc', 1, 0, 'type,cycle');

        $current = [];
        if (!empty($data)) {
            $current = $data[0];
        }

        return $this->success(['cycle' => $this->cycleType, 'current_set' => $current]);
    }


    /**
     * @action_doc_start
     * @action_index:updateOutpwd
     * @action_name:修改用户资金密码
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 6, // 用户ID
     *      },
     *      data: {
     *          fundpwd1: '123qwe', //新密码
     *          fundpwd2: '123qwe', //确认密码
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//修改状态
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdateOutpwd()
    {
        $where = (array)$this->input('post.where');
        $data = (array)$this->input('post.data');
        if (empty($data) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $data = (array)$this->input("post.data");
        $data = array_map('trim', $data);
        $data = array_filter($data);
        if (empty($data))
            return $this->error(3, '参数错误');

        $userInfo = $this->model('user')->_detail(['id' => $where['id']], null, 'username,out_password');
        if (empty($userInfo))
            return $this->error(1, '不是有效参数');

        if (!$this->validate($this->preg['fundpwd'], 'post.data.fundpwd1', $data['fundpwd2']))
            return $this->error(3, '资金密码格式不正确');

        if (!$this->validate($this->preg['fundpwd'], 'post.data.fundpwd2', $data['fundpwd2']))
            return $this->error(3, '确认资金密码格式不正确');

        if ($data['fundpwd1'] != $data['fundpwd2'])
            return $this->error(3, '两次资金密码不一样');

        $password = $this->password($data['fundpwd1'], $userInfo['username']);

        if ($password == $userInfo['out_password'])
            return $this->error(3, '不能和原资金密码一致');

        $rs = $this->model('user')->_update(['out_password' => $password], ['id' => $where['id']]);
        if (false === $rs)
            return $this->error(1, '修改异常，请稍后重试。');

        return $this->success(['status' => true, 'affected_rows' => (int)$rs]);
    }

}
