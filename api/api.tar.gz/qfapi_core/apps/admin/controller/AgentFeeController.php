<?php

/**
 * @module_doc_start
 * @module_name:代理手续费
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class AgentFeeController extends _AdminController
{

    public $needCheckAccess = true;
    protected $moduleModel = 'AgentFee';

    /**
     * @action_doc_start
     * @action_index:set
     * @action_name:设置代理手续费
     * @action_description:
     * 请求参数:
     * {
     *      data: {
     *          xz_fee_raido: 12.01, // 行政费
     *          in_fee_raido: 0.01, // 入款手续费
     *          in_fee_limit: 10000000, // 入款手续费上限
     *          out_fee_radio: 0.01, // 出款手续费
     *          out_fee_limit: 10000000, // 出款手续费上限
     *          share_return_bet_radio:  0.01, // 分摊会员返水费用
     *          share_give_fee_radio: 0.01 // 均摊会员优惠赠送费用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//设置成功，返回true，失败返回false
     *          insert_id:2, // 新设置成功的ID
     *      }
     * }
     * @action_doc_end
     */
    public function actionSet()
    {
        $data = (array) $this->input('post.data');
        if (empty($data)) {
            return $this->error(3, '参数错误');
        }

        $data = array_map('floatval', $data);

        if (!isset($data['xz_fee_raido']) || ($data['xz_fee_raido'] > 99.99 && $data['xz_fee_raido'] < 0)) {
            return $this->error('3', '行政费设置不合理');
        }
        if (!isset($data['in_fee_raido']) || ($data['xz_fee_raido'] > 99.99 && $data['xz_fee_raido'] < 0)) {
            return $this->error('3', '入款手续费设置不合理');
        }
        if (!isset($data['in_fee_limit']) || (strlen($data['in_fee_limit']) > 10 && $data['in_fee_limit'] < 0)) {
            return $this->error('3', '入款手续费上限设置不合理');
        }
        if (!isset($data['out_fee_radio']) || ($data['out_fee_radio'] > 99.99 && $data['out_fee_radio'] < 0)) {
            return $this->error('3', '出款手续费设置不合理');
        }
        if (!isset($data['out_fee_limit']) || (strlen($data['out_fee_limit']) > 10 && $data['out_fee_limit'] < 0)) {
            return $this->error('3', '出款手续费上限设置不合理');
        }
        if (!isset($data['share_return_bet_radio']) || ($data['share_return_bet_radio'] > 99.99 && $data['share_return_bet_radio'] < 0)) {
            return $this->error('3', '分摊会员返水费用设置不合理');
        }
        if (!isset($data['share_give_fee_radio']) || ($data['share_give_fee_radio'] > 99.99 && $data['share_give_fee_radio'] < 0)) {
            return $this->error('3', 'share_give_fee_radio设置不合理');
        }

        $model = $this->model($this->moduleModel);

        $model->_update(['status' => 0]);

        $data['status'] = 1;
        $ret_insert = $model->_insert($data);
        $ret = [
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "insert_id" => (int) $ret_insert
        ];

        return $ret_insert ? $this->success($ret) : $this->error('添加失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:get
     * @action_name:获取代理手续费
     * @action_description:
     * 请求参数:
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          xz_fee_raido: 12.01, // 行政费
     *          in_fee_raido: 0.01, // 入款手续费
     *          in_fee_limit: 10000000, // 入款手续费上限
     *          out_fee_radio: 0.01, // 出款手续费
     *          out_fee_limit: 10000000, // 出款手续费上限
     *          share_return_bet_radio:  0.01, // 分摊会员返水费用
     *          share_give_fee_radio: 0.01 // 均摊会员优惠赠送费用
     *      }
     * }
     * @action_doc_end
     */
    public function actionGet()
    {
        $field = 'xz_fee_raido, in_fee_raido, in_fee_limit, out_fee_radio, out_fee_limit, share_return_bet_radio, share_give_fee_radio';

        $list = $this->model($this->moduleModel)->_lists("", 'id desc', 1, null, $field);

        if (empty($list)) {
            foreach (explode(',', $field) as $value) {
                $detail[trim($value)] = 0;
            }
        } else {
            $detail = $list[0];
        }

        return $this->success($detail);
    }


}
