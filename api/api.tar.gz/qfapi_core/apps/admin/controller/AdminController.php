<?php

/**
 * @module_doc_start
 * @module_name:后台管理员
 * @module_model:Admin
 * @module_description:
 * @module_doc_end
 */
class AdminController extends _AdminController
{

    public $needCheckAccess = true;
    public $noNeedCheckAction = array("Login", "Logout");
    public $noNeedLogAction = array("Login");
    protected $moduleModel = "Admin";

    /**
     * @action_doc_start
     * @action_index:login
     * @action_name:登陆
     * @action_description:
     * 参数：
     * {
     *      name:"jaky",//用户名
     *      password:"123qwe",//密码，6-12位非*字符
     *      authcode:"4345"//验证码，4-6位a-zA-Z0-9字符
     * }
     *
     * 返回值：
     * {
     *      code:0,//3：参数错误
     *      msg:'',//错误信息
     *      data:{
     *          admin:{
     *              id:1,//用户id
     *              name:"jaky",//用户名
     *          }
     *      }
     * }
     *
     *
     * @action_doc_end
     */
    public function actionLogin()
    {
        $name = $password = $authcode = "";

        if ($this->validate('notempty', 'post.name', $name) === false) {
            return $this->error(3, '请输入用户名');
        }

        if ($this->validate('notempty', 'post.password', $password) === false) {
            return $this->error(3, '请输入密码');
        }

//        if ($this->validate('/^[a-zA-Z0-9]{4,6}$/', 'post.authcode', $authcode) === false) {
//            return $this->error(3, '验证码不能为空!');
//        }
//        if ($authcode != iSession::get("login_authnum")) {
//            return $this->error("验证码错误" . iSession::get("login_authnum"));
//        }

        $rest_user = $this->model("admin");

        $user = $rest_user->_detail(["name" => $name]);

//        if (empty($user) || $user["name"]!=$name) {
//            return $this->error("用户名不存在");
//        }

        if (empty($user["password"]) || $user["password"] !== $this->password($password, $user["salt"])) {
            return $this->error("密码不正确");
        } else {
            //查看是否状态正常
            if ($user["status"] !== "1") {
                return $this->error("该用户已被禁用");
            }

            $data = array(
                "id" => $user["id"],
                "salt" => $user["salt"],
                "name" => $user["name"],
                "group_ids" => $user["group_ids"],
                "is_admin" => $user["is_admin"]
            );

            // 挤出其他会话用户
            iSession::logoutUser($user['id'], 0, 0, 2);
            iSession::redis("zAdd", APP_NAME . '_pc_list', time(), $user['id']);
            iSession::redis("set", APP_NAME . '_' . $user['id'], iGlobal::get("access_token"));

            // 注册新用户会话
            iSession::set($data); //登录用户会话存储30天
            unset($data["salt"]);
            unset($data["group_ids"]);
            $group_ids = array_filter(explode(",", $user["group_ids"]));
            $data["group_names"] = boolval($user["is_admin"]) ? ["admin"] : array_column($this->model("AdminGroup")->_lists(["id" => ["in", $group_ids]]), "name");

            //修改最后登录时间
            $this->model("Admin")->_update(["last_login_time" => time()], $user["id"]);

            //返回用户数据
            return $this->success(array("admin" => $data));
        }
    }

    /**
     * @action_doc_start
     * @action_index:logout
     * @action_name:登陆注销
     * @action_description:
     * 会销毁当前用户token对应会话缓存信息
     * @action_doc_end
     */
    public function actionLogout()
    {

        $uid = iSession::get('id');
        iSession::logoutUser($uid, 0, 0, 2);
        return $this->success();
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:管理员列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *          //create_time:["between",['2019-12-12 12:12:12','2019-12-13 12:12:12']],
     *          //id:[">",100],
     *          //_group_index:[
     *              group_ids:["like","%,1,%"],//前后有逗号
     *              "or",
     *              group_ids:["like","%,2,%"],//前后有逗号
     *          ]
     *      },
     *      attr:"id,name",//需要显示的对象属性，可以为字符串，也可以是数组
     *      need_total:true/false,//是否需要统计总量
     *      offset:0,//偏移量
     *      page:1,//分页
     *      page_size:10,//分页大小：默认10
     *      order:"id desc",//排序，默认id 倒序，规则为：字段+空格+“desc/asc”,
     *      need_admin_group_lists:1//如果为1，则将返回admin_group_lists
     *
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          admin_group_lists:{
     *              1:"系统管理员",
     *              2:"运营管理员"
     *          },
     *          lists:[
     *              {
     *                  name:"jaky",//新的账户名
     *                  password:"123qwe",//任何不能为空，密码将被加密成40位字符，原始密码可以包含任何字符
     *                  group_ids:"admin,operate",//用户的角色，可以多个
     *                  create_at:"1542712345",//注册时间，时间戳格式
     *                  update_at："1542712345"，//记录更新时间，时间戳格式
     *                  status:1,//管理员状态,-1:逻辑删除，0：待审核，1：正常，2：禁止
     *                  remark:"备注",//管理员备注，例如备注“该管理员被xxx禁止，原因：该用户转到其他部门”
     *              }
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        //只允许列表非admin账号
        $where = $this->input("post.where", array());
        $where["is_admin"] = 0;
        $this->POST["where"] = $where;

        //不能返回密码
        $this->model($this->moduleModel)->forbit_field = array("password", "salt");
        $ret = parent::actionLists();
        $is_need_admin_group_lists = (int)$this->input("post.need_admin_group_lists", 0);
        if ($is_need_admin_group_lists) {
            $admin_group_lists = $this->model("AdminGroup")->_lists(["status" => [">=", 0]], "id desc", 100, null, "id,name");
            $ret["data"]["admin_group_lists"] = $admin_group_lists;
        }

        return $ret;
    }

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:管理员新增
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          name:"jaky",//新的账户名
     *          password:"123qwe",//任何不能为空，密码将被加密成40位字符，原始密码可以包含任何字符
     *          group_ids:"admin,operate",//用户的角色，可以多个
     *          status:1,//管理员状态,-1:逻辑删除，0：待审核，1：正常，2：禁止
     *          remark:"备注",//管理员备注，例如备注“该管理员被xxx禁止，原因：该用户转到其他部门”
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//新增成功，返回true，失败返回false
     *          affected_rows:2,//增加个数，例如一次性新增了3个管理员信息
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        //参数验证
        $name = "";
        if (!$this->validate("/[\u{4e00}-\u{9fa5}0-9a-zA-Z]{2,18}/", "post.data.name", $name)) {
            return $this->error(3, "用户名须 2-18 位字母、数字或汉字");
        }
        if (!$this->validate("notempty", "post.data.password")) {
            return $this->error(3, "密码不能为空");
        }

        //创建盐值
        $this->POST["data"]["salt"] = rand(0, 9999);
        //密码转换
        $this->POST["data"]["password"] = $this->password($this->POST["data"]["password"], $this->POST["data"]["salt"]);

        //检查用户名是否已经存在
        $admin = $this->model($this->moduleModel)->_detail(["name" => $name]);
        if ($admin) {
            return $this->error("用户名已存在");
        }

        return parent::actionInsert();
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:管理员编辑
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]]
     *      },
     *      data:{//未修改数据即可不传
     *          name:"jaky",//新的账户名
     *          password:"123qwe",//任何不能为空，密码将被加密成40位字符，原始密码可以包含任何字符
     *          group_ids:"admin,operate",//用户的角色，可以多个
     *          status:1,//管理员状态,-1:逻辑删除，0：待审核，1：正常，2：禁止
     *          remark:"备注",//管理员备注，例如备注“该管理员被xxx禁止，原因：该用户转到其他部门”
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//修改成功，返回true，失败返回false
     *          affected_rows:2,//修改个数，例如一次性修改了3个管理员信息
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        //只允许修改非admin账号
        $where = $this->input("post.where", array());
        $where["is_admin"] = 0;
        $this->POST["where"] = $where;

        //验证是否修改了密码
        if ($this->validate("notempty", "post.data.password")) {
            $id = $this->input("post.where.id", 0);
            if (is_array($id)) {
                return $this->error(3, "修改密码只能针对单个账户进行操作");
            }
            if (empty($id)) {
                return $this->error(3, "修改密码必须提供账户id");
            }
            $admin = $this->model($this->moduleModel)->_detail(["id" => $id]);
            if (empty($admin)) {
                return $this->error("管理员不存在，无法修改");
            }
            $salt = $admin["salt"];

            $this->POST["data"]["password"] = $this->password($this->POST["data"]["password"], $salt);
        } else {
            unset($this->POST["data"]["password"]);
        }

        $ret = parent::actionUpdate();

        $new_group_ids = $this->input("post.data.group_ids", null);
        if ($ret["code"] == 0 && $new_group_ids) {
            $ids = $ret["data"]["ids"];
            iSession::resetUserGroupIds($ids, $new_group_ids);
        }

        //如果修改了密码
        if ($ret["code"] == 0 && $this->validate("notempty", "post.data.password")) {
            iSession::logoutUser($id, 0, 0, 2);
        }

        return $ret;
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:管理员删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除个数，例如一次性删除了3个管理员信息
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete()
    {
        //只允许删除非admin账号
        $where = $this->input("post.where", array());
        $where["is_admin"] = 0;
        $this->POST["where"] = $where;

        $ret = parent::actionDelete();
        if ($ret["code"] == 0) {
            $ids = $ret["data"]["ids"];
            iSession::logoutUser($ids, 0, 0, 2);
        }

        return $ret;
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用管理员
     * @action_description:
     * 请求参数：
     * {
     *      where:{
     *          id:1,//id:[1,2,3]
     *      },
     *      data:{
     *          status:0,//-1：逻辑删除，0：待审核，1：正常，2：禁止
     *          remark:""//状态备注
     *      }
     * }
     * 返回值：
     * {
     *      code:0,
     *      msg:'',
     *      data:{
     *          status:true,//状态修改是否成功，true:成功，false：失败
     *          affected_rows:1//影响记录数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        //只允许修改非admin账号状态
        $where = $this->input("post.where", array());
        $where["is_admin"] = 0;
        $this->POST["where"] = $where;

        $ret = parent::actionChangeStatus();

        if ($this->input("post.data.status") == 2 && $ret["code"] == 0) {
            $ids = $ret["data"]["ids"];
            iSession::logoutUser($ids, 0, 0, 2);
        }

        return $ret;
    }


    /**
     * @action_doc_start
     * @action_index:onlineUserList
     * @action_name:获取管理在线列表
     * @action_description:
     * 请求参数:
     * {
     *      page: 1, //当前页
     *      page_size: 10, //记录数
     * }
     * 返回值：
     *   {
     *       code:0,
     *       msg:'',
     *       data:{
     *           lists: [
     *              {
                        "id": "16",
                        "name": "admin3",
                        "group_names": [ //所属组
                            "超级管理员"
                        ]
                    }
     *          ],
     *          'total_num'://总记录数
     *          'total_page'://总页数
     *       }
     *   }
     * @action_doc_end
     */
    public function actionOnlineUserList()
    {

        $page = (int)$this->input('post.page', 1);
        $pagesize = (int)$this->input('post.page_size', 10);

        $start = time();
        $end = strtotime("-1 hour");
        $count = iSession::redis('zCount', 'admin_pc_list', $end, $start);

        $total_page = ceil($count / $pagesize);

        if ($page > $total_page)
            return $this->success(['lists' => [], 'total_num' => $count, 'total_page' => $total_page]);

        $idArr = iSession::redis("zRevRangeByScore", 'admin_pc_list', $start, $end, ['limit' => [($page - 1) * $pagesize, $pagesize]]);
        $idArr = array_filter($idArr);
        $list = [];
        $tokenArr = iSession::redis('mget', array_map(function ($r) {
            return 'admin_' . $r;
        }, $idArr));

        if (!empty($tokenArr)) {
            $tList = iSession::redis('mget', array_map(function ($r) {
                return 'accesstoken_' . $r;
            }, $tokenArr));
            $tList = array_map(function ($r) {
                return json_decode($r, true);
            }, $tList);
            if (!empty($tList)) {
                $groups = array_column($tList, 'group_ids');
                $groupids = [];
                foreach ($groups as $v) {
                    $v = trim($v, ',');
                    $groupids = array_merge($groupids, explode(',', $v));
                }

                $groupids = array_filter(array_unique($groupids));
                $adminMod = $this->model('admin_group');

                $gList = $adminMod->_lists(['id' => ['in', $groupids]], null, null, null, 'id,name');
                $ngList = [];
                foreach ($gList as $k => $v) {
                    $ngList[$v['id']] = $v['name'];
                }

                foreach ($tList as $k => $v) {
                    if (empty($v)) {
                        continue;
                    }
                    $groups = array_unique(explode(',', trim($v['group_ids'], ',')));
                    $v['group_names'] = [];
                    foreach ($groups as $vs) {
                        if ($vs) {
                            $v['group_names'][] = $ngList[$vs];
                        }
                    }
                    $list[] = $v;
                }
            }

            unset($tList, $groupids, $groups, $gList, $ngList);
        }

        return $this->success(['lists' => $list, 'total_num' => $count, 'total_page' => $total_page]);
    }

    /**
     * @action_doc_start
     * @action_index:kickoutAdmin
     * @action_name:将在线管理员踢下线
     * @action_description:
     * 请求参数:
     * {
     *      id: 1, //用户id
     * }
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *      }
     * }
     * @action_doc_end
     */
    public function actionKickoutAdmin()
    {
        $id = (int)$this->input('post.id', 0);
        if (!$id) return $this->error(3, '请指定用户');

        iSession::logoutUser($id, 0, 1, 2);

        return $this->success();
    }

}
