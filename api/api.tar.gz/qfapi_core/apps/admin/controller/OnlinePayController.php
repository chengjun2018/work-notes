<?php

/**
 * @module_doc_start
 * @module_name:在线支付管理
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class OnlinePayController extends _AdminController
{

    public $needCheckAccess = true;
    protected $moduleModel = 'PayOnlineConfig';

    /**
     * @action_doc_start
     * @action_index:onlinePayAdd
     * @action_name:在线支付添加
     * @action_description:
     * 请求参数:
     * {
     *      data: {
     *          channle_code: 'bmw', // 支付渠道code
     *          pay_code: 'alipay', // 支付通道code
     *          client_type: [1,2], // 支持终端 1PC 2H5
     *          pay_url: 'http://asdf.asdf.com/index.php/asdf/sdf', // 支持终端 1PC 2H5
     *          buession_no: 'asdfkllkasdfkl;asfjkklasdfjkl', // 商户号
     *          buession_key: 'ajfdklajfklaskldfjkasjkldfjklasdfaskjfdasdkfl', // 商户秘钥
     *          single_limit_max: 100, // 单笔限额上限
     *          single_limit_min: 10, // 单笔限额下限
     *          day_limit_max: 1000.55, // 单日限额（当天累计收款达到后将停止展示）
     *          bet_radio: 55.44, // 彩金比例
     *          mast_dml: 10000 , // 打码量（流水要求）
     *          user_tier: [1,2,3], // 会员分层
     *          status: 1 //状态 1正常 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
                "status": true,
                "insert_id": 9
     *      }
     * }
     * @action_doc_end
     */
    public function actionOnlinePayAdd()
    {
        $data = $this->input('post.data');
        if (empty($data)) {
            $this->error(3, '参数错误');
        }
        if (!empty($data['user_tier']) && is_array($data['user_tier'])) {
            $data['user_tier'] = implode(',', $data['user_tier']);
        }
        if (!empty($data['client_type']) && is_array($data['client_type'])) {
            $data['client_type'] = implode(',', $data['client_type']);
        }
        $data['admin_id'] = $this->member['id'];
        $data['admin_name'] = $this->member['name'];
        $this->POST['data'] = $data;

        return parent::actionInsert();
    }

    /**
     * @action_doc_start
     * @action_index:onlinePayGet
     * @action_name:在线支付列表
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          channle_code: ['in', 'bmw,test_pay'], // 支付渠道code
     *          //channle_code: 'bmw', // 支付渠道code
     *          pay_code:  ['in', 'alipay,wechatpay'], // 支付通道code
     *          //pay_code: 'alipay', // 支付通道code
     *          status: 1, // 状态 1正常 0 警用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
     *          "lists": [
                    {
                        "id": "8",
                        "channle_code": "bmw",
                        "pay_code": "alipay",
                        "client_type": "1,2", // 支付终端
                        "single_limit_min": "100.00", // 单笔支付最大额度
                        "single_limit_max": "100.00", // 单笔支付最小额度
                        "day_limit_max": "1000.55", // 当日最大额度
                        "user_tier": "1,2,3",
                        "admin_name": "meak",
                        "status": 1,
                        "update_at": '1556162388';,
                        "pay_name": "支付宝", // 支付通道
                        "channle_name": "宝马微信二维码", // 支付渠道
                        "user_tier_name": "abc、二级会员"
                    },
               ],
                "channle": [
                    {
                    "channle_code": "bmw",
                    "name": "宝马微信二维码"
                    },
               ],
              "pay_type": [
                    {
                    "pay_code": "alipay",
                    "name": "支付宝"
                    },
                ],
                "user_tier": [
                    {
                    "id": "1",
                    "name": "abc",
                    "status": "1",
                    "is_default": "0"
                    }
                ],
                total_num: 10,
                total_page: 1

     *      }
     * }
     * @action_doc_end
     */
    public function actionOnlinePayGet()
    {
        $page_size = (int)$this->input("post.page_size", 10);
        $page = (int)$this->input("post.page", 1);
        $order = (string)$this->input("post.order", "id desc");
        $need_total = (int)$this->input("post.need_total", 0);
        $where = $this->input('post.where');

        $page = $page < 1 ? 1 : $page;
        $page_size = $page_size < 10 ? 10 : $page_size;
        $limit = ($page - 1) * $page_size . ',' . $page_size;

        $field = 'id, channle_code, pay_code, client_type, single_limit_min, single_limit_max, day_limit_max, user_tier, admin_name, status, update_at';

        $onlinePay =  $this->model($this->moduleModel);
        $list = $onlinePay->_lists($where, $order, $limit, null, $field);

        $userTier = $this->model('UserTier')->_lists([], null, null, null, 'id, name, status, is_default');

        $returnData = [
            'lists' => [],
            'channle' => Pay::$thirdPay,
            'pay_type' => Pay::$payData,
            'user_tier' => $userTier,
        ];

        $temp1 = [];
        foreach (Pay::$payData as $value) {
            $temp1[$value['pay_code']]  = $value['name'];
        }
        $temp2 = [];
        foreach (Pay::$thirdPay as $value) {
            $temp2[$value['channle_code']]  = $value['name'];
        }
        $temp3 = [];
        foreach ($userTier as $value) {
            $temp3[$value['id']] = $value['name'];
        }

        foreach ($list as  $value) {
            $value['pay_name'] = $temp1[$value['pay_code']];
            $value['channle_name'] = $temp2[$value['channle_code']];
            $value['user_tier_name'] = '';
            if ($value['user_tier']) {
                $temp = [];
                foreach (explode(',', $value['user_tier']) as $iV) {
                    if (isset($temp3[$iV])) {
                        $temp[] = $temp3[$iV];
                    }
                }
                $value['user_tier_name'] = $temp ? implode('、', $temp) : '';
            }
            $returnData['lists'][] = $value;
        }
        if ($need_total) {
            $total_num = $onlinePay->_count($where, null);
            $returnData["total_num"] = (int)$total_num;
            $returnData["total_page"] = ceil($total_num / $page_size);
        }

        return $this->success($returnData);
    }

    /**
     * @action_doc_start
     * @action_index:onlinePayDetail
     * @action_name:在线支付详情
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 8
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
     *          "detail": {
                    "id": "8",
                    "channle_code": "bmw", // 渠道编码
                    "pay_code": "alipay", // 支付通道编码
                    "client_type": [1,2], // 支持客户端 1PC 2H5
                    "pay_url": "http://asdf.asdf.com/index.php/asdf/sdf", // 支付url
                    "buession_no": "asdfkllkasdfkl;asfjkklasdfjkl", //商户号
                    "buession_key": "ajfdklajfklaskldfjkasjkldfjklasdfaskjfdasdkfl", // 商户秘钥
                    "single_limit_max": "100.00", // 单笔最大限额
                    "single_limit_min": "100.00", // 单笔最小限额
                    "day_limit_max": "1000.55", // 单日限额
                    "bet_radio": "55.44", // 彩金比例
                    "mast_dml": "10000.00", // 打码量
                    "user_tier": [1,2,3], // 会员分层
                    "admin_id": "20", // 管理员ID
                    "admin_name": "meak", // 管理name
                    "status": "1", // 状态 1 启用 0 停用
                    "create_at": "1556160823", // 添加时间
                    "update_at": "1556160823" // 修改时间
                    }
               }
     * }
     * @action_doc_end
     */
    public function actionOnlinePayDetail()
    {
        $returnData = parent::actionDetail();

        if ($returnData['data']['detail']) {
            if ($returnData['data']['detail']['user_tier'])
                $returnData['data']['detail']['user_tier'] = explode(',', $returnData['data']['detail']['user_tier']);
            else
                $returnData['data']['detail']['user_tier'] = [];

            if ($returnData['data']['detail']['client_type'])
                $returnData['data']['detail']['client_type'] = explode(',', $returnData['data']['detail']['client_type']);
            else
                $returnData['data']['detail']['client_type'] = [];
        }

        return $returnData;
    }


    /**
     * @action_doc_start
     * @action_index:onlinePayUpdate
     * @action_name:在线支付修改
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 8
     *      },
     *      data: {
     *          channle_code: 'bmw', // 支付渠道code
     *          pay_code: 'alipay', // 支付通道code
     *          client_type: [1,2], // 支持终端 1PC 2H5
     *          pay_url: 'http://asdf.asdf.com/index.php/asdf/sdf', // 支持终端 1PC 2H5
     *          buession_no: 'asdfkllkasdfkl;asfjkklasdfjkl', // 商户号
     *          buession_key: 'ajfdklajfklaskldfjkasjkldfjklasdfaskjfdasdkfl', // 商户秘钥
     *          single_limit_max: 100, // 单笔限额上限
     *          single_limit_min: 10, // 单笔限额下限
     *          day_limit_max: 1000.55, // 单日限额（当天累计收款达到后将停止展示）
     *          bet_radio: 55.44, // 彩金比例
     *          mast_dml: 10000 , // 打码量（流水要求）
     *          user_tier: [1,2,3], // 会员分层
     *          status: 1 //状态 1正常 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
                "status": true,
                "affected_rows": 1
     *      }
     * }
     * @action_doc_end
     */
    public function actionOnlinePayUpdate()
    {
        $data = $this->input('post.data');
        if (empty($data)) {
            $this->error(3, '参数错误');
        }
        if (!empty($data['user_tier']) && is_array($data['user_tier'])) {
            $data['user_tier'] = implode(',', $data['user_tier']);
        }
        if (!empty($data['client_type']) && is_array($data['client_type'])) {
            $data['client_type'] = implode(',', $data['client_type']);
        }
        $data['admin_id'] = $this->member['id'];
        $data['admin_name'] = $this->member['name'];
        $this->POST['data'] = $data;

        return parent::actionUpdate();
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      },
     *      data:{
     *          status: 0, // 状态 1正常 0禁用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        return parent::actionChangeStatus();
    }





}
