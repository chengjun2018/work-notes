<?php

/**
 * @module_doc_start
 * @module_name:平台配置
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class PlatformConfigController extends _AdminController
{

    public $needCheckAccess = true;
    private $userInOutConfigTable = 'UserInOutConfig';

    /**
     * @action_doc_start
     * @action_index:inOutConfigSet
     * @action_name:用户存取款设置
     * @action_description:
     * 请求参数:
     * {
     *      data: {
     *          in_discount_radio: 12.01, // 公司入款优惠比例
     *          in_give_bet_radio: 0.01, // 公司入款赠送彩金比例
     *          in_give_bet_limit: 10000000, // 公司入款赠送彩金上限
     *          in_dml_raido: 0.01, // 公司入款打码量倍率（流水要求）
     *          out_free_count: 10000000, // 免费取款次数
     *          out_relax_amount: 5, // 取款放宽额度
     *          out_fee:  0.01, // 取款手续费
     *          out_fee_force_radio: 0.01, // 强制取款手续费比例
     *          out_fee_xz: 0.01 // 取款行政费
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//设置成功，返回true，失败返回false
     *          insert_id:2, // 新设置成功的ID
     *      }
     * }
     * @action_doc_end
     */
    public function actionInOutConfigSet()
    {
        $data = (array) $this->input('post.data');
        if (empty($data)) {
            return $this->error(3, '参数错误');
        }

        $data = array_map('floatval', $data);

        $model = $this->model($this->userInOutConfigTable);

        $data['status'] = 1;
        $data['admin_id'] = $this->member['id'];
        $ret_insert = $model->_insert($data);

        if ($ret_insert) {
            $model->_update(['status' => -1], ['status' => 1, 'id' => ['<>', $ret_insert]]);

            return $this->success(['status' => true, 'insert_id' => $ret_insert]);
        }

        return $this->error('添加失败，请重试！');
    }

    /**
     * @action_doc_start
     * @action_index:inOutConfigGet
     * @action_name:当前用户存取款配置
     * @action_description:
     * 请求参数:
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          in_discount_radio: 12.01, // 公司入款优惠比例
     *          in_give_bet_radio: 0.01, // 公司入款赠送彩金比例
     *          in_give_bet_limit: 10000000, // 公司入款赠送彩金上限
     *          in_dml_raido: 0.01, // 公司入款打码量倍率（流水要求）
     *          out_free_count: 10000000, // 免费取款次数
     *          out_relax_amount: 5, // 取款放宽额度
     *          out_fee:  0.01, // 取款手续费
     *          out_fee_force_radio: 0.01, // 强制取款手续费比例
     *          out_fee_xz: 0.01 // 取款行政费
     *      }
     * }
     * @action_doc_end
     */
    public function actionInOutConfigGet()
    {
        $field = 'in_discount_radio, in_give_bet_radio, in_give_bet_limit, in_dml_raido, out_free_count, out_relax_amount, out_fee, out_fee_force_radio, out_fee_xz';

        $list = $this->model($this->userInOutConfigTable)->_lists(['status' => 1], 'id desc', 1, null, $field);

        if (empty($list)) {
            foreach (explode(',', $field) as $value) {
                $detail[trim($value)] = 0;
            }
        } else {
            $detail = $list[0];
        }

        return $this->success($detail);
    }

    /**
     * @action_doc_start
     * @action_index:gameConfigSet
     * @action_name:游戏平台设置
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 1, // 游戏ID
     *      },
     *      data: {
     *          status: 1, // 状态：1启用 0禁用
     *          is_wh: 0, // 是否维护：1是 0否
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                status:true/false,//更新成功，返回true，失败返回false
                affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionGameConfigSet()
    {
        $where = $this->input('post.where');
        if (empty($where['id'])) {
            return $this->error('3', '参数错误');
        }

        $this->moduleModel = 'Game';
        return parent::actionUpdate();
    }

    /**
     * @action_doc_start
     * @action_index:gameConfigGet
     * @action_name:当前游戏平台状态
     * @action_description:
     * 请求参数:
     * {
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:[
     *          {
                    "id": "1",
                    "label": "真人娱乐",
                    "value": "live",
                    "code": "live",
                    "children": [
                        {
                            "id": "7",
                            "title": "AG急速厅",
                            "code": "ag_fa",
                            "pid": "1",
                            "is_wh": "0", // 是否维护
                            "is_sw": "0", // 是否试玩
                            "status": "1", // 状态  1启用 0禁用
                            "value": "live_ag_fa"
                        },
                   ]
               },
     *      ]
     * }
     * @action_doc_end
     */
    public function actionGameConfigGet()
    {
        $games = (new Game())->getTypeData();

        return $this->success($games);
    }






}
