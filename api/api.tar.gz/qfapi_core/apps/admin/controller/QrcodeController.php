<?php

/**
 * @module_doc_start
 * @module_name:公司支付二维码管理
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class QrcodeController extends iController
{

    public $needCheckAccess = true;
    protected $moduleModel = 'PayQrcode';
    protected $uploadPath = UPLOAD_PATH . '/pay_qrcode/';

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * 请求参数:
     * {
     *      data: {
     *          pay_code: 'alipay', // 支付code
     *          pay_username: '账号',
     *          pay_realname: '姓名',
     *          qrcode_path: '二维码路径',
     *          qrcode_name: '二维码图片名字',
     *          single_limit_max: 100, // 单笔限额上限
     *          single_limit_min: 10, // 单笔限额下限
     *          day_limit_max: 1000.55, // 单日限额（当天累计收款达到后将停止展示）
     *          remark: '描述',
     *          user_tier: [1,2,3], // 会员分层
     *          status: 1 //状态 1正常 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "status": true,
                "insert_id": 9
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = $this->input('post.data');
        if (empty($data)) {
            $this->error(3, '参数错误');
        }
        if (!empty($data['user_tier']) && is_array($data['user_tier'])) {
            $data['user_tier'] = implode(',', $data['user_tier']);
        }
        $temp = array_column(Pay::$payData, 'name','pay_code');
        if (empty($data['pay_code']) || !isset($temp[$data['pay_code']])) {
            return $this->error(3, '不支持此支付方式');
        }
        $data['pay_name'] = $temp[$data['pay_code']];
        $data['admin_id'] = $this->member['id'];
        $data['admin_name'] = $this->member['name'];
        $this->POST['data'] = $data;

        return parent::actionInsert();
    }



    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 8
     *      },
     *      data: {
     *          pay_code: 'wechatpay', // 支付code
     *          pay_username: '账号123',
     *          pay_realname: '姓名123',
     *          qrcode_path: '二维码路径',
     *          qrcode_name: '二维码图片名字',
     *          single_limit_max: 100, // 单笔限额上限
     *          single_limit_min: 10, // 单笔限额下限
     *          day_limit_max: 1000.55, // 单日限额（当天累计收款达到后将停止展示）
     *          remark: '描述123',
     *          user_tier: [1,2,3], // 会员分层
     *          status: 1 //状态 1正常 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
                "status": true,
                "affected_rows": 1
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $data = $this->input('post.data');
        if (empty($data)) {
            $this->error(3, '参数错误');
        }
        if (!empty($data['user_tier']) && is_array($data['user_tier'])) {
            $data['user_tier'] = implode(',', $data['user_tier']);
        }
        $temp = array_column(Pay::$payData, 'name','pay_code');
        if (!empty($data['pay_code']) && isset($temp[$data['pay_code']])) {
            $data['pay_name'] = $temp[$data['pay_code']];
        }
        $data['admin_id'] = $this->member['id'];
        $data['admin_name'] = $this->member['name'];
        $this->POST['data'] = $data;

        return parent::actionUpdate();
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:列表
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          pay_code: 'alipay', // 支付code
     *         // pay_code: ['in', 'alipay,wechatpay'],
     *          status: 1, // 状态 1正常 0 警用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
     *          "lists": [
                    {
                        "id": "2",
                        "pay_code": "alipay",
                        "pay_name": "支付宝",
                        "pay_username": "账号",
                        "pay_realname": "姓名",
                        "qrcode": "二维码路径",
                        "user_tier": [ "1", "2", "3" ],
                        "remark": "描述",
                        "admin_id": "20",
                        "admin_name": "meak",
                        "status": "1",
                        "create_at": "1556185351",
                        "update_at": "1556185351",
                        "user_tier_name": "abc、二级会员"
                    },
               ],
                "user_tier": [
                    {
                        "id": "1",
                        "name": "abc",
                        "status": "1",
                        "is_default": "0"
                    }
                ],
                "pay_type": [
                    {
                        "pay_code": "alipay",
                        "name": "支付宝"
                    }
                ]

     *      }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $returnData = parent::actionLists();

        $userTier = $this->model('UserTier')->_lists([], null, null, null, 'id, name, status, is_default');

        $returnData['data']['user_tier'] = $userTier;
        $returnData['data']['pay_type'] = Pay::$payData;

        $temp1 = $temp3 = [];
        foreach ($userTier as $value) {
            $temp3[$value['id']] = $value['name'];
        }
        foreach (Pay::$payData as $value) {
            $temp1[$value['pay_code']]  = $value['name'];
        }

        foreach ($returnData['data']['lists'] as $key => $value) {
            $user_tier_name = '';
            if ($value['user_tier']) {
                $value['user_tier'] = explode(',', $value['user_tier']);
                $temp = [];
                foreach ($value['user_tier'] as $iV) {
                    if (isset($temp3[$iV])) {
                        $temp[] = $temp3[$iV];
                    }
                }
                $user_tier_name = $temp ? implode('、', $temp) : '';
                $returnData['data']['lists'][$key]['user_tier'] = $value['user_tier'];
            }
            $returnData['data']['lists'][$key]['pay_name'] = $temp1[$value['pay_code']];
            $returnData['data']['lists'][$key]['user_tier_name'] = $user_tier_name;
        }

        return $returnData;
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      },
     *      data:{
     *          status: 0, // 状态 1正常 0禁用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        return parent::actionChangeStatus();
    }


    /**
     * @action_doc_start
     * @action_index:UplodImg
     * @action_name:上传图片
     * @action_description:
     * 请求参数:
     * {
     *      insertImg : [ // 多文件上传
     *          FILE文件1,
     *          ],
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          img_path: [ // 上传成功的文件路径 一个上传失败，同时上传的其他图片全部删除
                "/help_center/图片1.PNG",
                ],
     *      }
     * }
     * @action_doc_end
     */
    public function actionUplodImg()
    {
        return $this->uplodImg(0.5, 'insertImg', $this->request->files, '', '', ['jpg', 'jpeg', 'png', 'gif', 'tiff', 'raw', 'bmp']);
    }


    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 1
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
                "detail": {
                    "id": "1",
                    "pay_code": "wechatpay",
                    "pay_name": "微信",
                    "pay_username": "账号123",
                    "pay_realname": "姓名",
                    "qrcode_path": "二维码路径123",
                    "qrcode_name": "1,2,3",
                    "single_limit_max": "2",
                    "single_limit_min": "1",
                    "day_limit_max": "3",
                    "user_tier": [
                    "1",
                    "2",
                    "3"
                    ],
                    "remark": "描述123",
                    "admin_id": "80",
                    "admin_name": "vivian",
                    "status": "1",
                    "create_at": "1556185298",
                    "update_at": "1556288694"
                }
     *  }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $returnData = parent::actionDetail();

        if ($returnData['data']['detail']) {
            if ($returnData['data']['detail']['user_tier'])
                $returnData['data']['detail']['user_tier'] = explode(',', $returnData['data']['detail']['user_tier']);
            else
                $returnData['data']['detail']['user_tier'] = [];

            if ($returnData['data']['detail']['client_type'])
                $returnData['data']['detail']['client_type'] = explode(',', $returnData['data']['detail']['client_type']);
            else
                $returnData['data']['detail']['client_type'] = [];
        }

        return $returnData;
    }


}
