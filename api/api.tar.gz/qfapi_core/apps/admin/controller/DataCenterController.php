<?php

/**
 * @module_doc_start
 * @module_name:后台数据中心
 * @module_type:common
 * @module_description:
 * @module_doc_end
 */
class DataCenterController extends  _AdminController {

    public $needCheckAccess = true;
    public $sendCookie = true;


    /**
     * @action_doc_start
     * @action_index:overview
     * @action_name:平台数据总览 (需求待确定)
     * @action_description:
     * 请求参数: 无
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "detail": {
                    "today_recharge": 0, // 今日充值
                    "today_withdraw": 0, // 今日体现
                    "today_sale": 0,    // 今日销售
                    "today_award": 0,   // 今日派奖量
                    "day15_profit_loss": { // 近15天平台盈亏
                        "20190312": 1,
                        "20190313": 2,
                        "20190314": 3,
                        "20190315": 4,
                        "20190316": 5,
                        "20190317": 6,
                        "20190318": 7,
                        "20190319": 8,
                        "20190320": 9,
                        "20190321": 10,
                        "20190322": 11,
                        "20190323": 12,
                        "20190324": 13,
                        "20190325": 14,
                        "20190326": 15
                    },
                    "day31_appdown": { // 近31日APP下载量
                        "20190225": 9964,
                        "20190226": 5905,
                        "20190227": 450,
                        "20190228": 9396,
                        "20190301": 3165,
                        "20190302": 133,
                        "20190303": 3976,
                        "20190304": 3502,
                        "20190305": 5737,
                        "20190306": 3968,
                        "20190307": 4492,
                        "20190308": 3698,
                        "20190309": 5260,
                        "20190310": 6490,
                        "20190311": 9140,
                        "20190312": 9798,
                        "20190313": 6325,
                        "20190314": 7871,
                        "20190315": 8487,
                        "20190316": 9718,
                        "20190317": 8880,
                        "20190318": 3281,
                        "20190319": 6422,
                        "20190320": 2600,
                        "20190321": 6680,
                        "20190322": 9058,
                        "20190323": 4521,
                        "20190324": 6216,
                        "20190325": 2828,
                        "20190326": 2632
                    },
                    "login_num": 1,  // 登陆人数
                    "online_num": 0, // 在线人数
                    "register_new_num": 0, // 新增人数
                    "recharge_first_num": 0, // 首存人数
                    "vv": { // 域名访问量（日）
                        "yuing1": 1047,
                        "yuing2": 6617,
                        "yuing3": 6634,
                        "yuing4": 8752,
                        "yuing5": 9795,
                        "yuing6": 452,
                        "yuing7": 5582,
                        "yuing8": 5161,
                        "yuing9": 5071,
                        "yuing10": 3406
                    }
     *          }
     * }
     * @action_doc_end
     * TODO 平台数据总览
     */
    public function actionOverview()
    {
        $detail = [
            'today_recharge' => 0,
            'today_withdraw' => 0,
            'today_sale' => 0,
            'today_award' => 0,
            'day15_profit_loss' => [],
            'day31_appdown' => [],
            'login_num' => 1,
            'online_num' => 0,
            'register_new_num' => 0,
            'recharge_first_num' => 0,
            'vv' => [],
        ];

        $now = time();
        for ($i = 15; $i >= 1; $i--) {
            $detail['day15_profit_loss'][date('Ymd', $now - $i * 3600 * 24)] = 16 - $i;
        }
        for ($i = 30; $i >= 1; $i--) {
            $detail['day31_appdown'][date('Ymd', $now - $i * 3600 * 24)] = mt_rand(0, 10000);
        }
        for ($i = 1; $i <= 10; $i++) {
            $detail['vv']['yuing' . $i] = mt_rand(0, 10000);
        }

        return $this->success(['detail' => $detail]);
    }

    /**
     * @action_doc_start
     * @action_index:operationReport
     * @action_name:运营报表(需求待确定)
     * @action_description:
     * 请求参数: 无
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          detail:{
                    "profit_loss": [], // 输赢报表
                    "recharge_withdraw": [], // 充提报表
                    "rmd_total": [], // 推广统计
                    "day_report": [], // 每日报表
                    "user_keep_analysis": [], // 用户留存分析
                    "user_active_analysis": [], // 用户活跃分析
                    "ip_total": [] // IP查询
                    }
     *          }
     *      }
     * }
     * @action_doc_end
     * TODO 运营报表
     */
    public function actionOperationReport()
    {
        $detail = [
            'profit_loss' => [],
            'recharge_withdraw' => [],
            'rmd_total' => [],
            'day_report' => [],
            'user_keep_analysis' => [],
            'user_active_analysis' => [],
            'ip_total' => []
        ];

        return $this->success(['detail' => $detail]);
    }


    /**
     * @action_doc_start
     * @action_index:fundReport
     * @action_name:资金报表(需求待确定)
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          type: 'fund', // fund 资金账变报表, game 游戏账变报表, dml 打码量报表, agent代理商佣金报表;
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          detail:{
     *          }
     *      }
     * }
     * @action_doc_end
     * TODO 资金报表
     */
    public function actionFundReport()
    {
        $type = ['fund' => '资金账变报表', 'game' => '游戏账变报表', 'dml' => '打码量报表', 'agent' => '代理商佣金报表'];

        $data = [];

        return $this->success(['list' => $data]);
    }
}
