<?php

/**
 * @module_doc_start
 * @module_name:会员分层
 * @module_type:Notice
 * @module_description:
 * @module_doc_end
 */
class UserTierController extends _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = 'UserTier';
    private $returnBet = 'UserTierReturnBet';
    private $discountModel = 'UserTierDiscountRaido';

    // 取消默认
    private function cancelDefault($filterID = 0)
    {
        $where = $filterID ? ['id' => ['<>', $filterID], 'is_default' => 1] : '';
        $model = $this->model($this->moduleModel);
        $model->_update(['is_default' => 0], $where);
    }

    private function  disables($id)
    {
        $detail = $this->model($this->moduleModel)->_detail(['id' => $id], null, 'is_default');
        if ($detail['is_default'] == 1) {
            return $this->error(1000, '默认分层不能禁用');
        }
        if ($this->model('User')->_count(['tierid' => $id])) {
            return $this->error(1002, '分层下存在用户不能禁用或删除');
        }
        return true;
    }

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          name:"层级名称",
     *          remark:"备注",
     *          is_default: 1,  // 是否默认 ，1是 0否 如果选择1 则已有默认会被取消
     *          status: 1,  // 状态：1启用 0禁用
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = (array) $this->input("post.data");

        if (empty($data))
            return $this->error(3, '参数错误');

        // 是否禁用
        if ($data['is_default'] == 1 && $data['status'] == 0) {
            return $this->error(1000, '默认分层不能禁用');
        }

        if (!isset($data['radio']) || empty($data['radio'])) {
            $this->POST['data']['radio'] = 0;
        }

        if (!isset($data['name']) || empty($data['name'])) {
            return $this->error(3, '请输入 3~8 文字');
        }

        if ($this->model($this->moduleModel)->_count(['name' => $data['name']])) {
            return $this->error(3, '分层名称已存在');
        }

        $result = parent::actionInsert();

        if (isset($result['data']) && isset($result['data']['insert_id']) && $result['data']['insert_id']) {
            if (isset($data['is_default']) && $data['is_default'] == 1) {
                $this->cancelDefault($result['data']['insert_id']);
            }
        }

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          name:"层级名称", // 必填
     *          status: 1, //状态 1启用 0禁用 必填
     *          is_default: 1, //是否默认 必填
     *          remark:"内容"
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//修改成功，返回true，失败返回false
     *          affected_rows:2,//修改的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $where = (array) $this->input('post.where');
        $data = (array) $this->input('post.data');
        if (empty($data) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        // 是否禁用
        if ($data['status'] == 0 && $data['is_default'] == 1) {
            return $this->error(1000, '默认分层不能禁用');
        }

        if (isset($data['status']) && $data['status'] == 0) {
            $disables = $this->disables($where['id']);
            if ($disables !== true) {
                return $disables;
            }
        }
        $model = $this->model($this->moduleModel);
        if ($data['status'] == 1 && $data['is_default'] == 0) {
            $detail = $model->_detail(['id' => $where['id']], null, 'is_default');
            if ($detail['is_default'] == 1) {
                return $this->error(1000, '默认分层不能编辑');
            }
        }
        if (isset($data['name']) && $model->_count(['name' => $data['name'], 'id' => ['<>', $where['id']]])) {
            return $this->error(3, '分层名称已存在');
        }

        $result = parent::actionUpdate();

        // 是否默认
        if (isset($result['data']) && isset($result['data']['affected_rows']) && $result['data']['affected_rows']) {
            if (isset($data['is_default']) && $data['is_default'] == 1) {
                $this->cancelDefault($where['id']);
            }
        }

        return $result;
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数都不是必须参数
     *          title: ['like', '%标题%'],//  标题模糊查询
     *          status: 1,// 1 启用 0停用 不设置全部
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
              "lists": [
                {
                    "id": "3",
                    "name": "层级名称",
                    "remark": "备注",
                    "status": "1",
                    "is_default": "1",
                    "create_at": "1554806152",
                    "update_at": "1554806152"
                }
              ],
               total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
               total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
            }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:1,//删除个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');

        $detail =  $this->model($this->moduleModel)->_detail(['id' => $where['id']]);

        if (empty($detail)) {
            return $this->error(1000, '分层不存在');
        }

        if ($detail['is_default'] == 1) {
            return $this->error(1002, '默认分层不允许删除');
        }
        $disables = $this->disables($where['id']);
        if ($disables !== true) {
            return $disables;
        }

        return parent::actionDelete();
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:停用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          status: 1, // 1启用 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        $where = $this->input('post.where.id');
        $status = (int) $this->input('post.data.status');
        if ($status != 1 && $status != 0)
            return $this->error(3, '参数有误');

        // 是否禁用
        if ($status == 0) {
            $disables = $this->disables($where);
            if ($disables !== true) {
                return $disables;
            }
        }

        return parent::actionChangeStatus();
    }



    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id: 1, //ID ，必须
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "detail": {
                    "id": "1",
                    "name": "一级会员",
                    "remark": "初级会员",
                    "status": "1",
                    "is_default": "0",
                    "create_at": "0",
                    "update_at": "1554807264"
                }
     *      }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $where = $this->input("post.where");
        if (!isset($where['id']) || intval($where['id']) <= 0)
            return $this->error(3, '参数有误');
        return parent::actionDetail();
    }

    /**
     * @action_doc_start
     * @action_index:returnBetSet
     * @action_name:退水设置
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          tierid: 2, // 用户分层ID
     *      },
     *      data:{
     *          radio_json:[
     *              {
     *                   'value': 'live_ag', // 编码
     *                   'label': 'AG视讯', // 游戏名称
     *                   'radio': '0.01', // 两位小数
     *              }
     *           ]
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionReturnBetSet()
    {
        $data = $this->input('post.data');
        $where = $this->input('post.where');

        if (empty($where) || $where['tierid'] < 1 || empty($data) || !is_array($data['radio_json'])) {
            return $this->error(3, '参数错误');
        }
        $checkRs = $this->checkRadioData($data['radio_json']);
        if (isset($checkRs['code'])) {
            return $checkRs;
        }
        $model = $this->model($this->returnBet);

        $_data = [
            'user_tierid' => $where['tierid'],
            'radio_json' => json_encode($checkRs)
        ];

        $ret_insert = $model->_insert($_data);
        if ($ret_insert === FALSE) {
            return $this->error('修改失败，请重试！');
        }
        $ret = array(
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "insert_id" => (int) $ret_insert
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:returnBetGet
     * @action_name:退水数据
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          tierid: 2, // 代理商分层ID
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "radio_data": [
                    {
                    "value": "live_ag",
                    "label": "AG视讯",
                    "radio": 0.01
                    },
                ]
     *      }
     * }
     * @action_doc_end
     */
    public function actionReturnBetGet()
    {
        $where = $this->input('post.where');
        if (empty($where) || $where['tierid'] < 1) {
            return $this->error(3, '参数错误');
        }

        $model = $this->model($this->returnBet);
        $data = $model->_lists(['user_tierid' => $where['tierid']], 'id desc', 1, 0, 'radio_json');

        if (empty($data)) {
            $returnData = $this->setRaidoData('');
        } else {
            $returnData = $this->setRaidoData($data[0]['radio_json']);
        }

        return $this->success(['radio_data' => $returnData]);
    }

    private function setRaidoData($redioData)
    {
        $gameList =  (new Game())->getTypeData('list');
        if (empty($redioData)) {
            $redioData = [];
            foreach ($gameList as $value) {
                $redioData[] = [
                    'value' => $value['value'],
                    'label' => $value['label'] . '有效投注',
                    'radio' => 0
                ];
            }
            return $redioData;
        }

        $tempGameList = json_decode($redioData, true);
        $codeList = array_column($tempGameList, 'value');
        foreach ($gameList as $value) {
            // 新添加平台的话就需要添加对应的比例
            if (!in_array($value['value'], $codeList)) {
                $tempGameList[] = [
                    'value' => $value['value'],
                    'label' => $value['label'] . '有效投注',
                    'radio' => ''
                ];
            }
        }
        return $tempGameList;
    }

    private function checkRadioData($radioData)
    {
        $codeList = array_column($radioData, 'value');

        foreach ($radioData as $key => $value) {
            if (isset($value['value']) &&  !isset($value['radio'])) {
                $radioData[$key]['radio'] = 0;
            }
        }

        $gameList = $list =  (new Game())->getTypeData('list');
        $gameCodeList = array_column($gameList, 'value');

        foreach ($radioData as $key => $value) {
            if (!in_array($value['value'], $gameCodeList)) {
                return $this->error(3, $value['radio'] . '未知或已被禁用');
            }
            $radioData[$key]['radio'] = floatval(number_format($value['radio'], 2,".",""));
            if ($value['radio'] != $radioData[$key]['radio']) {
                return $this->error(3, $value['label'] . '比例输入有误');
            }
            if ($value['radio'] > 100 || $value['radio'] < 0) {
                return $this->error(3, '仅支持输入 0~100 之间的正数，支持 2 位小数');
            }
        }

        // 新添加平台的话就需要添加对应的比例
        foreach ($gameList as $value) {
            if (!in_array($value['value'], $codeList)) {
                $radioData[] = [
                    'value' => $value['value'],
                    'label' => $value['label'],
                    'radio' => 0
                ];
            }
        }

        return $radioData;
    }

    /**
     * @action_doc_start
     * @action_index:setDiscount
     * @action_name:重新设置优惠比例（如果未修改请不要调用此接口）
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          tierid: 1, // 用户分层ID
     *      },
     *      data: {
     *          raido: 0.01, // 优惠比例
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//设置成功，返回true，失败返回false
     *          insert_id:2, // 新设置成功的ID
     *      }
     * }
     * @action_doc_end
     */
    public function actionSetDiscount()
    {
        $where = (array) $this->input('post.where');
        $data = (array) $this->input('post.data');
        if (empty($data) || empty($where) || !isset($where['tierid'])) {
            return $this->error(3, '参数错误');
        }

        if ($where['tierid'] <= 0) {
            $this->error('3', '请选择用户分层');
        }
        if (!isset($data['raido']) || ($data['raido'] > 100 && $data['raido'] < 0)) {
            $this->error('3', '仅支持输入 0~100 之间的正数及 2 位小数');
        }

        $model = $this->model($this->discountModel);

        $_data = [
            'user_tierid' => $where['tierid'],
            'radio' => $data['raido'],
            'status' => 1,
        ];
        $ret_insert = $model->_insert($_data);

        if ($ret_insert !== false) {
            $model->_update(['status' => 0], ['id' => ['<>', $ret_insert]]);
            return $this->success(['status' => true, 'insert_id' => intval( $ret_insert ) ]);
        } else {
            return  $this->error('添加失败，请重试！');
        }
    }

    /**
     * @action_doc_start
     * @action_index:getDiscount
     * @action_name:获取当前优惠设置
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          tierid: 1, // 用户分层ID
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
                radio: "0.01" //当前使用的设置优惠比例
     *      }
     * }
     * @action_doc_end
     */
    public function actionGetDiscount()
    {
        $where = (array) $this->input('post.where');

        if (empty($where) || !isset($where['tierid'])) {
            return $this->error(3, '参数错误');
        }

        $list = $this->model($this->discountModel)->_lists(['user_tierid' => $where['tierid']], 'id desc', 1, 0, 'radio');

        if (empty($list)) {
            $detail = [];
        } else {
            $detail = $list[0];
        }

        return $this->success($detail);
    }


}
