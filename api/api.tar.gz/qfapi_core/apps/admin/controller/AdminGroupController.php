<?php

/**
 * @module_doc_start
 * @module_name:后台管理员分组
 * @module_model:AdminGroup
 * @module_description:
 * @module_doc_end
 */
class AdminGroupController extends _AdminController {

    public $needCheckAccess = true;
    protected $moduleModel = "AdminGroup";

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:管理员分组新增
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          name:"系统管理员",//分组名称
     *          actions:",*,",//分组名称
     *          status:1,//分组状态，-1:删除，0：待审核，1：正常，2：禁用
     *          remark:"",//备注
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//新增成功，返回true，失败返回false
     *          affected_rows:2,//增加个数，例如一次性新增了3个管理员信息
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert() {
        //参数验证
        $name = "";
        if (!$this->validate("notempty", "post.data.name", $name)) {
            return $this->error(3, "请输入角色名称");
        }

        //查看分组名称是否存在
        $admin_group = $this->model($this->moduleModel)->_detail(["name" => $name]);
        if ($admin_group) {
            return $this->error("角色名称已存在");
        }

        $ret = parent::actionInsert();
        if($ret["code"]==0){
            $this->reflushAppGroupRoutes(true);
        }
        
        return $ret;
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:管理员分组列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *          //create_time:["between",['2019-12-12 12:12:12','2019-12-13 12:12:12']],
     *          //id:[">",100],
     *          name:["like","%系统%"]
     *      },
     *      attr:"id,name,status,remark",//需要显示的对象属性，可以为字符串，也可以是数组
     *      need_total:true/false,//是否需要统计总量
     *      offset:0,//偏移量
     *      page:1,//分页
     *      page_size:10,//分页大小：默认10
     *      order:"id desc",//排序，默认id 倒序，规则为：字段+空格+“desc/asc”
     *      
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          lists:[
     *              {
     *                  id:1,//分组id
     *                  name:"系统管理员",//分组名称
     *                  status:1,//分组状态，-1:删除，0：待审核，1：正常，2：禁用
     *                  remark:"",//备注
     *              }
     *          ],
     *          total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
     *          total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
     *      }
     * }
     * @action_doc_end
     */
    public function actionLists() {
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:管理员分组编辑
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]]
     *      },
     *      data:{//未修改数据即可不传
     *          name:"系统管理员",//分组名称
     *          status:1,//分组状态，-1:删除，0：待审核，1：正常，2：禁用
     *          remark:"",//备注
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//修改成功，返回true，失败返回false
     *          affected_rows:2,//修改个数，例如一次性修改了3个管理员信息
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate() {
        $id = $this->input("post.where.id");
        $name = $this->input("post.data.name");
        //检查角色名称是否重复
        if ($name) {
            $group = $this->model($this->moduleModel)->_detail(["id" => ["<>", $id], "status" => ["<>", -1], "name" => $name]);
            if ($group) {
                return $this->error("角色名称已存在");
            }
        }

        $ret = parent::actionUpdate();
        
        if ($ret["code"] == 0 && $this->input("post.data.actions", null) !== null) {
            $this->reflushAppGroupRoutes(true);
        }
        
        return $ret;
    }

    /**
     * @action_doc_start
     * @action_index:delete
     * @action_name:管理员分组删除
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]]
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除个数，例如一次性删除了3个管理员信息
     *      }
     * }
     * @action_doc_end
     */
    public function actionDelete() {
        $ret = parent::actionDelete();
        if ($ret["code"] == 0) {
            $this->reflushAppGroupRoutes(true);
        }
        return $ret;
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用管理员分组
     * @action_description:
     * 请求参数：
     * {
     *      where:{
     *          id:1,//id:[1,2,3]
     *      },
     *      data:{
     *          status:0,//-1：逻辑删除，0：待审核，1：正常，2：禁止
     *          remark:""//状态备注
     *      }
     * }
     * 返回值：
     * {
     *      code:0,
     *      msg:'',
     *      data:{
     *          status:true,//状态修改是否成功，true:成功，false：失败
     *          affected_rows:1//影响记录数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus() {
        $id = $this->input("post.where.id", null);
        if ($id === null) {
            return $this->error(3, "状态修改必须提供id");
        }

        $ret = parent::actionChangeStatus();
        if($ret["code"]==0){
            $this->reflushAppGroupRoutes(true);
        }
        return $ret;
    }

}
