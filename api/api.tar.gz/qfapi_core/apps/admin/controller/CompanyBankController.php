<?php

/**
 * @module_doc_start
 * @module_name:公司银行卡管理
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class CompanyBankController extends _AdminController
{

    public $needCheckAccess = true;
    protected $moduleModel = 'PayCompanyBank';

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * 请求参数:
     * {
     *      data: {
     *          bank: 'ICBC', // 银行编号
     *          realname: '姓名',
     *          cardno: '银行卡号',
     *          address: '开户行地址',
     *          single_limit_max: 100, // 单笔限额上限
     *          single_limit_min: 10, // 单笔限额下限
     *          day_limit_max: 1000.55, // 单日限额（当天累计收款达到后将停止展示）
     *          user_tier: [1,2,3], // 会员分层
     *          status: 1 //状态 1正常 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
                "status": true,
                "insert_id": 9
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {
        $data = $this->input('post.data');
        if (empty($data)) {
            $this->error(3, '参数错误');
        }
        if (!empty($data['user_tier']) && is_array($data['user_tier'])) {
            $data['user_tier'] = implode(',', $data['user_tier']);
        }
        $temp = array_column(Pay::$bankData, 'name','bank');
        if (empty($data['bank']) || !isset($temp[$data['bank']])) {
            return $this->error(3, '不支持此银行');
        }
        $data['bank_name'] = $temp[$data['bank']];
        $data['admin_id'] = $this->member['id'];
        $data['admin_name'] = $this->member['name'];
        $this->POST['data'] = $data;

        return parent::actionInsert();
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:列表
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          bank: ['in', 'ICBC,ABC'], // 银行 ICBC,ABC中间不能有空格
     *          status: 1, // 状态 1正常 0 警用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
     *          "lists": [
                    {
                        "id": "3",
                        "bank_name": "中国工商银行",
                        "cardno": "银行卡号",
                        "bank": "ICBC",
                        "realname": "姓名",
                        "address": "开户行地址",
                        "single_limit_max": "100.00",
                        "single_limit_min": "10.00",
                        "day_limit_max": "1000.55",
                        "user_tier": [1,2,3],
                        "admin_id": "20",
                        "admin_name": "meak",
                        "status": "1",
                        "create_at": "1556174165",
                        "update_at": "1556174165",
                        "user_tier_name": "abc、二级会员"
                    },
               ],
                "user_tier": [
                    {
                    "id": "1",
                    "name": "abc",
                    "status": "1",
                    "is_default": "0"
                    }
                ],

     *      }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        $returnData = parent::actionLists();

        $userTier = $this->model('UserTier')->_lists([], null, null, null, 'id, name, status, is_default');

        $returnData['data']['bank'] = Pay::$bankData;
        $returnData['data']['user_tier'] = $userTier;

        $temp3 = [];
        foreach ($userTier as $value) {
            $temp3[$value['id']] = $value['name'];
        }

        foreach ($returnData['data']['lists'] as $key => $value) {
            $user_tier_name = '';
            if ($value['user_tier']) {
                $temp = [];
                $value['user_tier'] = explode(',', $value['user_tier']);
                foreach ($value['user_tier'] as $iV) {
                    if (isset($temp3[$iV])) {
                        $temp[] = $temp3[$iV];
                    }
                }
                $user_tier_name = $temp ? implode('、', $temp) : '';
                $returnData['data']['lists'][$key]['user_tier'] = $value['user_tier'];
            }
            $returnData['data']['lists'][$key]['user_tier_name'] = $user_tier_name;
        }

        return $returnData;
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 8
     *      },
     *      data: {
     *          bank: 'ICBC', // 银行编号
     *          realname: '姓名',
     *          cardno: '银行卡号',
     *          address: '开户行地址',
     *          single_limit_max: 100, // 单笔限额上限
     *          single_limit_min: 10, // 单笔限额下限
     *          day_limit_max: 1000.55, // 单日限额（当天累计收款达到后将停止展示）
     *          user_tier: [1,2,3], // 会员分层
     *          status: 1 //状态 1正常 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
                "status": true,
                "affected_rows": 1
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $data = $this->input('post.data');
        if (empty($data)) {
            $this->error(3, '参数错误');
        }
        if (!empty($data['user_tier']) && is_array($data['user_tier'])) {
            $data['user_tier'] = implode(',', $data['user_tier']);
        }
        $temp = array_column(Pay::$bankData, 'name','bank');
        if (!empty($data['bank']) && isset($temp[$data['bank']])) {
            $data['bank_name'] = $temp[$data['bank']];
        }
        $data['admin_id'] = $this->member['id'];
        $data['admin_name'] = $this->member['name'];
        $this->POST['data'] = $data;

        return parent::actionUpdate();
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:禁用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *          //id:["in",[1,2,3]],
     *      },
     *      data:{
     *          status: 0, // 状态 1正常 0禁用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//成功，返回true，失败返回false
     *          affected_rows:1,//
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        return parent::actionChangeStatus();
    }


    /**
     * @action_doc_start
     * @action_index:detail
     * @action_name:详情
     * @action_description:
     * 请求参数:
     * {
     *      where: {
     *          id: 1
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{ // 为空则不设置
              "detail": {
                "id": "1",
                "bank_name": "兴业银行",
                "cardno": "6666 6666 6666 666",
                "bank": "CIB",
                "realname": "姓名",
                "address": "兴业银行CIB",
                "single_limit_max": "100.00",
                "single_limit_min": "10.00",
                "day_limit_max": "1000.55",
                "user_tier": [
                "1",
                "2",
                "3"
                ],
                "admin_id": "80",
                "admin_name": "vivian",
                "status": "1",
                "create_at": "1556174162",
                "update_at": "1556191628"
              }
     *  }
     * }
     * @action_doc_end
     */
    public function actionDetail()
    {
        $returnData = parent::actionDetail();

        if ($returnData['data']['detail']) {
            if ($returnData['data']['detail']['user_tier'])
                $returnData['data']['detail']['user_tier'] = explode(',', $returnData['data']['detail']['user_tier']);
            else
                $returnData['data']['detail']['user_tier'] = [];

            if ($returnData['data']['detail']['client_type'])
                $returnData['data']['detail']['client_type'] = explode(',', $returnData['data']['detail']['client_type']);
            else
                $returnData['data']['detail']['client_type'] = [];
        }

        return $returnData;
    }


}
