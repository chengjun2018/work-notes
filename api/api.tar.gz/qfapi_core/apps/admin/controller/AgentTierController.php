<?php

/**
 * @module_doc_start
 * @module_name:代理分层
 * @module_type:AgentTier
 * @module_description:
 * @module_doc_end
 */
class AgentTierController extends _AdminController
{

    public $needCheckAccess = true;
    protected $moduleModel = 'AgentTier';

    private function setTierData()
    {
        $data = (array)$this->input("post.data");
        $data = array_map('trim', $data);
        if (empty($data))
            return $this->error(3, '参数错误');

        if (!isset($data['name']) || preg_match('/^\s*$/', $data['name']) || mb_strlen($data['name']) > 8)
            return $this->error(3, '请输入 1~8 文字');

        if (isset($data['remark']) && !preg_match('/^\s*$/', $data['remark']) && mb_strlen($data['remark']) > 10)
            return $this->error(3, '最多输入 10 位字符');

        if (isset($data['status']) && ($data['status'] != 1 && $data['status'] != 0))
            return $this->error(3, '请设置状态为启用或者禁用');

        $this->POST['data'] = $data;

        return true;
    }

    /**
     * @action_doc_start
     * @action_index:insert
     * @action_name:添加
     * @action_description:
     * 请求参数:
     * {
     *      data:{
     *          name:"层级名称",
     *          remark:"备注",
     *          status: 1,  // 状态 0 禁用 1启用 默认1
     *      }
     * }
     * 
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true,//添加成功，返回true，失败返回false
     *          insert_id:12866,//插入的id
     *      }
     * }
     * @action_doc_end
     */
    public function actionInsert()
    {

        $data = $this->setTierData();

        if ($data !== true) {
            return $data;
        }

        $data = $this->input('post.data');

        $model = $this->model($this->moduleModel);

        if (!isset($data['name']) || empty($data['name'])) {
            return $this->error(3, '请输入 1~8 文字');
        }

        if ($model->_count(['name' => $data['name']])) {
            return $this->error(3, '分层名称已存在');
        }

        if ($model->_count(['is_default' => 1])) {
            $data['is_default'] = 0;
        } else {
            $data['is_default'] = 1;
        }

        $ret_insert = $model->_insert($data);
        $ret = array(
            "status" => $ret_insert === FALSE ? FALSE : TRUE,
            "insert_id" => (int) $ret_insert
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:update
     * @action_name:修改
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:6,
     *      },
     *      data: {
     *          name:"层级名称",
     *          remark:"内容",
     *          status: 1
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//删除成功，返回true，失败返回false
     *          affected_rows:2,//删除的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionUpdate()
    {
        $where = (array) $this->input('post.where');
        if (empty($where) || intval($where['id']) <= 0)
            return $this->error(3, '参数错误');

        $data = $this->setTierData();

        if ($data !== true) {
            return $data;
        }

        $data = (array) $this->input('post.data');
        $model = $this->model($this->moduleModel);

        $detail = $model->_detail(['id' => $where['id']]);

        if (empty($detail)) {
            return $this->error(1000, '分层不存在');
        }

        if (isset($data['name']) && $model->_count(['name' => $data['name'], 'id' => ['<>', $where['id']]])) {
            return $this->error(3, '分层名称已存在');
        }

        if ($detail['is_default'] == 1) {
            return $this->error(1002, '默认分层不允许修改');
        }

        if ($data['status'] == 0) {
            if ($this->model('Agent')->_count(['tierid' => $where['id']])) {
                return $this->error(1002, '分层下存在代理商不能禁用');
            }
        }

        $_data = [
            'name' => $data['name'],
            'remark' => $data['remark'],
            'status' => $data['status']
        ];

        $ret_update = $model->_update($_data, $where);
        $ret = array(
            "status" => $ret_update === FALSE ? FALSE : TRUE,
            "affected_rows" => (int) $ret_update
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:lists
     * @action_name:列表
     * @action_description:
     * 请求参数:
     * {
     *      where:{ // 以下参数都不是必须参数
     *          title: '标题',//  标题查询
     *          status: '',//  状态 ''全选 0禁用 1启用 不设置或''为全选
     *      },
     *      page_size: 10, // 每页记录条数 默认10
     *      page: 1, // 每页记录条数 默认1 第一页
     *      need_total: 1,//是否需要统计总量 1是 0不需要
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
              "lists": [
                {
                    "id": "3",
                    "name": "层级名称",
                    "remark": "备注",
                    "status": "1",
                    "is_default": "1",
                    "create_at": "1554806152",
                    "update_at": "1554806152"
                }
              ],
               total_num:10,//总结记录数，如果请求参数中need_total=true将返回该值
               total_page:12,//总计分页数，如果请求参数中need_total=true将返回该值
            }
     * }
     * @action_doc_end
     */
    public function actionLists()
    {
        return parent::actionLists();
    }

    /**
     * @action_doc_start
     * @action_index:changeStatus
     * @action_name:停用/启用
     * @action_description:
     * 请求参数:
     * {
     *      where:{
     *          id:12,
     *      },
     *      data:{
     *          status: 1, // 1启用 0停用
     *      }
     * }
     *
     * 返回数据：
     * {
     *      code:0,
     *      msg:"",
     *      data:{
     *          status:true/false,//更新成功，返回true，失败返回false
     *          affected_rows:1,//更新的个数
     *      }
     * }
     * @action_doc_end
     */
    public function actionChangeStatus()
    {
        $where = $this->input('post.where');
        $status = (int) $this->input('post.data.status');
        if ($status != 1 && $status != 0 && empty($where['id']))
            return $this->error(3, '参数有误');

        // 是否禁用
        if ($status == 0) {
            $detail = $this->model($this->moduleModel)->_detail(['id' => $where['id']], null, 'is_default');
            if ($detail['is_default'] == 1) {
                return $this->error(1000, '默认分层不能禁用');
            }
        }

        return parent::actionChangeStatus();
    }


}
