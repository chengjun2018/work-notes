<?php

namespace Model;

/**
 # 模型解释 start：

模型名：Agent
表明：agent
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | username             | varchar(11)          | NO   | UNI  |              | 代理账号 5~11位字母数字或组合               |
  | password             | char(32)             | NO   |      |              |                                                  |
  | realname             | varchar(5)           | NO   |      |              | 真实姓名                                         |
  | rmd_code             | char(6)              | NO   | UNI  |              | 推荐码                                           |
  | tierid               | int(10) unsigned     | NO   |      | 0           | 层级ID                                         |
  | domain               | varchar(255)         | NO   |      |              | 代理商域名                                       |
  | pid                  | int(10) unsigned     | NO   |      | 0           | 上级ID                                         |
  | phone                | char(11)             | NO   |      |              | 手机号                                           |
  | email                | varchar(50)          | NO   |      |              |                                                  |
  | qq                   | varchar(20)          | NO   |      |              |                                                  |
  | cardno               | varchar(20)          | NO   |      |              | 银行卡号                                         |
  | bank_name            | varchar(15)          | NO   |      |              | 开户行                                           |
  | remark               | varchar(100)         | NO   |      |              | 备注                                             |
  | status               | tinyint(1) unsigned  | NO   |      | 1           | 状态：1正常 2锁定                             |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：代理商

# 模型解释 end：
*/
class Agent extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "agent";//表名

}

?>