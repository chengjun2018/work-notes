<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserTransfer
表明：user_transfer
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(11) unsigned     | NO   | PRI  |              |                                                  |
  | userid               | int(11) unsigned     | NO   |      |              | 用户ID                                         |
  | username             | char(20)             | NO   |      |              | 用户名                                           |
  | order_id             | char(20)             | NO   |      |              | 统一订单号，平台之间转账，转入转出拥有相同的订单号 |
  | third_order_id       | varchar(30)          | NO   |      |              | 第三方订单号                                     |
  | platform_from        | char(20)             | NO   |      |              | 转入方                                           |
  | platform_to          | char(20)             | NO   |      |              | 转出方                                           |
  | amount               | decimal(8,2)         | NO   |      | 0.00     | 转账金额                                         |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 转账时间                                         |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | status               | tinyint(1)           | NO   |      | 1           | 0：失败，1：处理中，2：完成                   |
  | remark               | varchar(255)         | NO   |      |              |                                                  |
  | type                 | tinyint(1) unsigned  | NO   |      | 0           | 0：普通，1：闪入，2.闪出                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户转账表

# 模型解释 end：
*/
class UserTransfer extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_transfer";//表名

}

?>