<?php

namespace Model;

/**
 # 模型解释 start：

模型名：PayQrcode
表明：pay_qrcode
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | pay_code             | varchar(20)          | NO   |      |              | 支付code                                     |
  | pay_name             | varchar(50)          | NO   |      |              | 支付名称                                         |
  | pay_username         | varchar(50)          | NO   |      |              | 账号                                             |
  | pay_realname         | varchar(10)          | NO   |      |              | 姓名                                             |
  | qrcode_path          | varchar(255)         | NO   |      |              | 二维码路径                                       |
  | qrcode_name          | varchar(100)         | NO   |      |              | 会员分层                                         |
  | single_limit_max     | int(10) unsigned     | NO   |      | 0           | 单笔最大额度                                     |
  | single_limit_min     | int(10) unsigned     | NO   |      | 0           | 单笔最小额度                                     |
  | day_limit_max        | int(10) unsigned     | NO   |      | 0           | 单日最大额度                                     |
  | user_tier            | varchar(255)         | NO   |      |              | 用户分层                                         |
  | remark               | varchar(255)         | NO   |      |              | 描述                                             |
  | admin_id             | int(10) unsigned     | NO   |      | 0           | 管理员ID                                       |
  | admin_name           | varchar(30)          | NO   |      |              | 管理员账号                                       |
  | status               | tinyint(1)           | NO   |      | 1           | 状态：1正常 0禁用                             |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：支付二维码

# 模型解释 end：
*/
class PayQrcode extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "pay_qrcode";//表名

}

?>