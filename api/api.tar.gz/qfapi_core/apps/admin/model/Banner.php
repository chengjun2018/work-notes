<?php

namespace Model;

/**
 # 模型解释 start：

模型名：Banner
表明：banner
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | path                 | varchar(255)         | NO   |      |              | 图片地址                                         |
  | title                | varchar(50)          | NO   |      |              | 图片标识                                         |
  | status               | tinyint(1)           | NO   |      | 1           | 1启用 0禁用 -1删除                         |
  | sort                 | int(4) unsigned      | NO   |      | 0           | 排序                                             |
  | type                 | tinyint(1) unsigned  | NO   |      |              | 1.PC 2.H5                               |
  | position             | tinyint(1) unsigned  | NO   |      |              | 1首页轮播 2首页左弹窗 3首页右弹窗 4游戏入口 5优惠活动轮播 6热门推荐轮播 7活动宣传轮播 |
  | href                 | varchar(255)         | NO   |      |              | 链接                                             |
  | jsondata             | text                 | YES  |      |              | 当type=4的时候才会有此数据 

json格式'{"position":1,"type":1,"game":"","gamechild":""}'

position：配置区域
type：1第三方游戏大厅 2平台游戏列表
game：游戏类型
gamechild：游戏平台ID   或者跳转链接 |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 记录创建时间                                     |
  | update_at            | int(10) unsigned     | NO   |      | 0           | 记录更新时间                                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：banner表

# 模型解释 end：
*/
class Banner extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "banner";//表名

}

?>