<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserInOutConfig
表明：user_in_out_config
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | in_discount_radio    | decimal(10,2) unsigned | NO   |      | 0.00     | 公司入款优惠比例                                 |
  | in_give_bet_radio    | decimal(10,2) unsigned | NO   |      | 0.00     | 公司入款赠送彩金比例                             |
  | in_give_bet_limit    | int(10) unsigned     | NO   |      | 0           | 公司入款赠送彩金上限                             |
  | in_dml_raido         | decimal(10,2) unsigned | NO   |      | 0.00     | 公司入款打码量倍率（流水要求）                   |
  | out_free_count       | int(10) unsigned     | NO   |      | 0           | 免费取款次数                                     |
  | out_fee              | decimal(10,2) unsigned | NO   |      | 0.00     | 取款手续费                                       |
  | out_fee_force_radio  | decimal(10,2) unsigned | NO   |      | 0.00     | 强制取款手续费比例                               |
  | out_fee_xz           | decimal(10,2) unsigned | NO   |      | 0.00     | 取款行政费                                       |
  | admin_id             | int(10) unsigned     | NO   |      | 0           | 管理员ID                                       |
  | status               | tinyint(1)           | NO   |      | 1           | 状态 -1无效 0即将失效 1正常               |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户存取款配置

# 模型解释 end：
*/
class UserInOutConfig extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_in_out_config";//表名

}

?>