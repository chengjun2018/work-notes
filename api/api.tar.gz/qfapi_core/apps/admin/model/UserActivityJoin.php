<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserActivityJoin
表明：user_activity_join
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | userid               | int(10) unsigned     | NO   |      |              |                                                  |
  | username             | varchar(20)          | NO   |      |              |                                                  |
  | activityid           | int(10) unsigned     | NO   |      |              | 活动ID                                         |
  | adminid              | int(10) unsigned     | NO   |      | 0           | 审核管理员                                       |
  | adminname            | varchar(20)          | NO   |      |              | 管理员名称                                       |
  | status               | tinyint(1)           | NO   |      | 0           | 审核状态：0未审核  1审核通过 2未通过 -1删除 |
  | check_time           | int(10) unsigned     | NO   |      | 0           | 审核时间                                         |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 记录创建时间                                     |
  | update_at            | int(10) unsigned     | NO   |      | 0           | 记录更新时间                                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户加入活动

# 模型解释 end：
*/
class UserActivityJoin extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_activity_join";//表名

}

?>