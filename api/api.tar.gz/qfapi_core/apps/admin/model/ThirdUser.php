<?php

namespace Model;

/**
 # 模型解释 start：

模型名：ThirdUser
表明：third_user
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | userid               | int(10) unsigned     | NO   | UNI  |              |                                                  |
  | username             | varchar(20)          | NO   |      |              |                                                  |
  | ag_user              | varchar(20)          | NO   |      |              | AG账号                                         |
  | ag_pwd               | char(6)              | NO   |      | 0           | AG密码                                         |
  | pt_user              | varchar(20)          | NO   |      |              | PT账号                                         |
  | pt_pwd               | char(6)              | NO   |      | 0           | PT密码                                         |
  | ky_user              | varchar(20)          | NO   |      |              | KY账号                                         |
  | mg_user              | varchar(20)          | NO   |      |              | MG账号                                         |
  | mg_pwd               | char(6)              | NO   |      | 0           | MG密码                                         |
  | status               | tinyint(1)           | NO   |      | 1           | 状态：1启用 -1删除                           |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 记录创建时间                                     |
  | update_at            | int(10) unsigned     | NO   |      | 0           | 记录更新时间                                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：第三方用户信息

# 模型解释 end：
*/
class ThirdUser extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "third_user";//表名

}

?>