<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserFundflow
表明：user_fundflow
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | userid               | int(10) unsigned     | NO   | MUL  | 0           | 用户ID                                         |
  | type                 | int(4) unsigned      | NO   |      | 0           | 变动类型                                         |
  | before_ablebalance   | decimal(10,4)        | NO   |      | 0.0000 | 变动前可用余额                                   |
  | before_frozenbalance | decimal(10,4)        | NO   |      | 0.0000 | 变动前冻结余额                                   |
  | before_balance       | decimal(10,4)        | NO   |      | 0.0000 | 变动前余额                                       |
  | after_ablebalance    | decimal(10,4)        | NO   |      | 0.0000 | 变动后可用余额                                   |
  | after_frozenbalance  | decimal(10,4)        | NO   |      | 0.0000 | 变动后冻结余额                                   |
  | after_balance        | decimal(10,4)        | NO   |      | 0.0000 | 变动后余额                                       |
  | money                | decimal(10,4) unsigned | NO   |      | 0.0000 | 变动金额                                         |
  | create_at            | int(10) unsigned     | NO   | MUL  | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：资金流水表

# 模型解释 end：
*/
class UserFundflow extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_fundflow";//表名

}

?>