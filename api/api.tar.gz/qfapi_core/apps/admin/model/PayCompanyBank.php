<?php

namespace Model;

/**
 # 模型解释 start：

模型名：PayCompanyBank
表明：pay_company_bank
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | bank_name            | varchar(30)          | NO   |      |              | 银行名称                                         |
  | cardno               | varchar(20)          | NO   |      |              | 银行卡号                                         |
  | bank                 | varchar(10)          | NO   |      |              | 银行缩写                                         |
  | realname             | varchar(10)          | NO   |      |              | 姓名                                             |
  | address              | varchar(255)         | NO   |      |              | 开户行地址                                       |
  | single_limit_max     | decimal(10,2) unsigned | NO   |      | 0.00     | 单笔最高金额                                     |
  | single_limit_min     | decimal(10,2) unsigned | NO   |      | 0.00     | 单笔最低金额                                     |
  | day_limit_max        | decimal(10,2) unsigned | NO   |      | 0.00     | 单日最高金额                                     |
  | user_tier            | varchar(255)         | NO   |      |              | 用户分层                                         |
  | admin_id             | int(10) unsigned     | NO   |      | 0           |                                                  |
  | admin_name           | varchar(255)         | NO   |      |              |                                                  |
  | status               | tinyint(1) unsigned  | NO   |      | 1           | 状态：1正常 0禁用                             |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：公司银行卡

# 模型解释 end：
*/
class PayCompanyBank extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "pay_company_bank";//表名

}

?>