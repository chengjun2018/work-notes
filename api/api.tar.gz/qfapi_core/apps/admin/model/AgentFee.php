<?php

namespace Model;

/**
 # 模型解释 start：

模型名：AgentFee
表明：agent_fee
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | xz_fee_raido         | decimal(5,2) unsigned | NO   |      | 0.00     | 行政费                                           |
  | in_fee_raido         | decimal(5,2) unsigned | NO   |      | 0.00     | 入款手续费                                       |
  | in_fee_limit         | int(10) unsigned     | NO   |      | 0           | 入款手续费上限                                   |
  | out_fee_radio        | decimal(5,2) unsigned | NO   |      | 0.00     | 出款手续费                                       |
  | out_fee_limit        | int(10) unsigned     | NO   |      | 0           | 出款手续费上限                                   |
  | share_return_bet_radio | decimal(5,2) unsigned | NO   |      | 0.00     | 分摊会员返水费用                                 |
  | share_give_fee_radio | decimal(5,2) unsigned | NO   |      | 0.00     | 均摊会员优惠赠送费用                             |
  | status               | tinyint(1) unsigned  | NO   |      | 1           |                                                  |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 1           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：

# 模型解释 end：
*/
class AgentFee extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "agent_fee";//表名

}

?>