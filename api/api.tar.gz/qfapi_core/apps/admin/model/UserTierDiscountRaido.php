<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserTierDiscountRaido
表明：user_tier_discount_raido
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | user_tierid          | int(10) unsigned     | NO   |      | 0           |                                                  |
  | radio                | decimal(5,2) unsigned | NO   |      | 0.00     | 比例 0-100 的两位小数                     |
  | status               | tinyint(1) unsigned  | NO   |      | 1           | 状态 1正常                                     |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：会员优惠比例

# 模型解释 end：
*/
class UserTierDiscountRaido extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_tier_discount_raido";//表名

}

?>