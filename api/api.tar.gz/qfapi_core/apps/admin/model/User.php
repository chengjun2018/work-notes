<?php

namespace Model;

/**
 # 模型解释 start：

模型名：User
表明：user
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10)              | NO   | PRI  |              |                                                  |
  | realname             | varchar(20)          | NO   |      |              | 真实姓名                                         |
  | password             | char(32)             | NO   |      |              | 密码                                             |
  | username             | varchar(20)          | NO   | UNI  |              | 账号                                             |
  | tierid               | int(10) unsigned     | NO   |      | 1           | 会员层级ID                                     |
  | tag                  | tinyint(1) unsigned  | NO   |      | 0           | 用户标签：1真人 2电子 3棋牌 4体育 5彩票 |
  | phone                | char(11)             | NO   | UNI  |              | 手机号                                           |
  | out_password         | char(32)             | NO   |      |              | 取款密码                                         |
  | remark               | varchar(255)         | NO   |      |              | 备注                                             |
  | mast_dml             | decimal(10,4) unsigned | NO   |      | 0.0000 | 要求打码量                                       |
  | reg_device           | varchar(20)          | NO   |      |              | 注册设备类型：pc|h5|ios|android |
  | reg_ip               | varchar(15)          | NO   |      |              | 注册ip地址                                     |
  | reg_source           | varchar(255)         | NO   |      |              | 注册来源 域名                                   |
  | agent_id             | int(10) unsigned     | NO   |      | 0           | 推荐人iD                                       |
  | email                | varchar(50)          | NO   |      |              | 绑定email                                   |
  | wechat               | varchar(50)          | NO   |      |              | 微信号                                           |
  | domain               | varchar(255)         | NO   |      |              | 最后登录域名                                     |
  | is_enable            | tinyint(1) unsigned  | NO   |      | 0           | 是否禁用 1禁用 0启用                         |
  | status               | tinyint(1)           | NO   |      | 1           | 状态：1正常 2锁定 -1删除                   |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 记录创建时间                                     |
  | update_at            | int(10) unsigned     | NO   |      | 0           | 记录更新时间                                     |
  | last_login_ip        | varchar(15)          | NO   |      |              | 最后一次登录IP                                 |
  | last_login_time      | int(10) unsigned     | NO   |      | 0           | 最后一次登录时间                                 |
  | sc_login_time        | int(10) unsigned     | NO   |      | 0           | 上次登录时间                                     |
  | sc_login_ip          | varchar(15)          | NO   |      |              | 上次登录IP                                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户|agent表

# 模型解释 end：
*/
class User extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user";//表名

    /**
     * 关联数据
     */
    public $field = array(
        "_fund"=>array(
            "data_model"=>"user_fund",//"Agent"
            "data_type"=>"one",//one/lists/detail/max/min/sum/avg/count
            "where"=>"@irow.id=user_fund.userid",//(@irow.([a-z_]+))
            "field"=> 'ablebalance,frozenbalance,balance,score,handsel,dml',
//            "cache_time"=>10,//以防止并发和及时有效为标准，一般设置为
//            "limit"=>1
        )
    );

}

?>