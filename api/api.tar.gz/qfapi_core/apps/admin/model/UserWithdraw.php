<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserWithdraw
表明：user_withdraw
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | money                | decimal(10,4) unsigned | NO   |      |              | 提款金额                                         |
  | userid               | int(10) unsigned     | NO   |      |              |                                                  |
  | username             | varchar(20)          | NO   |      |              |                                                  |
  | tiername             | varchar(20)          | NO   |      |              | 层级名称                                         |
  | agentid              | int(10) unsigned     | NO   |      |              | 代理ID                                         |
  | agentname            | varchar(20)          | NO   |      |              | 代理名称                                         |
  | bankid               | int(10) unsigned     | NO   |      |              | 银行ID                                         |
  | mast_dml             | decimal(10,4) unsigned | NO   |      |              | 要求打码量                                       |
  | finish_dml           | decimal(10,4) unsigned | NO   |      |              | 完成打码量                                       |
  | number               | int(6) unsigned      | NO   |      |              | 总次数                                           |
  | order_no             | varchar(20)          | NO   |      |              | 编号                                             |
  | adminid              | int(10) unsigned     | NO   |      |              | 审核管理员ID                                   |
  | adminname            | varchar(20)          | NO   |      |              | 审核管理员账号                                   |
  | remark               | varchar(50)          | NO   |      |              | 审核备注                                         |
  | check_time           | int(10) unsigned     | NO   |      | 0           | 审核时间                                         |
  | status               | tinyint(1)           | NO   |      | 0           | 审核结果：0未审核 1审核通过 2未通过 -1删除 |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 提款申请时间 记录创建时间                       |
  | update_at            | int(10) unsigned     | NO   |      | 0           | 记录更新时间                                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户提款审核

# 模型解释 end：
*/
class UserWithdraw extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_withdraw";//表名

}

?>