<?php

namespace Model;

/**
 # 模型解释 start：

模型名：PayOnlineConfig
表明：pay_online_config
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | channle_code         | varchar(20)          | NO   |      |              | 渠道code                                     |
  | pay_code             | varchar(20)          | NO   |      |              | 支付通道                                         |
  | client_type          | varchar(10)          | NO   |      |              | 支持终端类型 1PC 2H5                     |
  | pay_url              | varchar(255)         | NO   |      |              | 支付url地址                                   |
  | buession_no          | varchar(100)         | NO   |      |              | 商户号                                           |
  | buession_key         | text                 | NO   |      |              | 商户秘钥                                         |
  | single_limit_max     | int(10) unsigned     | NO   |      | 0           | 单笔限额上限                                     |
  | single_limit_min     | int(10) unsigned     | NO   |      | 0           | 单笔限额下限                                     |
  | day_limit_max        | int(10) unsigned     | NO   |      | 0           | 单日限额（当天累计收款达到后将停止展示）         |
  | bet_radio            | decimal(10,2) unsigned | NO   |      | 0.00     | 彩金比例                                         |
  | mast_dml             | decimal(10,2) unsigned | NO   |      | 0.00     | 打码量（流水要求）                               |
  | user_tier            | varchar(255)         | NO   |      |              | 会员分层                                         |
  | admin_id             | int(10) unsigned     | NO   |      | 0           | 管理员ID                                       |
  | admin_name           | varchar(50)          | NO   |      |              | 管理员name                                   |
  | status               | tinyint(1) unsigned  | NO   |      | 1           | 状态：1 正常 0禁用                           |
  | create_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  | update_at            | int(10) unsigned     | NO   |      | 0           |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：在线支付配置表

# 模型解释 end：
*/
class PayOnlineConfig extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "pay_online_config";//表名

}

?>