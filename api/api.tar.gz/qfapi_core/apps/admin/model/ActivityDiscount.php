<?php

namespace Model;

/**
 # 模型解释 start：

模型名：ActivityDiscount
表明：activity_discount
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | title                | varchar(50)          | NO   |      |              | 标题                                             |
  | sort                 | int(4) unsigned      | NO   |      | 100       | 权重（排序）                                     |
  | little_image         | varchar(255)         | NO   |      |              | 小图                                             |
  | big_image            | varchar(255)         | NO   |      |              | 大图                                             |
  | thum_image           | varchar(255)         | NO   |      |              | 缩略图                                           |
  | status               | tinyint(1)           | NO   |      | 1           | 状态：1正常 -1删除                           |
  | type                 | tinyint(1) unsigned  | NO   |      |              | 类型：                                           |
  | ischeck              | tinyint(1) unsigned  | NO   |      | 1           | 是否需要审核：0否 1是                         |
  | isjoin               | tinyint(1) unsigned  | NO   |      | 1           | 是否需要加入：1是 0否                         |
  | rule                 | text                 | NO   |      |              | 规则                                             |
  | start_time           | int(10) unsigned     | NO   |      | 0           | 活动开始时间                                     |
  | end_time             | int(10) unsigned     | NO   |      | 0           | 活动结束时间                                     |
  | create_at            | int(10) unsigned     | NO   |      | 0           | 记录创建时间                                     |
  | update_at            | int(10) unsigned     | NO   |      | 0           | 记录更新时间                                     |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：优惠活动

# 模型解释 end：
*/
class ActivityDiscount extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "activity_discount";//表名

}

?>