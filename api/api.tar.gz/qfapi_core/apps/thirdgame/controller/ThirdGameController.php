<?php

class ThirdGameController extends iController {

    //间隔时间（单位：秒）
//    public $times = 300;
    public $times = 1800;

    /**
     * 开元棋牌计划任务拉取投注记录
     */
    public function kyBetList() {

        //当前时间戳（毫秒级）
        list($msec, $sec) = explode(' ', microtime());
        $dq_time = (float) sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);

        $iEt = new iElasticsearch();
        $logs = $iEt->getLastBet('ky_game_put_list');

        //所需的间隔时间
        $times = $this->times * 1000;

        $start_time = 0;
        $end_time = 0;
        if ($logs['total'] > 0) {
            $info = array_values($logs['data']);
            $start_time = $info[0]['end_time'];
            //如果最后拉取数据的时间 + 间隔时间  大于当前时间的话，则将当前时间往前推1分钟，在通过间隔时间计算起始。
            if (($start_time + $times) >= $dq_time) {
                $end_time = ($dq_time - 60000);
                $start_time = $end_time - $times;
            } else {
                $end_time = $start_time + $times;
            }
        } else {
            $end_time = $dq_time - 60000;
            $start_time = $end_time - $times;
        }

        $game = new GameChessKy();
        return $game->getGameList($start_time, $end_time);
    }

    /**
     * @action_doc_start
     * @action_index:GetGameData
     * @action_name:拉取游戏记录
     * @action_description:
     * 请求参数：
     * 路由地址：/thirdGame/GetGameData/[游戏类型：live_ag_in(ag真人国际厅)]
     * 
     * 返回数据：
     * {
     *      code:0,//1
     *      msg:"",//拉取游戏数据失败|游戏" . $game_class_name . "对象不存在|游戏不存在
     *      data:{
     *      }
     * }
     * @action_doc_end
     */
    public function actionGetGameData($gamecode) {
        $game_class_name = "Game" . $this->toTuoFeng($gamecode);

        if (class_exists($game_class_name)) {
            $ret = (new $game_class_name)->getGameData();
            if ($ret === false) {
                return $this->error("拉取游戏数据失败");
            }
            return $this->success([$ret]);
        } else {
            iLog::write("游戏" . $game_class_name . "对象不存在");
            return $this->error("游戏不存在!!");
        }
    }

}
