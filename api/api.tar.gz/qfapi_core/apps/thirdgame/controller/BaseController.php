<?php

/**
 * @module_doc_start
 * @module_name:框架基础模块
 * @module_type:common
 * @module_description:
 * 该模块包含包含系统基础的：登录、登出、图像验证码、自动化文档、自动化模型、随机公钥和私钥对生成
 * @module_doc_end
 */
class BaseController extends iController {

    public $needCheckAccess = false;
    public $sendCookie = true;

    /**
     * @action_doc_start
     * @action_index:login
     * @action_name:登陆
     * @action_description:
     * 参数：
     *  +----------------------+---------------------+----------------------------------------+
     *  | 参数名               | 格式                 | 备注                                    |
     *  +----------------------+----------------------+----------------------------------------+
     *  | post.name            | string               | 不能为空                                |
     *  | post.password        | string               | 不能为空                                |
     *  | post.authcode        | string               | 验证码不能为空                           |
     *  +----------------------+----------------------+-----------------------------------------+
     * @action_doc_end
     */
    function actionLogin() {
        $name = $password = $authcode = "";

        if ($this->validate('notempty', 'post.name', $name) === false) {
            return $this->error(3, '用户名不能为空!');
        }

        if ($this->validate('password', 'post.password', $password) === false) {
            return $this->error(3, '密码格式不正确!');
        }

        if ($this->validate('/^[a-zA-Z0-9]{4,6}$/', 'post.authcode', $authcode) === false) {
            return $this->error(3, '验证码不能为空!');
        }

        if ($authcode != iSession::get("login_authnum")) {
            return iSession::get();
            return $this->error("验证码错误" . iSession::get("login_authnum"));
        }

        $rest_user = $this->model("user");

        $user = $rest_user->_detail(["name" => $name]);

        if (empty($user)) {
            return $this->error("用户不存在");
        }

        if ($user["password"] && $user["password"] !== $this->password($password, $user["salt"])) {
            return $this->error("密码错误");
        } else {
            //查看是否状态正常
            if ($user["status"] !== "1") {
                return $this->error("当前用户状态，禁止登录");
            }

            $data = array(
                "id" => $user["id"],
                "salt" => $user["salt"],
                "name" => $user["name"],
                "group_indexes" => $user["group_indexes"]
            );

            iSession::set($data); //登录用户会话存储30天
            unset($data["salt"]);
            unset($data["group_indexes"]);
            return $this->success(array("user" => $data));
        }
    }

    /**
     * @action_doc_start
     * @action_index:getPermissionRouter
     * @action_name:获取权限路由
     * @action_description:
     * @return array 
{
        "permission_routes": {
            "system": {
                "name": "系统管理", 
                "children": {
                    "permission_lists": {
                        "name": "权限列表", 
                        "actions": [
                            "base/getPermissionLists"
                        ]
                    }, 
                    "auth_group": {
                        "name": "权限分组管理", 
                        "children": {
                            "lists": {
                                "name": "权限分组列表", 
                                "actions": [
                                    "rest/adminGroup/lists"
                                ]
                            }, 
                            "update": {
                                "name": "权限分组修改", 
                                "actions": [
                                    "rest/adminGroup/update"
                                ]
                            }, 
                            "delete": {
                                "name": "权限分组删除", 
                                "actions": [
                                    "rest/adminGroup/delete"
                                ]
                            }
                        }
                    }, 
                    "admin": {
                        "name": "管理员管理", 
                        "children": {
                            "lists": {
                                "name": "管理员列表", 
                                "actions": [
                                    "rest/admin/lists"
                                ]
                            }, 
                            "update": {
                                "name": "管理员修改", 
                                "actions": [
                                    "rest/admin/update"
                                ]
                            }, 
                            "delete": {
                                "name": "管理员删除", 
                                "actions": [
                                    "rest/admin/delete"
                                ]
                            }
                        }
                    }, 
                    "operate_lists": [ ], 
                    "system_monitor": {
                        "ip_exception": {
                            "name": "ip异常"
                        }, 
                        "rechange_exception": {
                            "name": "充值异常"
                        }, 
                        "withdrawal_exception": {
                            "name": "提款异常"
                        }
                    }
                }
            }
        }
    }
     * 
     * 
     * @action_doc_end
     */
    public function actionGetPermissionRouter() {
        $permission_routes = permissionRouter::get();
        $ret = array(
            "permission_routes" => $permission_routes
        );
        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:getSessionPermission
     * @action_name:获取会话权限
     * @action_description:
     * @return array array("code"=>0,"data"=>array("lists"=>["base/login","base/logout"]),"msg"=>"")
     * @action_doc_end
     */
    public function actionGetSessionPermission() {
        $group_indexes = iSession::get("group_indexes", "");
        $where = array(
            "index" => array(
                "in",
                explode(",", $group_indexes)
            )
        );

        $ret_user_groups = $this->model("adminGroup")->_list($where, null, 100, 1, "actions");
        $permission_lists = [];
        foreach ($ret_user_groups as $group) {
            $actions = explode(",", $group);
            $permission_lists = array_merge($permission_lists, $actions);
        }
        $permission_lists = array_unique($permission_lists);
        $ret = array(
            "lists" => $permission_lists
        );

        return $this->success($ret);
    }

    /**
     * @action_doc_start
     * @action_index:logout
     * @action_name:登陆注销
     * @action_description:
     * 注意：该接口将登陆该token对应所有服务，包含后台，前台等等
     * @action_doc_end
     */
    public function actionLogout() {
        iSession::destory();
        return $this->success();
    }

    /**
     * @action_doc_start
     * @action_index:authnum
     * @action_name:获取图片验证码
     * @action_description:
     * 前端通过image标签直接访问该图像验证码：<image src="base/authnum?t=1547866836.1234" />
     * @action_doc_end
     */
    function actionAuthnum() {
        $this->validate("/^(login)|(register)|(common)$/", "get.type", $type, "common");
        $this->contentType = "image/png";
        $authnum = new iAuthnum();
        $authnum->create();
        iSession::set(array($type . "_authnum" => $authnum->randnum));
    }

    /**
     * @action_doc_start
     * @action_index:doc
     * @action_name:获取API文档
     * @action_description:
     * 将以网页的形式展示该服务下的接口文档
     * @action_doc_end
     */
    function actionDoc() {
        //restfull类型接口
        $model_dir = APP_DIR . "/bin/model";
        $files_model = scandir($model_dir);

        $files_controller = scandir(__DIR__);
        $no_need_explane_files_arr = array(".", "..", "_Empty.php");
        $doc = array();
        foreach ($files_controller as $file) {
            if (!in_array($file, $no_need_explane_files_arr)) {
                $content = file_get_contents(__DIR__ . "/" . $file);
                $module_index = lcfirst(substr($file, 0, -14));
                $pattern_module_name = "/@module_name[:：]([\S]+)/";
                $module_name = preg_match($pattern_module_name, $content, $matches_module_name) ? $matches_module_name[1] : $module_index;

                $pattern_module_type = "/@module_type[:：]([\S]+)/";
                $module_type = preg_match($pattern_module_type, $content, $matches_module_type) ? $matches_module_type[1] : "common";

                $pattern_module_description = "/@module_description[:：]([\s\S]+)@module_doc_end/U";
                $module_description = preg_match($pattern_module_description, $content, $matches_module_description) ? $matches_module_description[1] : "";

                $doc[$module_index] = array(
                    "module_index" => $module_index,
                    "module_name" => $module_name,
                    "module_description" => preg_replace("/[\r\n][ ]*\*/", "\r\n", $module_description),
                    "module_type" => $module_type
                );

                $actions = array();

                $pattern_actions = "/@action_doc_start[\s\S]*?@action_doc_end/";
                if (preg_match_all($pattern_actions, $content, $matches_actions)) {
                    $matches_actions = $matches_actions[0];
                    foreach ($matches_actions as $actions_str) {
                        $action_index = lcfirst(preg_match("/@action_index[:：]([\S]+)/", $actions_str, $matches_action_index) ? $matches_action_index[1] : "");
                        $action_name = preg_match("/@action_name[:：]([\S]+)/", $actions_str, $matches_action_name) ? $matches_action_name[1] : $action_index;
                        $action_description = preg_match("/@action_description[:：]([\s\S]+)@action_doc_end/U", $actions_str, $matches_action_description) ? $matches_action_description[1] : "";
                        if (empty($action_index)) {
                            continue;
                        }
                        $actions[$action_index] = array(
                            "module_index" => $module_index,
                            "action_index" => $action_index,
                            "action_name" => $action_name,
                            "action_description" => preg_replace("/[\r\n][ ]*\*/", "\r\n", $action_description)
                        );
                    }
                }

                if ($module_type === "rest") {
                    foreach ($files_model as $file) {
                        if (!in_array($file, $no_need_explane_files_arr)) {
                            $model_content = file_get_contents($model_dir . "/" . $file);
                            $model_index = lcfirst(substr($file, 0, -4));

                            $pattern_model_name = "/模型名[:：] ([\S]+)/";
                            $model_name = preg_match($pattern_model_name, $model_content, $matches_model_name) ? $matches_model_name[1] : $model_index;

                            $pattern_model_description = "/模型解释 start：([\s\S]*)模型解释 end：/U";
                            $model_description = preg_match($pattern_model_description, $model_content, $matches_model_description) ? $matches_model_description[1] : "";

                            //模型信息
                            $doc[$module_index]["models"][$model_index] = array(
                                "module_index" => $module_index,
                                "model_index" => $model_index,
                                "model_name" => $model_name,
                                "model_description" => preg_replace("/[\r\n][ ]*\*/", "\r\n", $model_description),
                                "actions" => $actions
                            );
                        }
                    }
                } else {
                    $doc[$module_index]["actions"] = $actions;
                }
            }
        }

        $data = array(
            "doc" => $doc
        );

        return $this->display(null, $data);
    }

    /**
     * @action_doc_start
     * @action_index:getActions
     * @action_name:获取所有行为
     * @action_description:获取所有行为
     * 
     * @action_doc_end
     */
    function actionGetActionLists() {
        //restfull类型接口
        $model_dir = APP_DIR . "/bin/model";
        $files_model = scandir($model_dir);

        $files_controller = scandir(__DIR__);
        $no_need_explane_files_arr = array(".", "..", "_Empty.php");
        $action_lists = array();
        foreach ($files_controller as $file) {
            if (!in_array($file, $no_need_explane_files_arr)) {
                $content = file_get_contents(__DIR__ . "/" . $file);
                $module_index = substr($file, 0, -14);
                $pattern_module_name = "/@module_name[:：]([\S]+)/";
                $module_name = preg_match($pattern_module_name, $content, $matches_module_name) ? $matches_module_name[1] : $module_index;

                $controller = $module_index . "Controller";
                $controllerObj = new $controller(false);
                $module_type = $controllerObj->isRestApi ? "rest" : "common";
                $actions = array();

                $pattern_actions = "/@action_doc_start[\s\S]*?@action_doc_end/";
                if (preg_match_all($pattern_actions, $content, $matches_actions)) {
                    $matches_actions = $matches_actions[0];
                    foreach ($matches_actions as $actions_str) {
                        $action_index = preg_match("/@action_index[:：]([\S]+)/", $actions_str, $matches_action_index) ? $matches_action_index[1] : null;
                        $action_name = preg_match("/@action_name[:：]([\S]+)/", $actions_str, $matches_action_name) ? $matches_action_name[1] : $action_index;
                        if ($action_index === null) {
                            continue;
                        }
                        $actions[$action_index] = array(
                            "action_index" => $action_index,
                            "action_name" => $action_name
                        );
                    }
                }

                if ($module_type === "rest") {
                    foreach ($files_model as $file) {
                        $model_content = file_get_contents($model_dir . "/" . $file);
                        $model_index = substr($file, 0, -4);
                        $pattern_model_name = "/模型名[:：] ([\S]+)/";
                        $model_name = preg_match($pattern_model_name, $model_content, $matches_model_name) ? $matches_model_name[1] : $model_index;

                        foreach ($actions as $action) {
                            $action_lists[] = array(
                                "app" => APP_NAME,
                                "type" => "rest",
                                "path" => $module_index . "/" . $model_index . "/" . $action["action_index"],
                                "module_index" => $module_index,
                                "module_name" => $module_name,
                                "model_index" => $model_index,
                                "model_name" => $model_name,
                                "action_index" => $action["action_index"],
                                "action_name" => $action["action_name"]
                            );
                        }
                    }
                } else {
                    foreach ($actions as $action) {
                        $action_lists[] = array(
                            "app" => APP_NAME,
                            "type" => "common",
                            "path" => $module_index . "/" . $action["action_index"],
                            "module_index" => $module_index,
                            "module_name" => $module_name,
                            "action_index" => $action["action_index"],
                            "action_name" => $action["action_name"]
                        );
                    }
                }
            }
        }

        $data = array(
            "lists" => $action_lists
        );

        return $this->success($data);
    }

    /**
     * @action_doc_start
     * @action_index:autoModel
     * @action_name:自动化生成数据模型
     * @action_description:
     * $data = array(
     *   "the base model of table {$table_name} created success.<br/>"
     * )
     * @action_doc_end
     */
    function actionAutoModel() {
        $model = new iModel();
        $tables = $model->_query("show table status;");

        $ret = [];
        foreach ($tables as $v) {
            $table_name = $v["Name"];
            $object_name = ucfirst(preg_replace_callback('/(_[a-z]{1})/', function($matches) {
                        return strtoupper(ltrim($matches[0], "_"));
                    }, $v["Name"]));
            $base_model_file = APP_DIR . "/bin/model/" . $object_name . ".php";
            $data = array(
                "table_name" => $table_name,
                "object_name" => $object_name,
                "table_info" => $v,
                "fields_info" => $model->_query("show full fields from {$table_name}")
            );
            if (!is_file($base_model_file)) {//如果模型文件不存在，则
                $content = $this->display("auto_model_tpl", $data, false);
                file_put_contents($base_model_file, $content);
            } else {
                $note = $this->display("auto_model_note", $data, false);
                $content = file_get_contents($base_model_file);
                $replace_count = 0;
                $content2 = preg_replace("/\/\*\*[\s]*# 模型解释 start：[\S\s]*模型解释 end：[\s]*\*[\/]+/", $note, $content, 1, $replace_count);
                if ($replace_count === 0) {//如果模型文件中没有模型描述内容则插入
                    $content2 = preg_replace("/namespace Model;/", "namespace Model;\r\n" . $note, $content, 1);
                }
                file_put_contents($base_model_file, $content2);
            }
            $ret[] = "the base model of table {$table_name} created success.<br/>";
        }

        return $this->display("auto_model", $ret, false);
    }

    /**
     * @action_doc_start
     * @action_index:secret
     * @action_name:随机公钥和私钥对生成
     * @action_description:
     * 可以通过skey生成stxt,但无法通过stxt获取到skey
     * 返回值：
     * $data = array(
     *   “skey”=>"加密key",
     *   ”stxt“=>"加密内容"
     * )
     * @action_doc_end
     */
    function actionSecret() {

        $s = "";
        $k = "";
        $ret = array();

        for ($i = 0; $i < 512; $i++) {
            $num = rand(0, 61);
            $char = $this->f10t62($num);
            $k .= $char;
        }
        $ret["skey"] = $k;

        //生成密文
        for ($i = 0; $i < 512; $i++) {
            $kcp = $this->f62t10(substr($k, $i, 1));
            $s .= substr(sha1(substr($k, $i, $kcp)), $kcp % 40, 1);
        }

        //根据key给密文加入沙子，并丢失部分真实密文
        for ($i = 0; $i < 100; $i++) {
            $num = rand(0, 61);
            $char = $this->f10t62($num);
            $first_c = substr($k, $i, 1);
            $second_c = substr($k, $i + $this->f62t10($first_c), 1);
            $sumc = (int) ((string) $this->f62t10($first_c) . (string) $this->f62t10($second_c));
            $pos = $sumc % 512;
            if ($sumc > $sumc / 2) {
                $s = substr_replace($s, $char, $pos, 1);
            } elseif ($sumc < $sumc / 4) {
                $s = substr_replace($s, "", $pos, 1);
                $s .= $char;
            }
        }
        $ret["stxt"] = $s;

        return $this->success($ret);
    }

}
