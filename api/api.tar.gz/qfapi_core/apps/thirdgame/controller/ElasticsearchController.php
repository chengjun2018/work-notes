<?php

/**
 * @module_doc_start
 * @module_name:ES公共处理方法（后端使用）
 * @module_type:common
 * @module_descrition:
 * @module_doc_end
 */
class ElasticsearchController extends iController {

    public $needCheckAccess = false;

    /**
     * @action_doc_start
     * @action_index:createDb
     * @action_name:创建索引数据库
     * @action_description:
     * 创建索引数据库
     *
     * 请求示例:
     *     {
     *          db:'logs'
     *     }
     *
     * @action_doc_end
     */
    public function actionCreateDb() {

        $db = (string) $this->input('post.db');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        $es = new iElasticBuild();
        $rs = $es->create_db($db);
        if (false == $rs || isset($rs['error']))
            return $this->error('1',$rs);

        return $this->success($rs);
    }


    /**
     * @action_doc_start
     * @action_index:getIndex
     * @action_name:获取索引信息
     * @action_description:
     * 获取索引信息
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *     }
     *
     * @action_doc_end
     */
    public function actionGetIndex() {

        $db = (string) $this->input('post.db');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        $es = new iElasticBuild();
        $rs = $es->get_index($db);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);

    }

    /**
     * @action_doc_start
     * @action_index:deleteDb
     * @action_name:删除索引数据库
     * @action_description:
     * 删除索引数据库
     *
     * 请求示例:
     *     {
     *          db:'logs'
     *     }
     *
     *
     * @action_doc_end
     */
    public function actionDeleteDb() {

        $db = (string) $this->input('post.db');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        $es = new iElasticBuild();
        $rs = $es->delete_db($db);
        if (false == $rs || isset($rs['error']))
            return $this->error('1',$rs);

        return $this->success($rs);
    }


    /**
     * @action_doc_start
     * @action_index:createMappings
     * @action_name:创建表字段
     * @action_description:
     * 创建表字段
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs',
     *          field: {
     *              'id' : {
     *                  type:'keyword',
     *                  store:true
     *              },
     *              'actions' : {
     *                  type:'keyword',
     *                  store:true
     *              },
     *              'params' : {
     *                  type:'text'
     *              },
     *              'from_username': {
     *                  type:'keyword',
     *                  store:true
     *              },
     *              'to_username': {
     *                  type:'keyword',
     *                  store:true
     *              },
     *              'desc': {
     *                  type:'text'
     *              },
     *              'ip': {
     *                  type:'ip',
     *                  store:true
     *              },
     *              'time': {
     *                  type:'date',
     *                  store:true,
     *                  format:'yyy-MM-dd HH:mm:ss||yyyy-MM-dd||epoch_millis'
     *              }
     *          }
     *     }
     *
     * @action_doc_end
     */
    public function actionCreateMappings() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        $field = (array) $this->input('post.field');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

//        if (!$this->validate($this->preg['notempty'], 'post.field', $field))
//            return $this->error(3, 'field参数不对');

        $es = new iElasticBuild();
        $rs = $es->create_mappings($db, $table, $field);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);
    }


    /**
     * @action_doc_start
     * @action_index:getMappings
     * @action_name:获取表信息
     * @action_description:
     * 获取表信息
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs'
     *     }
     *
     * @action_doc_end
     */
    public function actionGetMappings() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

        $es = new iElasticBuild();
        $rs = $es->get_mapping($db, $table);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);
    }




    /**
     * @action_doc_start
     * @action_index:addDoc
     * @action_name:添加文档数据
     * @action_description:
     * 添加文档数据
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs',
     *          id:1,
     *          doc:{
     *              id:1,
     *              actions:'/admin/user/login',
     *              params: {
     *                  'username': 'admin',
     *                  'password': '123qwe'
     *              },
     *              from_username: 'admin',
     *              to_username: '',
     *              desc: '用户登录',
     *              time: '2019-03-30 18:00:00',
     *              ip: '192.168.1.147'
     *          }
     *     }
     *
     * @action_doc_end
     */
    public function actionAddDoc() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        $doc = (array) $this->input('post.doc');
        $id = (int) $this->input('post.id');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

//        if (!$this->validate($this->preg['notempty'], 'post.doc', $doc))
//            return $this->error(3, 'doc参数不对');

        if (empty($doc)) return $this->error(3, 'doc参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.id', $id))
            return $this->error(3, 'id参数不对');

        $es = new iElasticBuild();
        $rs = $es->add_doc($db, $table, $id, $doc);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);
    }

    /**
     * @action_doc_start
     * @action_index:getDoc
     * @action_name:获取文档信息
     * @action_description:
     * 获取文档信息
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs',
     *          id:1
     *     }
     *
     * @action_doc_end
     */
    public function actionGetDoc() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        $id = (string) $this->input('post.id');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.id', $id))
            return $this->error(3, 'id参数不对');

        $es = new iElasticBuild();
        $rs = $es->get_doc($db, $table, $id);
        return $rs;
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);
    }


    /**
     * @action_doc_start
     * @action_index:updDoc
     * @action_name:修改文档数据
     * @action_description:
     * 修改文档数据
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs',
     *          id:1,
     *          doc:{
     *              id:1,
     *              title:'admin_logs',
     *              content: '中国好',
     *              time: '2019-03-30 18:00:00'
     *          }
     *     }
     *
     * @action_doc_end
     */
    public function actionUpdDoc() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        $doc = (string) $this->input('post.doc');
        $id = (int) $this->input('post.id');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.doc', $doc))
            return $this->error(3, 'doc参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.id', $id))
            return $this->error(3, 'id参数不对');

        $es = new iElasticBuild();
        $rs = $es->update_doc($db, $table, $id, $doc);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);
    }


    /**
     * @action_doc_start
     * @action_index:delDoc
     * @action_name:删除文档数据
     * @action_description:
     * 删除文档数据
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs',
     *          id:1
     *     }
     *
     * @action_doc_end
     */
    public function actionDelDoc() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        $id = (int) $this->input('post.id');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.id', $id))
            return $this->error(3, 'id参数不对');

        $es = new iElasticBuild();
        $rs = $es->delete_doc($db, $table, $id);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);
    }


    /**
     * @action_doc_start
     * @action_index:cleanDoc
     * @action_name:清空文档数据
     * @action_description:
     * 清空文档数据
     *
     * 请求示例:
     *     {
     *          db:'logs',
     *          table:'admin_logs'
     *     }
     *
     * @action_doc_end
     */
    public function actionCleanDoc() {

        $db = (string) $this->input('post.db');
        $table = (string) $this->input('post.table');
        if (!$this->validate($this->preg['notempty'], 'post.db', $db))
            return $this->error(3, 'db参数不对');

        if (!$this->validate($this->preg['notempty'], 'post.table', $table))
            return $this->error(3, 'table参数不对');

        $es = new iElasticBuild();
        $rs = $es->clean_doc($db, $table);
        if (isset($rs['error']))
            return $this->error('1',$rs);
        return $this->success($rs);


    }


    public function actionBetchIns() {

        $stime=microtime(true); #获取程序开始执行的时间


        $es = new iElasticBuild();
        $rs = $es->batch_insert();
//        $rs = $es->getNum();
        if (isset($rs['error']))
            return $this->error('1',$rs);

        #你写的php代码
        $etime=microtime(true); #获取程序执行结束的时间
        $total=$etime-$stime;   #计算差值
        echo "<br />{$total} times";
        return $this->success($rs);
    }

}
