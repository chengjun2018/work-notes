<?php

namespace Model;

/**
 # 模型解释 start：

模型名：AdminActionLog
表明：admin_action_log
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | user_id              | int(10) unsigned     | NO   |      |              | 用户id                                         |
  | appid                | int(11)              | YES  |      |              |                                                  |
  | action               | char(80)             | NO   |      |              | 行为类型即路由                                   |
  | action_content       | varchar(10000)       | NO   |      |              | 行为内容即参数                                   |
  | status               | tinyint(4)           | NO   |      | 1           | 状态                                             |
  | remark               | varchar(191)         | NO   |      |              | 备注                                             |
  | created_at           | int(10) unsigned     | YES  |      | 0           | 创建时间                                         |
  | updated_at           | int(10) unsigned     | YES  |      | 0           | 更新时间                                         |
  | ipaddress            | varchar(255)         | YES  |      |              |                                                  |
  | username             | varchar(20)          | YES  |      |              | 用户名                                           |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户行为日志

# 模型解释 end：
*/
class AdminActionLog extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "admin_action_log";//表名

}

?>