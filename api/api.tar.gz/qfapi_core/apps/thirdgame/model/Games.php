<?php

namespace Model;

/**
 # 模型解释 start：

模型名：Games
表明：games
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | title                | varchar(20)          | NO   |      |              | 游戏名                                           |
  | logo                 | varchar(255)         | NO   |      |              | 游戏logo                                     |
  | info                 | varchar(255)         | NO   |      |              | 游戏简介                                         |
  | href                 | varchar(255)         | NO   |      |              | 跳转地址                                         |
  | is_dir               | tinyint(1) unsigned  | NO   |      | 0           | 是否是目录（用来判断是否直接进入第三方游戏）  默认0 1是不跳转 0不是要进入第三方游戏 |
  | status               | tinyint(1) unsigned  | NO   |      |              | 状态：1启用 0禁用                             |
  | type                 | tinyint(1) unsigned  | NO   |      |              | 游戏类型 1视讯 2电子游戏 3棋牌 4捕鱼 5体育 6彩票 |
  | pid                  | int(10) unsigned     | NO   |      | 0           | 父ID                                           |
  | tag                  | smallint(1)          | NO   |      |              | 游戏分类标签                                     |
  | createtime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  | updatetime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：

# 模型解释 end：
*/
class Games extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "games";//表名

}

?>