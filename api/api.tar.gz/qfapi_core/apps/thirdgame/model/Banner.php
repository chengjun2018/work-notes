<?php

namespace Model;

/**
 # 模型解释 start：

模型名：Banner
表明：banner
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | path                 | varchar(255)         | NO   |      |              | 图片地址                                         |
  | title                | varchar(50)          | NO   |      |              | 图片标识                                         |
  | status               | tinyint(1) unsigned  | NO   |      | 0           | 0启用 1禁用                                   |
  | sort                 | int(4) unsigned      | NO   |      |              | 排序                                             |
  | type                 | tinyint(1) unsigned  | NO   |      |              | 1.PC 2.H5                               |
  | position             | tinyint(1) unsigned  | NO   |      |              | 1首页banner 2活动banner          |
  | href                 | varchar(255)         | NO   |      |              | 链接                                             |
  | createtime           | timestamp            | NO   |      | CURRENT_TIMESTAMP | 创建时间                                         |
  | updatetime           | timestamp            | NO   |      | CURRENT_TIMESTAMP | 修改时间                                         |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：banner表

# 模型解释 end：
*/
class Banner extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "banner";//表名

}

?>