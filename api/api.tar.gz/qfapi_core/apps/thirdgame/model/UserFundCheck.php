<?php

namespace Model;

/**
 # 模型解释 start：

模型名：UserFundCheck
表明：user_fund_check
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | money                | decimal(10,4) unsigned | NO   |      |              |                                                  |
  | type                 | tinyint(1) unsigned  | NO   |      |              | 类型：1加款  2扣款                           |
  | is_discount          | tinyint(1) unsigned  | NO   |      |              | 是否赠送优惠：1是 0否                         |
  | is_caijin            | tinyint(1) unsigned  | NO   |      |              | 是否赠送彩金：1是 0否                         |
  | is_score             | tinyint(1) unsigned  | NO   |      |              | 计算积分：1计算 0不计算                       |
  | is_count_dml         | tinyint(1) unsigned  | NO   |      |              | 计算打码量：1计算 0不计算                     |
  | is_clear_dml         | tinyint(1) unsigned  | NO   |      |              | 情况历史打码量：1情况 0不清空                 |
  | remark               | varchar(100)         | NO   |      |              | 备注                                             |
  | status               | tinyint(1) unsigned  | NO   |      | 0           | 审核状态：0未审核 1通过 2未通过             |
  | reason               | varchar(50)          | NO   |      |              | 审核结果备注                                     |
  | adminid              | int(10) unsigned     | NO   |      | 0           | 管理员ID                                       |
  | adminname            | varchar(20)          | NO   |      |              | 管理员                                           |
  | createtime           | timestamp            | NO   |      | CURRENT_TIMESTAMP | 添加时间                                         |
  | checktime            | datetime             | NO   |      |              | 审核时间                                         |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：手动加款/扣款审核

# 模型解释 end：
*/
class UserFundCheck extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user_fund_check";//表名

}

?>