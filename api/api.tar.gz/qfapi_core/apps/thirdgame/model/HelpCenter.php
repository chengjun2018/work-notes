<?php

namespace Model;

/**
 # 模型解释 start：

模型名：HelpCenter
表明：help_center
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | title                | varchar(50)          | NO   |      |              | 标题                                             |
  | content              | text                 | NO   |      |              | 内容                                             |
  | type                 | tinyint(1) unsigned  | NO   |      |              | 1.常见问题 2.登录/注册 3.注册协议 。。。。。 |
  | ctype                | tinyint(1) unsigned  | NO   |      |              | 内容类型：1.富文本 2.多标签                 |
  | status               | tinyint(1) unsigned  | NO   |      |              | 0禁用 1启用                                   |
  | createtime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  | updatetime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：帮助中心

# 模型解释 end：
*/
class HelpCenter extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "help_center";//表名

}

?>