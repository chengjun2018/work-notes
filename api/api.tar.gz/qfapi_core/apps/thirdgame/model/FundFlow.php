<?php

namespace Model;

/**
 # 模型解释 start：

模型名：FundFlow
表明：fund_flow
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | userid               | int(10)              | NO   |      |              |                                                  |
  | agentid              | int(10)              | NO   |      |              | 代理id                                         |
  | tierid               | int(10)              | NO   |      |              | 用户分层                                         |
  | plat_id              | char(50)             | NO   |      |              | 平台id                                         |
  | fundtype             | tinyint(3)           | NO   |      |              | 资金账变类型：是个数字                           |
  | balance_before_change | decimal(10,4)        | NO   |      |              | 帐变前余额                                       |
  | change_amount        | decimal(10,4)        | NO   |      |              | 变动金额                                         |
  | balance_after_change | decimal(10,4)        | NO   |      |              | 帐变后余额                                       |
  | createtime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  | updatetime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  | remark               | varchar(255)         | NO   |      |              |                                                  |
  | status               | tinyint(1) unsigned  | NO   |      |              | 状态（0：待审核，1：正常，2：禁止，-1：删除） |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户资金流水

# 模型解释 end：
*/
class FundFlow extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "fund_flow";//表名

}

?>