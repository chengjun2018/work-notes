<?php

namespace Model;

/**
 # 模型解释 start：

模型名：User
表明：user
引擎：InnoDB

字段：
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | Field                | Type                 | Null | Key  | Default      | Extra                | Privileges                           | Comment                                          |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+
  | id                   | int(10) unsigned     | NO   | PRI  |              |                                                  |
  | realname             | varchar(20)          | NO   |      |              | 真实姓名                                         |
  | password             | char(32)             | NO   |      |              | 密码                                             |
  | username             | varchar(20)          | NO   | UNI  |              | 账号                                             |
  | status               | tinyint(1) unsigned  | NO   |      | 1           | 状态：1正常 2锁定                             |
  | tierid               | int(10) unsigned     | NO   |      |              | 会员层级ID                                     |
  | istrue               | tinyint(1) unsigned  | NO   |      | 1           | 是否真实用户：1是 0否                         |
  | phone                | char(11)             | NO   | UNI  |              | 手机号                                           |
  | outpassword          | char(32)             | NO   |      |              | 取款密码                                         |
  | remark               | varchar(255)         | NO   |      |              | 备注                                             |
  | mast_dml             | decimal(10,4) unsigned | NO   |      | 0.0000 | 要求打码量                                       |
  | registertype         | tinyint(1) unsigned  | NO   |      | 0           | 注册类型：1PC 2.H5 3.Android 4.ios(待确定) |
  | registerip           | varchar(30)          | NO   |      |              | 注册ip地址                                     |
  | registersource       | varchar(255)         | NO   |      |              | 注册来源                                         |
  | recommendcode        | varchar(6)           | NO   | UNI  |              | 推荐码                                           |
  | createtime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  | updatetime           | timestamp            | NO   |      | CURRENT_TIMESTAMP |                                                  |
  | agent_id             | int(10) unsigned     | NO   |      | 0           | 代理id,如果id=0既纯玩家用户               |
  | bank_id              | int(10) unsigned     | NO   |      |              | 绑定银行id                                     |
  | qq                   | varchar(20)          | NO   |      |              | 绑定qq                                         |
  | email                | varchar(50)          | NO   |      |              | 绑定email                                   |
  | domans               | varchar(1000)        | NO   |      |              | 代理商域名                                       |
  | agent_tierid         | int(10) unsigned     | NO   |      |              | 代理层级ID                                     |
  | agent_status         | tinyint(1) unsigned  | NO   |      | 1           | 状态：1正常 2锁定                             |
  | is_agnet             | tinyint(1) unsigned  | NO   |      | 0           | 是否是代理商                                     |
  | user_count           | int(10) unsigned     | NO   |      | 0           | 会员数量                                         |
  +----------------------+----------------------+------+------+--------------+----------------------+--------------------------------------+--------------------------------------------------+

描述更多：用户|agent表

# 模型解释 end：
*/
class User extends \iModel {

    /**
     * 公共属性
     */ 
    protected $db_table = "user";//表名

}

?>