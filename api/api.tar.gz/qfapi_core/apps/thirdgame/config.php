<?php

/**
 * 允许ip
 */
define("SERVER_HOST", "0.0.0.0");

/**
 * 数据库配置
 */
define("DB_HOST", "192.168.1.205");
define("DB_PORT", 3306);
define("DB_USER", "root");
define("DB_PASSWORD", "qfdb123!@#");
define("DB_NAME", "rainbow");

/**
 * session连接配置
 */
define("SESSION_HOST", "192.168.1.209");
define("SESSION_PORT", "6379");
define("SESSION_PASSWORD", "");

/**
 * cache连接配置
 */
define("CACHE_HOST", "192.168.1.208");
define("CACHE_PORT", "6379");
define("CACHE_PASSWORD", "");

/**
 * ElasticSearch game
 */
define("ES_GAME_HOST", "192.168.1.210");
define("ES_GAME_PORT", "9200");

/**
 * ElasticSearch log
 */
define("ES_LOG_HOST", "192.168.1.207");
define("ES_LOG_PORT", "9200");

/**
 * 跨域
 */
define("COOKIE_DOMAIN", "");
define("ALLOW_ORIGINS", "*"); //*或者多个域名，以逗号分隔，域名包含主机名，如www.aaa.com,expert.aaa.com

/**
 * 上传
 */
define("UPLOAD_PATH", '/home/projects/oss');

/**
 * 登录过期
 */
define("LOGIN_EXPIRE", 3600);

/**
 * 定时任务
 */
$cronTab = array(
    array(
        "time" => 30000,
        "task" => array(
            "path_info" => "thirdGame/getGameData/chess_ky",
            "data" => array()
        )
    ),
    array(
        "time" => 2000,
        "task" => array(
            "path_info" => "thirdGame/getGameData/electric_mg",
            "data" => array()
        )
    ),
    array(
        "time" => 2000,
        "task" => array(
            "path_info" => "thirdGame/getGameData/electric_pt",
            "data" => array()
        )
    )
);

