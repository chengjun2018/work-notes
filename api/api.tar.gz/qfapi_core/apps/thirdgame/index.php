<?php

define("APP_NAME", "thirdgame"); //原则上和应用目录名一致
define("APP_DIR", __DIR__);
define("DAEMONIZE", TRUE);
define("DEBUG", TRUE);

include __DIR__ . "/../../core/server_http.php";
