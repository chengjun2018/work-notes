#!/bin/bash
#这是测试环境api_frontend项目停止与启动服务的脚本
#Time-20190408
#Watson@irainbow7.com

#使用函数再次判断
. /etc/init.d/functions
ADMIN_PHP(){
#if [ "`ps -ef|grep /home/projects/api_frontend/apps/frontend/index.php|grep -v grep|wc -l`" -eq  "0" ]
if [ "`ps -ef|grep /home/projects/qfapi_frontend/pre.php|grep -v grep|wc -l`" -eq  "0" ]
then
  echo "api_frontend前端没有启动，现在进行自动启动"
  #/bin/php /home/projects/api_frontend/apps/frontend/index.php start 20000 8 8
  /bin/php /home/projects/qfapi_frontend/pre.php start 20000 8 8
  #echo 启动完成
else
 echo "api_frontend前端启动........"
 echo "测试环境{前端}对应端口20000"
fi
}
#调用函数
ADMIN_PHP
