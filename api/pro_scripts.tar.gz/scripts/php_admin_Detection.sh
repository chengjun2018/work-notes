#!/bin/bash
#
#
#
PORT="`netstat -tunlp|grep 20001|wc -l`"
. /etc/init.d/functions
ADMIN_PHP(){
#if [ "`ps -ef|grep /home/projects/api_frontend/apps/admin/index.php|grep -v grep|wc -l`" -eq  "6" ]
if [ "`ps -ef|grep /home/projects/qfapi_admin/pre.php|grep -v grep|wc -l`" -eq  "6" ]
then
  echo "api_admin服务运行正常"
else
  echo "测试环境{前端}对应端口20001"
fi
}
#调用函数
ADMIN_PHP


if [ "$PORT" -lt "1" ]
  then 
   echo "admin管理后台没有起来"
fi

