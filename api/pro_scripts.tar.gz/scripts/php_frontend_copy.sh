#!/bin/bash
#Time-20190419
#Watson@irainbow7.com

COPYCONFIG="`cp /home/data/api_frontend/apps/frontend/bin/config.php  /home/projects/api_frontend/apps/frontend/bin/`"
########################################################
COPYINDEX="`cp /home/data/api_frontend/apps/frontend/index.php /home/projects/api_frontend/apps/frontend/`"
#########################################################
#FDIR=/home/projects/api_frontend/apps/frontend/bin/
##############################################################
COPY_F(){
$COPYINDEX
}
FRONTEND(){
#if [ -f "/home/projects/api_frontend/apps/frontend/bin/config.php" ]
#   then
#      echo "删除旧的不正确的frontend文件"
#      /usr/bin/find "$FDIR" -type f -name "config.php" |xargs rm -rf
#else
      echo "copy正确的fronyend文件"
     $COPYCONFIG
#fi
}
###########
COPY_F
sleep 3
FRONTEND
echo "echo "$?""
