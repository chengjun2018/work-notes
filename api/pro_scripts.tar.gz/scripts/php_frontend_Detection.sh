#!/bin/bash
#
#
#
PORT="`netstat -tunlp|grep 20000|wc -l`"
. /etc/init.d/functions
ADMIN_PHP(){
#if [ "`ps -ef|grep /home/projects/api_frontend/apps/frontend/index.php|grep -v grep|wc -l`" -eq  "6" ]
if [ "`ps -ef|grep /home/projects/qfapi_frontend/pre.php|grep -v grep|wc -l`" -eq  "6" ]
then
  echo "api_frontend服务运行正常"
else
  echo "测试环境{前端}对应端口20000"
fi
}
#调用函数
ADMIN_PHP


if [ "$PORT" -lt "1" ]
  then 
   echo "Frontend没有起来"
fi

