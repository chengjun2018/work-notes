#!/bin/sh
#Time-20190419
#Watson@irainbow7.com


COPYCONFIG="`cp /home/data/api_frontend/apps/admin/bin/config.php /home/projects/api_frontend/apps/admin/bin/`"
#################################################
COPYINDEX="`cp /home/data/api_frontend/apps/admin/index.php /home/projects/api_frontend/apps/admin/`"
#####################################
#ADIR=/home/projects/api_frontend/apps/admin/bin/
##############
COPY_A(){
$COPYINDEX
}
ADMIN(){
#if [ -f "/home/projects/api_frontend/apps/admin/bin/config.php" ]
#   then
#      echo "删除旧的admin配置文件"
#      find "$ADIR" -type f -name "config.php" |xargs rm -rf
      echo "copy正确的admin文件"
      $COPYCONFIG 
#fi
}
################################################
COPY_A
sleep 3
ADMIN
echo "echo "$?""
