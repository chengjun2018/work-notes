#!/bin/sh
#Time-20190419
#Watson@irainbow7.com

#KILL_PHP="`ps -ef|grep /home/projects/api_frontend/apps/admin/index.php|grep -v grep |cut -c 9-15|xargs kill -s 9 >/dev/null 2>&1`" 
KILL_PHP="`ps -ef|grep /home/projects/qfapi_admin/pre.php|grep -v grep |cut -c 9-15|xargs kill -s 9 >/dev/null 2>&1`" 
 
###No.1#-关闭进程 
#如果api_admin进程数量大于0 
#if [ "`ps -ef|grep /home/projects/api_frontend/apps/admin/index.php|grep -v grep|wc -l`" -gt  "0" ] 
if [ "`ps -ef|grep /home/projects/qfapi_admin/pre.php|grep -v grep|wc -l`" -gt  "0" ] 
then 
#则使用kill的方式关闭进程 
  echo "关闭api_admin进程" 
#  /bin/php /home/projects/api_frontend/apps/admin/index.php stop 20001 8 8
  /bin/php /home/projects/qfapi_admin/pre.php stop
  $KILL_PHP  
fi 
echo "echo "$?""
