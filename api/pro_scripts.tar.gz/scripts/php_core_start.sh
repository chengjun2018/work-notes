#!/bin/bash
#这是测试环境api_core项目启动服务的脚本
#Time-20190501
#Watson@irainbow7.com

###No.1#-判断，并启服务

#使用函数再次判断
. /etc/init.d/functions 
FRONTEND_PHP(){
if [ "`ps -ef|grep /home/projects/qfapi_frontend/pre.php|grep -v grep|wc -l`" -lt  "1" ]
then
  echo "api_frontend 前端没有启动，现在进行自动启动"
  /bin/php /home/projects/qfapi_frontend/pre.php start 20000 8 8
  echo "启动完成"
else
  echo "api_frontend后端已经启动"
  echo "服务端口为20000"
fi
}

ADMIN_PHP() {
if [ "`ps -ef|grep /home/projects/qfapi_admin/pre.php|grep -v grep|wc -l`" -lt  "1" ]
then
  echo "api_admin后端没有启动，现在进行自动启动"
  /bin/php /home/projects/qfapi_admin/pre.php start 20001 8 8
  echo "启动完成"
else
  echo "api_admin后端已经启动"
  echo "服务端口为20001"
fi
}
#调用函数
FRONTEND_PHP
sleep 3
ADMIN_PHP
