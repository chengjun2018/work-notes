#!/bin/sh
#Time-20190430
#Watson@irainbow7.com
COPYCONFIG="`cp /home/data/file/config.php /home/projects/qfapi_core/core/`"


COPY(){
$COPYCONFIG
}
COPY

