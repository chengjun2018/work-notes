#!/bin/bash
#
#
#
PORT="`netstat -tunlp|grep 20001|wc -l`"
. /etc/init.d/functions
ADMIN_PHP(){
if [ "`ps -ef|grep iswoole_admin|grep -v grep|wc -l`" -gt  "6" ]
then
  echo "api_admin服务运行正常-Pre环境{后台}对应端口20001"
else
  echo "Pre环境{后台}没有运行"
fi
if [ "$PORT" -lt "1" ]
  then 
   echo "admin管理后台没有起来"
fi
}
#调用函数
ADMIN_PHP



