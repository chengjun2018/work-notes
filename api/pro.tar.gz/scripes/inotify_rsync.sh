#\!/bin/bash
#The is inotify and rsync dir by shell
#zuozhe cj
#time 20180401
IP=172.31.23.67
Path=/home/projects/oss/
/usr/bin/inotifywait -mrq  -e delete,close_write,moved_to,moved_from,isdir --timefmt '%Y-%m-%d %H:%M:%S' --format '%w%f:%e:%T' $Path \
|while read file
do
   cd $Path
if [ -f $file ];then
   rsync -az $file --delete rsync_backup@$IP::backup/ --password-file=/etc/rsync.password
else
   cd $Path &&
   rsync -az ./ --delete rsync_backup@$IP::backup/ --password-file=/etc/rsync.password
   fi
  done
