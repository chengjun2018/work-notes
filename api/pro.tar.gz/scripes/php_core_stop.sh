#!/bin/bash
#这是测试环境Core项目停止与启动服务的脚本
#Time-20190501
#Watson@irainbow7.com
KILL_FRONTEND="`ps -ef|grep iswoole_frontend_20000|grep -v grep |cut -c 9-15|xargs kill -s 9`"
KILL_ADMIN="`ps -ef|grep swoole_admin_20001|grep -v grep |cut -c 9-15|xargs kill -s 9`"
###No.1#-关闭进程
#如果api_admin进程数量大于0
if [  "`ps -ef|grep swoole_admin_20001|grep -v grep|wc -l`" -gt  "0"  ]
then
#则使用kill的方式关闭进程
  echo "关闭api_admin进程"
sudo  /bin/php /home/projects/qfapi_admin/master.php stop 20001  
  #$KILL_ADMIN
  sleep 3
  #$KILL_ADMIN
fi
#如果api_frontend进程数量大于0
if [ "`ps -ef|grep iswoole_frontend_20000|grep -v grep|wc -l`" -gt  "0" ]
then
#则使用kill的方式关闭进程
  echo "关闭api_frontend进程"
sudo  /bin/php /home/projects/qfapi_frontend/master.php stop 20000
  #$KILL_FRONTEND
  sleep 3
  #$KILL_FRONTEND
fi
sleep 3

