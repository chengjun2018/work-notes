#coding:utf-8
try:
	import json
except:
	import simplejson as json

import commands

(status, output) = commands.getstatusoutput('''cat /proc/diskstats |awk '{print $3}'|egrep 'sd|vd|hd'|egrep -v '[0-9]'|sort -u''')
if output:
        outputs = output.split('\n')
        disks = []
        for disk in  outputs:
            disks += [{'{#DISKONE}': disk}]
        print json.dumps({'data':disks},sort_keys=True,indent=4)
else:
        print 'discovery error'
