#!/bin/bash
#8   0 sda 76880282531 8117316 937263519846 4237854729 62989000438 35668103347 777694636224 1190396494 3 2895102137 899093508
while getopts "d:o:" opt
do
        case $opt in
                d ) disk=$OPTARG;;
                o ) option=$OPTARG;;
                ? )
                echo 'parameter is wrong!'
                exit 1;;
        esac
done
if [ ! "${disk}" ] || [ ! "${option}" ];then
        echo "parameter is null"        
        exit 1
fi

if [[ ${option} == "read" ]];then
	cat /proc/diskstats |grep "${disk} "|awk '{print $6}'
elif [[ ${option} == "write" ]];then
	cat /proc/diskstats |grep "${disk} "|awk '{print $10}'
elif [[ ${option} == "readops" ]];then
	cat /proc/diskstats |grep "${disk} "|awk '{print $4}'
elif [[ ${option} == "writeops" ]];then
        cat /proc/diskstats |grep "${disk} "|awk '{print $8}'
elif [[ ${option} == "readtime" ]];then
        cat /proc/diskstats |grep "${disk} "|awk '{print $7}'
elif [[ ${option} == "writetime" ]];then
        cat /proc/diskstats |grep "${disk} "|awk '{print $11}'
fi
