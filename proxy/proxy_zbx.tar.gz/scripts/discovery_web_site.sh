#######cat /etc/zabbix/scripts/web_site_code_status########
#!/bin/bash
#function:monitor tcp connect status from zabbix
#license:GPL
#version:1.0
source /etc/bashrc > /dev/null 2>&1
source /etc/profile > /dev/null 2>&1
#/usr/bin/curl -o /dev/null -s -w %{http_code} http://$1/
Web_dir="/etc/zabbix/scripts"
WEB_SITE_discovery () {
WEB_SITE=($(cat "$Web_dir"/WEB.txt|grep -v "^#"))
printf '{\n'
printf '\t"data":[\n'
for ((i=0;i<${#WEB_SITE[@]};++i))
{
num=$(echo $((${#WEB_SITE[@]}-1)))
if [ "$i" != "${num}" ];then
printf '\t\t{ \n'
printf "\t\t\t\"{#SITENAME}\":\"${WEB_SITE[$i]}\"},\n"
else
printf '\t\t{ \n'
printf "\t\t\t\"{#SITENAME}\":\"${WEB_SITE[$num]}\"}]}\n"
fi
}
}
WEB_SITE_code () {
/usr/bin/curl -o /dev/null -s -w %{http_code} http://$1
}
case "$1" in
web_site_discovery)
WEB_SITE_discovery;;
web_site_code)
WEB_SITE_code $2;;
*)
echo "Usage:$0 {web_site_discovery|web_site_code URL}";;
esac
