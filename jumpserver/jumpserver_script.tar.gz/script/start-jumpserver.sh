#!/bin/bash
#
#
#
#启动 jumpserver
cd /home/qfdata/
python3.6 -m venv py3  
source /home/qfdata/py3/bin/activate
cd jumpserver/
./jms start all -d
#启动docker  jms_guacamole 以及jms_koko

docker start 87fcefacd529
docker start ac316c4b4298
