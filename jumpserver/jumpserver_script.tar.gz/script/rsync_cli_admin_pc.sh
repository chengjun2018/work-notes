#\!/bin/bash
#The is inotify and rsync dir by shell
#zuozhe cj
#time 20180401
IP=172.31.29.183
IP1=172.31.41.33
Path=/home/qfdata/projects/cli_admin_pc/
#Path=/home/qfdata/data/projects/cli_admin_pc/
#api-1
#拷贝代码到监控目录
#sudo cp -a  /home/qfdata/data/projects/cli_admin_pc/* /home/qfdata/projects/cli_admin_pc/
/usr/bin/inotifywait -mrq  -e delete,close_write,attrib,modify,create,moved_to,moved_from,isdir --timefmt '%Y-%m-%d %H:%M:%S' --format '%w%f:%e:%T' $Path \
|while read file
do
   cd $Path
if [ -f $file ];then
   rsync -az $file --delete rsync_backup@$IP::cli_admin_pc/ --password-file=/etc/rsync.password
   rsync -az $file --delete rsync_backup@$IP1::cli_admin_pc/ --password-file=/etc/rsync.password
else
   cd $Path &&
   rsync -az ./ --delete rsync_backup@$IP::cli_admin_pc/ --password-file=/etc/rsync.password
   rsync -az ./ --delete rsync_backup@$IP1::cli_admin_pc/ --password-file=/etc/rsync.password
   fi
  done


