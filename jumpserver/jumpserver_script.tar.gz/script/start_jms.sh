#!/bin/bash
set -e

export LANG=zh_CN.UTF-8

systemctl start jms
docker start jms_koko
docker start jms_guacamole

exit 0
