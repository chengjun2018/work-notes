#!/bin/bash
#
#
#
echo 8192000 > /proc/sys/fs/inotify/max_user_instances
echo 8192000 > /proc/sys/fs/inotify/max_user_watches
echo 8192000 > /proc/sys/fs/inotify/max_queued_events

