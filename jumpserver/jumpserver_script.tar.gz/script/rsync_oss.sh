#\!/bin/bash
#The is inotify and rsync dir by shell
#zuozhe cj
#time 20180401
IP=172.31.22.196
IP1=172.31.39.180
Path=/home/qfdata/projects/oss/
#api-1
#拷贝代码到监控目录
/usr/bin/inotifywait -mrq  -e delete,close_write,attrib,create,modify,moved_to,moved_from,isdir --timefmt '%Y-%m-%d %H:%M:%S' --format '%w%f:%e:%T' $Path \
|while read file
do
   cd $Path
if [ -f $file ];then
   rsync -azu --ignore-errors $file --delete rsync_backup@$IP::backup/ --password-file=/etc/rsync.password
   rsync -azu --ignore-errors $file --delete rsync_backup@$IP1::backup/ --password-file=/etc/rsync.password
else
   cd $Path &&
   rsync -azu --ignore-errors ./ --delete rsync_backup@$IP::backup/ --password-file=/etc/rsync.password
   rsync -azu --ignore-errors ./ --delete rsync_backup@$IP1::backup/ --password-file=/etc/rsync.password
   fi
  done


