#!/bin/bash
set -e

export LANG=zh_CN.UTF-8

docker stop jms_koko
docker stop jms_guacamole
systemctl stop jms

exit 0
