#\!/bin/bash
#The is inotify and rsync dir by shell
#zuozhe cj
#time 20180401
IP=172.31.29.183
IP1=172.31.41.33
Path=/home/qfdata/projects/cli_agent_pc/
#api-1
#拷贝代码到监控目录
#sudo cp -a  /home/qfdata/data/projects/cli_agent_pc/* /home/qfdata/projects/cli_agent_pc/
/usr/bin/inotifywait -mrq  -e delete,close_write,attrib,create,modify,moved_to,moved_from,isdir --timefmt '%Y-%m-%d %H:%M:%S' --format '%w%f:%e:%T' $Path \
|while read file
do
   cd $Path
if [ -f $file ];then
   rsync -az $file --delete rsync_backup@$IP::cli_agent/ --password-file=/etc/rsync.password
   rsync -az $file --delete rsync_backup@$IP1::cli_agent/ --password-file=/etc/rsync.password
else
   cd $Path &&
   rsync -az ./ --delete rsync_backup@$IP::cli_agent/ --password-file=/etc/rsync.password
   rsync -az ./ --delete rsync_backup@$IP1::cli_agent/ --password-file=/etc/rsync.password
   fi
  done

#flock -xn /tmp/rsync.lock -c   rsync -az /home/qfdata/projects/cli_agent_pc/  --delete rsync_backup@172.31.29.183::cli_agent/ --password-file=/etc/rsync.password
