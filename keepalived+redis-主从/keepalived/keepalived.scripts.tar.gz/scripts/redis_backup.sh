#!/bin/bash
REDISCLI="/usr/local/redis/bin/redis-cli"
LOGFILE="/home/data/logs/keepalived-redis-state.log"
echo "[backup]" >> $LOGFILE
date >> $LOGFILE
echo "Being slave...." >> $LOGFILE 2>&1
sleep 15 #延迟15秒待数据被对方同步完成之后再切换主从角色
echo "Run SLAVEOF cmd ..." >> $LOGFILE
$REDISCLI SLAVEOF 10.0.0.6 6379 >> $LOGFILE  2>&1

