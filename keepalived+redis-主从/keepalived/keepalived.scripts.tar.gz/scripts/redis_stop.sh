# !/bin/bash
LOGFILE=/home/data/logs/keepalived-redis-state.log
echo "[stop]" >> $LOGFILE 
date >> $LOGFILE

