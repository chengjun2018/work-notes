#!/bin/bash
CHECK=`/usr/local/redis/bin/redis-cli -a qfproredis PING 2>/dev/null`
if [ "$CHECK" == "PONG" ] ;then
      echo $CHECK
      exit 0
else 
      echo $CHECK
      /etc/init.d/keepalived stop   #可确保让出MASTER
      exit 1
fi
