# !/bin/bash
LOGFILE=/home/data/logs/keepalived-redis-state.log 
echo "[fault]" >> $LOGFILE 
date >> $LOGFILE

